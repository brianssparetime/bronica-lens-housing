"""Lens housing with stacked optical elements and a matching clip-on hood.

Shows the recommended multi-part layout (see
docs/organizing_a_project.md). Generic Components live in the REUSABLE
zone with no project-specific defaults; the specific design for an
M57-throat camera lives in the CONCRETE zone as thin subclasses that
fill in measurements as class attributes.

Run:
    python examples/lens-housing.py                                  # print variant (default)
    scadwright build examples/lens-housing.py --variant=display        # assembled view
    scadwright build examples/lens-housing.py --variant=print          # split + spread for inspection
"""

import os
import sys
from collections import namedtuple

# Make sibling-file imports work under `scadwright build` (the CLI doesn't
# add the script's directory to sys.path; running via plain Python does).
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from scadwright import BBox, Component, Param, from_json, print_stamp
from scadwright.api.tolerances import default_eps
from scadwright.component.anchors import anchor

from s2_spec import BronicaS2Bayonet
from scadwright.boolops import difference, intersection, union
from scadwright.composition_helpers import mirror_copy, pack_on_bed
from scadwright.design import Design, run, variant
from scadwright.primitives import circle, cube, cylinder, polygon
from scadwright.shapes import FilletRing, Funnel, Sector, Tube
from scadwright.transforms import transform


# =============================================================================
# REUSABLE: generic Components, helpers, value types
# =============================================================================


# Per-element fit clearances around the lens body, separately tunable
# per element (different glass shapes/edge profiles benefit from
# different fit looseness). Both fields in mm.
#
# `axial` is per-side: the gap between the element's flat face (top or
# bottom) and the holder's surround floor. Total axial slop = 2 * axial
# (one gap above, one below).
#
# `radial` is DIAMETER-based, NOT radius-based: it's added directly to
# the element diameter to compute the surround tube's bore
# (`id = e.dia + clearances.radial` in ElementHolder.build()). So the
# actual per-side radial gap between the element's outer edge and the
# surround's inner wall is `radial / 2`. A `radial` of 0.4 mm means
# 0.2 mm gap on each side, not 0.4 mm. (Naming is legacy; the math is
# what counts.)
ElementClearances = namedtuple("ElementClearances", "axial radial")
DEFAULT_ELEMENT_CLEARANCES = ElementClearances(axial=0.2, radial=0.3)


# Mating disc: an annular ring on the lens-housing's outer surface that
# bridges the radial gap between the housing's outer lower segment and
# the lens-mount ring's inner bore. Built as part of the housing (so it
# gets halved with the housing's lap-split halves and needs no separate
# support); functionally it's the physical interface to the lens-mount
# ring.
#   - od: lens-mount ring's bore (the disc fits snugly inside it).
#   - z_bot, z_top: axial range in housing world frame. Typically z_bot
#     sits a small clearance above the rotation channel's roof, and
#     z_top flushes with the top of the lens-mount tube (= MOUNT_OFFSET
#     in the housing's world frame).
# The disc's ID is taken from `lower_outer_od` so the disc wraps the
# outer segment concentrically; outer is the only lower segment that
# reaches above the flange into this z-range.
MatingDisc = namedtuple("MatingDisc", "od z_bot z_top")


# Lock spec for the mating disc ↔ locking lens-mount ring lives in a
# shared module so both designs reference one source of truth without
# pulling each other's Design class into scope (which would collide on
# variant names like `print`).
from housing_lock_spec import (
    BRONICA_S2_MATING_DISC_BEAD,
    BRONICA_S2_MATING_DISC_TABS,
    HOUSING_GROOVE_ANGLE_DEG,
    MATING_DISC_CLEARANCE,
    MatingDiscBead,
    MatingDiscTabs,
)


# Helicoid focus slot: a shallow axial groove in the mid-segment wall
# that clears a focus-helicoid pin protruding from the camera body. By
# spec the slot lives entirely within the mid segment (z_bot pinned at
# the mid/inner step so the slot never opens into the inner segment).
# Uniform radial `depth` mm in from the OD across the slot's whole
# angular extent — the pin rides in this groove throughout the bayonet
# rotation. Two angular regions union into one cut:
#   - LOCKED side: `width` mm circumferential at the mid OD, centered
#     at `angle`. The pin sits here when the lens is locked.
#   - SWEEP side: extends CW from `angle` by `sweep_arc_deg` (toward
#     the alignment groove) to cover the pin's path as the lens rotates
#     from insertion to locked. Zero disables the sweep portion.
# Fields:
#   - angle: deg, 0 = +X axis (3 o'clock looking from camera toward subject).
#   - width: mm circumferential at OD on the locked side, centered on `angle`.
#   - depth: mm radial inward from the OD. Uniform across the slot.
#   - z_bot, z_top: axial range in housing world frame. z_bot = mid/inner
#     step; z_top = -offset_from_flange.
#   - sweep_arc_deg: deg, angular extent of the sweep portion CW from `angle`.
HelicoidFocusSlot = namedtuple(
    "HelicoidFocusSlot",
    "angle width depth z_bot z_top sweep_arc_deg bottom_overshoot",
)


# Aperture feeler slot: a shallow swept groove in the inner-segment wall
# that clears a small aperture-feeler protruding from the camera body.
# Same structure as `HelicoidFocusSlot` but sized off `lower_inner_od/id`,
# centered at the +X axis (3 o'clock, opposite the helicoid's 9 o'clock).
# Fields are identical to HelicoidFocusSlot — see that comment block for
# the semantics of each.
ApertureFeelerSlot = namedtuple(
    "ApertureFeelerSlot",
    "angle width depth z_bot z_top sweep_arc_deg bottom_overshoot",
)


class HousingSection(Component):
    """One axial section of the lens housing's wall. Cylindrical when
    bot_id == top_id, conical (a Funnel) otherwise. Carries both its
    axial extent and its radial profile in one Component, so the
    housing's geometry (built from sections) and its `wall_od_at_z`
    lookup (querying sections) share one source of truth — no parallel
    analytic predictor."""

    equations = """
        z_top > z_bot
        bot_id, top_id, thk > 0
    """

    # Cylindrical anchor for the outer wall — lets `add_text(on="outer_wall")`
    # wrap a label around the section. Safe only on cylindrical sections
    # (`bot_id == top_id`); conical (funnel) sections would need a separate
    # conical anchor with r1/r2/length surface_params.
    outer_wall = anchor(
        at="(bot_id + 2*thk) / 2.0, 0, (z_bot + z_top) / 2",
        normal=(1.0, 0.0, 0.0),
        kind="cylindrical",
        surface_params={
            "axis": (0.0, 0.0, 1.0),
            "radius": "(bot_id + 2*thk) / 2.0",
            "length": "z_top - z_bot",
        },
    )

    def build(self):                                       # framework hook: required; returns the shape
        h = self.z_top - self.z_bot
        if self.bot_id == self.top_id:
            return Tube(h=h, od=self.bot_id + 2 * self.thk, id=self.bot_id).up(self.z_bot)
        return Funnel(
            h=h, thk=self.thk, bot_id=self.bot_id, top_id=self.top_id,
        ).up(self.z_bot)

    def od_at(self, z):
        """Outer diameter at axial position z (must be in [z_bot, z_top])."""
        return self.id_at(z) + 2 * self.thk

    def id_at(self, z):
        """Inner diameter at axial position z (must be in [z_bot, z_top])."""
        if self.bot_id == self.top_id:
            return self.bot_id
        t = (z - self.z_bot) / (self.z_top - self.z_bot)
        return self.bot_id + t * (self.top_id - self.bot_id)


class FilletSection(Component):
    """Bore-side fillet ring at an interior step in the stacked lower
    housing. Lives inside the wider segment (the one above the step in
    housing-frame z), occupying axial extent
    `(top_id − bot_id) / 2 × tan(base_angle)` just above the step plane.
    Three things at once:
      1. Closes the radial gap between segment walls at the step. At the
         mid/inner step the inner wall ends ~1 mm radially inside mid's
         inner wall, so without this fillet the two segments are
         physically disjoint.
      2. Gives the bore step a self-supporting slope in the print
         (lens-side-down) orientation: `base_angle` is the slanted-cone
         angle from horizontal; ~45° is the FDM self-supporting
         threshold.
      3. Participates in `wall_id_at_z` so a stop or constricted-element
         holder landing inside the fillet's z range sizes off the
         locally-narrowed bore.
    `top_id` (the wider segment's bore, above the step) must exceed
    `bot_id` (the narrower segment's bore, below)."""

    equations = """
        bot_id, top_id > 0
        top_id > bot_id
        base_angle > 0
        base_angle <= 90
        h_full = tan(base_angle) * (top_id - bot_id) / 2
        z_top = z_bot + h_full
    """

    def build(self):                                       # framework hook: required; returns the shape
        return FilletRing(
            id=self.bot_id, od=self.top_id,
            base_angle=self.base_angle, slant="inwards",
        ).up(self.z_bot)

    def id_at(self, z):
        """Inner bore diameter at z. Linearly opens from `bot_id` at the
        step plane (z_bot) to `top_id` at the top of the fillet (z_top),
        matching the FilletRing's slanted inner cone."""
        t = (z - self.z_bot) / (self.z_top - self.z_bot)
        return self.bot_id + t * (self.top_id - self.bot_id)

    def od_at(self, z):
        """Outer extent at z. The fillet's outer surface is cylindrical
        at the wider segment's bore radius (i.e., the wider segment's
        inner wall) — it sits inside that bore. wall_od_at_z's MAX
        across containing sections picks the wider segment's actual OD
        instead, so this value is harmless."""
        return self.top_id


# spacing is from flange (z=0) to element center; +z = toward object.
# `face_z_top`, `face_z_bot`, `constricted`, `throat_dia_required` are
# precomputed by `element(...)` so the housing's `equations` list can
# reference them as attributes directly. `clearances` is an
# `ElementClearances(axial, radial)` namedtuple; the holder reads both
# values from this field. `code` (catalog code, e.g. "L7325") and
# `type` (e.g. "NMN", "ACH", "BCX") identify the lens.
Element = namedtuple(
    "Element",
    "code type dia edge_thk spacing face_z_top face_z_bot constricted throat_dia_required clearances",
)


class ElementHolder(Component):
    """Two-sided clamp around one Element, symmetric about the element center."""

    element = Param(Element)
    equations = """
        od, grip_depth, grip_width > 0
    """

    def build(self):                                       # framework hook: required; returns the shape
        e = self.element
        clr = e.clearances
        # Source of truth for the holder's z-extent: e.face_z_top,
        # computed once by element() factory and used by housing
        # equations to size upper_housing_len. We DERIVE surround_h from
        # it (subtracting the gripper's per-side contribution) so the
        # actual holder geometry can never drift from the predicted
        # face_z_top — change face_z_top's formula and the holder
        # follows automatically.
        gripper_h = 0.5 * self.grip_width
        surround_h = (e.face_z_top - e.spacing) - gripper_h
        # Diametral eps: the holder's outer cylinder otherwise sits at
        # exactly the housing wall's inner bore (`od == section.id` in
        # the non-wide case). The shared cylindrical face survives the
        # yield-union as an internal seam, and `halve` later exposes
        # that seam as a non-manifold edge along the cut plane. Bumping
        # the OD by 2*default_eps() pokes the holder a hair into the
        # wall material; the union with the barrel absorbs the overlap
        # and the inner bore geometry is unchanged at any meaningful
        # scale.
        eps = default_eps()
        od = self.od + 2 * eps
        surround = Tube(h=surround_h, od=od, id=e.dia + clr.radial)
        gripper = Tube(
            h=gripper_h,
            od=od,
            id=e.dia - self.grip_depth,
        ).attach(surround, bond="shift")
        half = union(surround, gripper).flip("z")
        return mirror_copy(half, normal=[0, 0, 1]).up(e.spacing)


def element(*, code, type, dia, edge_thk, spacing, grip_width, mount_offset=0,
            clearances=DEFAULT_ELEMENT_CLEARANCES):
    """Build an `Element` with its computed geometric fields filled in.

    The caller supplies `grip_width` (the holder's per-side gripper
    height) so the housing's equations can reason about each element's
    z-extent through attribute access. `mount_offset` is the axial
    extent of the lens-mount ring above the camera flange (z=0); the
    M57-restricted lower section of the housing extends up to this z,
    so an element is `constricted` when its lower face is below the
    top of the mount-ring zone (face_z_bot < mount_offset).
    `clearances` is an `ElementClearances(axial, radial)` pair; defaults
    to the project-wide `DEFAULT_ELEMENT_CLEARANCES`. Override per
    element when a particular piece of glass needs a tighter or looser
    fit (e.g. a chipped edge, an irregular OD, or a known-bad-tolerance
    cell).
    """
    # Half-extent of the element holder in z, computed from the EXACT
    # geometry built in ElementHolder.build(): one half = surround_h
    # (= 0.5 * edge_thk + axial clearance) + 0.5 * grip_width (the
    # mirror-copied gripper above the surround). Element spacings
    # (relative to the camera flange) are the source of truth; the
    # housing's `upper_housing_len = max(e.face_z_top)` is then EXACTLY
    # the topmost holder's top face, with no approximate-formula gap.
    half = 0.5 * edge_thk + clearances.axial + 0.5 * grip_width
    return Element(
        code=code, type=type,
        dia=dia, edge_thk=edge_thk, spacing=spacing,
        face_z_top=spacing + half,
        face_z_bot=spacing - half,
        constricted=(spacing - half) < mount_offset,
        throat_dia_required=dia + clearances.radial,
        clearances=clearances,
    )


class ElementTestGripper(Component):
    """Stand-alone diagnostic half-shell of one element's gripper.

    Three stacked tubes (bottom rim / middle / top rim) reproducing
    `ElementHolder`'s inward features — rim ID, middle ID, and axial
    extents — exactly, so a successful fit here predicts a fit in the
    housing. The outer wall is a smooth uniform-OD cylinder sized to
    give the middle (surround) tube `wall_thk` radial wall; rim tubes
    consequently have slightly thicker walls (the surplus being half
    of `grip_depth + radial_clr`). Intended to be halved sagittally
    and printed individually for per-element fit checks without
    committing to a full housing.

    `radial_clr` is the element's diametral radial clearance, passed
    in separately because the equations DSL only handles single-level
    attribute access and the value lives in `element.clearances.radial`.
    """

    element = Param(Element)
    equations = """
        grip_depth, grip_width, wall_thk, radial_clr > 0
        gripper_h = grip_width / 2
        surround_h = element.face_z_top - element.spacing - gripper_h
        rim_id = element.dia - grip_depth
        surround_id = element.dia + radial_clr
        od = surround_id + 2 * wall_thk
        total_h = 2 * (gripper_h + surround_h)
    """

    outer_wall = anchor(
        at="od / 2, 0, total_h / 2",
        normal=(1.0, 0.0, 0.0),
        kind="cylindrical",
        surface_params={
            "axis": (0.0, 0.0, 1.0),
            "radius": "od / 2",
            "length": "total_h",
        },
    )

    def build(self):                                       # framework hook: required; returns the shape
        bottom_rim = Tube(h=self.gripper_h, od=self.od, id=self.rim_id)
        middle = Tube(
            h=2 * self.surround_h, od=self.od, id=self.surround_id,
        ).up(self.gripper_h)
        top_rim = Tube(
            h=self.gripper_h, od=self.od, id=self.rim_id,
        ).up(self.gripper_h + 2 * self.surround_h)
        return union(bottom_rim, middle, top_rim)


# A waterhouse stop is a thin disc slid laterally into the lens barrel
# through a side slot to set the aperture. `spacing` is the stop center's
# z-position, `thk` the disc thickness, `clr` the slot's z-clearance.
Stop = namedtuple("Stop", "spacing thk clr")


class WaterhouseStop(Component):
    """A waterhouse stop disc.

    Viewed face-on, it's a 2D paddle: a smaller semicircle of radius
    `inner_diameter`/2 in -Y joined to a larger semicircle of radius
    `outer_diameter`/2 in +Y along their flat edges, with a central
    aperture hole of diameter `hole_d`. Extruded by `thk` along the
    lens axis and centered on `spacing`. When inserted, the lower
    (inner-diameter) semicircle sits in the bore as the aperture plate;
    the upper (outer-diameter) semicircle fills the wall slot, leaving
    a flush exterior. The hole sits on the barrel's axis."""

    equations = """
        inner_diameter, outer_diameter, thk, hole_d > 0
        outer_diameter > inner_diameter
        hole_d < inner_diameter
        # `spacing` is the disc's z-center; `slot_bottom` is the
        # extruder's lower edge. The derivation establishes `spacing` as
        # a Param(float) without an artificial inequality (it can be
        # negative — the stop sits below the flange in the default).
        slot_bottom = spacing - thk / 2
    """

    def build(self):                                       # framework hook: required; returns the shape
        upper = Sector(r=self.outer_diameter / 2, angles=(0, 180))
        lower = Sector(r=self.inner_diameter / 2, angles=(180, 360))
        paddle_2d = difference(union(upper, lower), circle(d=self.hole_d))
        paddle = paddle_2d.linear_extrude(height=self.thk)
        return paddle.up(self.slot_bottom).red()


class StopHolder(Component):
    """Two-sided clamp around a waterhouse stop. Upper and lower grippers
    flank the slot symmetrically along z; both pinch the stop's lower-ID
    semicircle from outside the slot. Each gripper has its own outer
    diameter so the holder can sit in a section where the local wall OD
    differs above vs. below the stop (e.g. when the stop lands inside the
    expansion funnel). When `od_top == od_bot` the result matches a
    uniform-OD section. ID is shared across both grippers since the disc
    they pinch is one diameter regardless of where it sits."""

    stop = Param(Stop)
    equations = """
        od_top, od_bot, grip_depth, grip_width, barrel_id > 0
        barrel_id > grip_depth
    """

    def build(self):                                       # framework hook: required; returns the shape
        s = self.stop
        slot_h = s.thk + s.clr
        half_gw = 0.5 * self.grip_width
        upper = Tube(
            h=half_gw, od=self.od_top, id=self.barrel_id - self.grip_depth,
        ).up(slot_h / 2)
        lower = Tube(
            h=half_gw, od=self.od_bot, id=self.barrel_id - self.grip_depth,
        ).down(slot_h / 2 + half_gw)
        return union(upper, lower).up(s.spacing).green()


class TruncFilletRing(Component):
    """A `FilletRing` with its sharp apex chopped to a flat rim of
    `rim_width` radial width."""

    equations = """
        id, od, base_angle, rim_width > 0
        base_angle < 90
        id < od
        rim_width < (od - id) / 2
        ?slant:str = ?slant or "outwards"
        slant in ("outwards", "inwards")
        h_full = tan(base_angle) * (od - id) / 2
        z_t = tan(base_angle) * ((od - id) / 2 - rim_width)
    """

    # Conical anchor for the inner slanted surface (slant="inwards" only:
    # the inner cone widens from id/2 at z=0 to (od/2 - rim_width) at z=z_t).
    # Lets add_text() wrap a label around the sloped face.
    slanted_face = anchor(
        at="(id + od - 2*rim_width) / 4.0, 0, z_t / 2",
        normal=(-1.0, 0.0, 0.0),
        kind="conical",
        surface_params={
            "axis": (0.0, 0.0, 1.0),
            "r1": "id / 2.0",
            "r2": "(od - 2*rim_width) / 2.0",
            "length": "z_t",
            "inner": True,
        },
    )

    def build(self):                                       # framework hook: required; returns the shape
        # Radial eps: the chopper's outer cylindrical surface sits at d=od, same
        # as the FilletRing's outer wall. through() handles planar-bbox coplanar
        # faces but not cylinder-on-cylinder coincidence, so nudge the chopper
        # outward by a hair.
        eps = 0.01
        base = FilletRing(id=self.id, od=self.od, base_angle=self.base_angle, slant=self.slant)
        chopper = cylinder(
            h=self.h_full - self.z_t, d=self.od + 2 * eps,
        ).up(self.z_t).through(base, axis="z")
        return difference(base, chopper)

    def tight_bbox(self):                                  # framework hook: declare true post-truncation extents
        # Default tight_bbox would walk into our top-level Difference and
        # raise. We know the truth: the chopper removes the apex from
        # z_t to h_full, so the truncated rim's actual top is at z=z_t
        # (not h_full as the conservative bbox would say).
        r = self.od / 2
        return BBox(min=(-r, -r, 0), max=(r, r, self.z_t))

    def prefers_shift_at_anchor(self, anchor) -> bool:
        # Same rationale as the standard-library `FilletRing`: our bottom
        # annular cap exactly matches the host wall's top face, so the
        # framework's `cross_section_extend` slab is itself coplanar with
        # the host's outer cylinder and CGAL leaves non-manifold edges.
        # Opt the planar top/bottom anchors into `bond='shift'` so
        # `.attach(host, fuse=True)` resolves to the shift path. The
        # eps drift on the opposite face is invisible on a fillet rim.
        if anchor.kind != "planar":
            return False
        return abs(anchor.normal[2]) > 1.0 - 1e-9


class LensHousing(Component):
    """Generic lens barrel: lower recess + flange + upper housing (narrow
    or funnel-widened) + element holders + front fillet. A matching hood
    Component can read the outer dimensions and hood cone angle off this
    housing to mate without shared scope."""

    FRONT_FILLET_OFFSET = 5.0   # aperture rim inset from the front element's grip ID

    stop = Param(Stop, default=None)
    mating_disc = Param(MatingDisc, default=None)
    mating_disc_tabs = Param(MatingDiscTabs, default=None)
    mating_disc_bead = Param(MatingDiscBead, default=None)
    helicoid_focus_slot = Param(HelicoidFocusSlot, default=None)
    aperture_feeler_slot = Param(ApertureFeelerSlot, default=None)
    equations = """
        # Wall-thickness split: the lower (M57-fit) section needs to fit
        # inside the camera's stepped M57 throat — its OD is constrained
        # from above by camera-body geometry at each axial step. The lower
        # housing is therefore three stacked segments (outer/mid/inner,
        # flange-side to deepest), each with its own OD and wall. The
        # flange-flange/funnel/upper section sits outside the camera body
        # and is wide enough to host a stepped lap joint internally —
        # typically a thick (~5 mm radial) wall, independent of the lower
        # segments because it's constrained by different physical realities.
        hood_base_angle = 90 - fov_angle / 2
        lower_outer_od, lower_outer_len, lower_outer_thk > 0
        lower_mid_od,   lower_mid_len,   lower_mid_thk   > 0
        lower_inner_od, lower_inner_len, lower_inner_thk > 0
        upper_barrel_thk > 0
        # Bore-side fillet ring angle (from horizontal). 45° is the
        # self-supporting threshold for FDM overhangs; steeper (more
        # vertical, larger angle here) is easier to print but consumes
        # more axial extent inside the wider segment.
        bore_fillet_base_angle > 0
        bore_fillet_base_angle <= 90
        flange_flange_od, flange_flange_len, fov_angle, hood_base_angle > 0
        grip_depth, grip_width > 0
        mount_offset >= 0
        # Alignment-groove cross-section: V-prism cut into the bottom
        # face of the upper housing at the stop-slot's angular position
        # (+Y in housing frame). Width = chord on the surface; depth =
        # how far the apex pokes into the upper-housing material.
        alignment_groove_depth, alignment_groove_width > 0
        # Segment IDs derived from each segment's OD and wall thickness.
        lower_outer_id = lower_outer_od - 2 * lower_outer_thk
        lower_mid_id   = lower_mid_od   - 2 * lower_mid_thk
        lower_inner_id = lower_inner_od - 2 * lower_inner_thk
        # Stepped-bore monotonicity: the throat narrows as we go deeper, so
        # each segment's ID must be no greater than the segment above it.
        lower_outer_id >= lower_mid_id
        lower_mid_id   >= lower_inner_id
        # Axial layout. Outer spans the flange-side step and extends above
        # the flange into the mount-ring zone (so it ends at mount_offset);
        # mid and inner stack below, into the throat. All three lengths
        # measure axial extent.
        lower_outer_z_top = mount_offset
        lower_outer_z_bot = -lower_outer_len
        lower_mid_z_top   = lower_outer_z_bot
        lower_mid_z_bot   = lower_mid_z_top - lower_mid_len
        lower_inner_z_top = lower_mid_z_bot
        lower_inner_z_bot = lower_inner_z_top - lower_inner_len
        # `housing_insertion_depth` is the total depth past the flange the
        # lower segments occupy; `lower_housing_len` is the full lower-tube
        # length including the above-flange mount-ring portion that outer
        # carries.
        housing_insertion_depth = lower_outer_len + lower_mid_len + lower_inner_len
        lower_housing_len = housing_insertion_depth + mount_offset
        unconstricted = tuple(e for e in elements:tuple if not e.constricted)
        max_upper_ele_dia = max((e.dia for e in unconstricted), default=0.0)
        # Bore at the funnel base (top of the lower section) is outer's ID.
        is_wide = max_upper_ele_dia > lower_outer_id
        expansion_funnel_len = min((e.face_z_bot for e in unconstricted), default=inf)
        upper_housing_len = max(e.face_z_top for e in elements)
        upper_housing_od = (max_upper_ele_dia + 2 * upper_barrel_thk) if is_wide else flange_flange_od
        # Per-element fit: the bore only narrows with depth, so the deepest
        # point an element reaches (its face_z_bot) determines the binding
        # segment.
        all(
            not e.constricted
            or e.throat_dia_required <= (
                lower_outer_id if e.face_z_bot >= lower_outer_z_bot
                else lower_mid_id if e.face_z_bot >= lower_mid_z_bot
                else lower_inner_id
            )
            for e in elements
        )
        # Wide-mode invariant: in funnel variants the funnel runs from
        # mount_offset (the top of the mount-ring zone, where the lower
        # tube ends) to expansion_funnel_len (the bottom of the lowest
        # unconstricted element). The funnel needs positive height, so the
        # lowest unconstricted element must sit strictly above the mount-
        # ring zone. (`element()` now defines constricted as face_z_bot <
        # mount_offset, so unconstricted elements have face_z_bot >=
        # mount_offset; this rule guards the equality edge case.)
        not is_wide or expansion_funnel_len > mount_offset
        # Stop slot must lie entirely in a section we can handle:
        #   (a) below the flange-flange (z <= mount_offset) — uniform
        #       lower-housing OD;
        #   (b) above the flange/funnel transition — uniform upper-
        #       housing OD;
        #   (c) (wide variant only) entirely within the funnel range
        #       [mount_offset, expansion_funnel_len] — handled by the
        #       per-gripper-OD logic in `wall_od_at_z` and the StopHolder
        #       od_top/od_bot pair.
        # The flange-overlap and mount-ring/flange transition zones stay
        # forbidden because they have a wall-OD discontinuity no cylindrical
        # gripper can span. The `?stop` references make these lines auto-
        # skip when no stop is supplied.
        slot_lo = ?stop.spacing - (stop.thk + stop.clr) / 2
        slot_hi = ?stop.spacing + (stop.thk + stop.clr) / 2
        upper_floor = expansion_funnel_len if is_wide else mount_offset + flange_flange_len
        ?slot_hi <= mount_offset or slot_lo >= upper_floor or (is_wide and slot_lo >= mount_offset and slot_hi <= expansion_funnel_len)
    """

    def _sections(self):
        """List of `HousingSection` Components describing the housing's
        wall geometry. Order doesn't matter — sections may overlap in z
        (e.g. flange + funnel in wide mode where the flange's wider OD
        wins). The single source of truth for both `build()` and
        `wall_od_at_z`.

        The lower housing is three stacked segments — outer (flange-side,
        widest, continues into the mount-ring zone above the flange), mid
        (intermediate, carries the helicoid focus slot), inner (deepest,
        narrowest). The flange-flange wall sits on top of outer, and the
        mating disc (if present) wraps outer."""
        outer_id = self.lower_outer_id
        outer_od = self.lower_outer_od
        mo = self.mount_offset
        flange_top = mo + self.flange_flange_len
        sections = [
            # Lower outer: from the outer/mid step up through the flange
            # plane into the mount-ring zone (z_top = mount_offset). The
            # flange-flange and (in narrow mode) the upper tube continue
            # this OD upward.
            HousingSection(
                z_bot=self.lower_outer_z_bot, z_top=self.lower_outer_z_top,
                bot_id=outer_id, top_id=outer_id,
                thk=self.lower_outer_thk,
            ),
            # Lower mid: middle step. Carries the helicoid focus slot.
            HousingSection(
                z_bot=self.lower_mid_z_bot, z_top=self.lower_mid_z_top,
                bot_id=self.lower_mid_id, top_id=self.lower_mid_id,
                thk=self.lower_mid_thk,
            ),
            # Lower inner: deepest step. The helicoid slot does NOT enter
            # this segment (the cutter is bounded above by the mid/inner
            # boundary).
            HousingSection(
                z_bot=self.lower_inner_z_bot, z_top=self.lower_inner_z_top,
                bot_id=self.lower_inner_id, top_id=self.lower_inner_id,
                thk=self.lower_inner_thk,
            ),
            # Bore fillet at the outer/mid step. Sits inside outer just
            # above the step plane; closes the (small) wall-overlap and
            # gives the bore a self-supporting slope for print.
            FilletSection(
                z_bot=self.lower_outer_z_bot,
                bot_id=self.lower_mid_id,
                top_id=self.lower_outer_id,
                base_angle=self.bore_fillet_base_angle,
            ),
            # Bore fillet at the mid/inner step. Without this the inner
            # wall doesn't touch mid's wall — there's a 1 mm radial gap
            # at the step plane.
            FilletSection(
                z_bot=self.lower_mid_z_bot,
                bot_id=self.lower_inner_id,
                top_id=self.lower_mid_id,
                base_angle=self.bore_fillet_base_angle,
            ),
            # Flange-flange: thicker wall sitting on top of the mount ring.
            # Bore matches outer (its lower neighbor).
            HousingSection(
                z_bot=mo, z_top=flange_top,
                bot_id=outer_id, top_id=outer_id,
                thk=(self.flange_flange_od - outer_id) / 2,
            ),
        ]
        if self.is_wide:
            # Funnel widens the bore from outer's ID to the largest
            # unconstricted element; its wall uses upper_barrel_thk.
            # Overlaps the flange in z=[mo, flange_top]; in wall_od_at_z
            # the flange's wider OD wins via max() across containing
            # sections.
            sections.append(HousingSection(
                z_bot=mo, z_top=self.expansion_funnel_len,
                bot_id=outer_id, top_id=self.max_upper_ele_dia,
                thk=self.upper_barrel_thk,
            ))
            # Upper (above the funnel): uniform wide bore.
            sections.append(HousingSection(
                z_bot=self.expansion_funnel_len, z_top=self.upper_housing_len,
                bot_id=self.max_upper_ele_dia, top_id=self.max_upper_ele_dia,
                thk=self.upper_barrel_thk,
            ))
        else:
            # Non-wide upper: continues outer's bore at the flange-flange OD.
            sections.append(HousingSection(
                z_bot=flange_top, z_top=self.upper_housing_len,
                bot_id=outer_id, top_id=outer_id,
                thk=(self.upper_housing_od - outer_id) / 2,
            ))
        if self.mating_disc is not None:
            # Mating disc: extra ring on the housing's outer surface
            # bridging the gap to the lens-mount ring's bore. ID =
            # lower_outer_od (wraps outer concentrically); OD and z range
            # come from the MatingDisc spec.
            md = self.mating_disc
            sections.append(HousingSection(
                z_bot=md.z_bot, z_top=md.z_top,
                bot_id=outer_od, top_id=outer_od,
                thk=(md.od - outer_od) / 2,
            ))
        return sections

    def wall_od_at_z(self, z):
        """Outer-wall diameter at axial position z. Used to size each
        stop-holder gripper to its local wall thickness so a gripper
        that lands in a narrowing funnel doesn't poke out past the wall.
        Returns the max OD across all sections containing z (overlapping
        sections — flange + funnel in wide mode — resolve via max)."""
        matching = [s for s in self._sections() if s.z_bot <= z <= s.z_top]
        if not matching:
            return 0.0
        return max(s.od_at(z) for s in matching)

    def wall_id_at_z(self, z):
        """Inner bore diameter at axial position z. Used to size the
        stop disc and the gripper's inner cylinder to the local bore,
        so the disc fills the bore and the gripper intrudes only
        `grip_depth/2` into the optical path regardless of which
        section the stop lands in. Overlapping sections resolve via
        MIN — wall material lives wherever any section has material,
        so the bore is bounded by the narrowest inner radius at z."""
        matching = [s for s in self._sections() if s.z_bot <= z <= s.z_top]
        if not matching:
            return 0.0
        return min(s.id_at(z) for s in matching)

    def _front_fillet(self):
        """Build the same TruncFilletRing instance used in `build()`,
        so its tight_bbox / equations are usable from here without
        duplicating the construction args."""
        front_ele = max(self.elements, key=lambda e: e.spacing)
        return TruncFilletRing(
            id=front_ele.dia - self.grip_depth + self.FRONT_FILLET_OFFSET,
            od=self.upper_housing_od,
            base_angle=self.hood_base_angle,
            slant="inwards",
            rim_width=2,
        )

    def _swept_slot_cutter(self, slot, wall_od):
        """Generic curved-bar cutter for a swept slot (helicoid focus
        slot or aperture feeler slot). One shell `slot.depth` mm thick
        (radially, from `wall_od/2` inward), intersected with a wedge
        that covers both the locked-side arc (centered at `slot.angle`,
        `slot.width` wide at `wall_od`) and the sweep arc (extending CW
        from `slot.angle` by `sweep_arc_deg`). Single uniform depth —
        the pin/feeler rides the groove throughout the bayonet rotation;
        nothing needs a full through-cut.

        The shell's outer cylinder pokes past the wall OD by a small
        delta for a clean exterior cut. `slot.bottom_overshoot` extends
        the cutter past `z_bot` axially — set this when the slot's deep
        end sits exactly on a segment boundary (e.g. the helicoid slot's
        z_bot at the mid/inner step) to drop the coplanar bottom face
        and avoid a rendering sliver. Leave it 0 when the slot's deep
        end is in the segment interior."""
        import math
        s = slot
        outer_delta = 0.1                     # past OD; just for clean exterior cut
        h = (s.z_top - s.z_bot) + s.bottom_overshoot
        outer_r = wall_od / 2 + outer_delta
        inner_r = wall_od / 2 - s.depth
        # Angular half-width = (arc / 2) / radius, in degrees. Use the
        # segment OD as the reference radius so `width` reads as the
        # arc length along the visible outer face.
        half_arc_deg = math.degrees((s.width / 2) / (wall_od / 2))
        shell = Tube(h=h, od=2 * outer_r, id=2 * inner_r)
        # Wedge angular extent: swept convex hull of the pin/feeler at
        # LOCK (centered at `slot.angle`, ±half_arc_deg wide) and at
        # INSERTION (centered at `slot.angle − sweep_arc_deg`, also
        # ±half_arc_deg wide). The pin/feeler width contributes half_arc
        # on BOTH sides — locked-side (CCW of `slot.angle`) and
        # insertion-side (CW of `slot.angle − sweep_arc_deg`). Sector
        # `angles=(a, b)` sweeps CCW from a to b.
        wedge = Sector(
            r=outer_r,
            angles=(
                s.angle - s.sweep_arc_deg - half_arc_deg,
                s.angle + half_arc_deg,
            ),
        ).linear_extrude(height=h)
        return intersection(shell, wedge).up(s.z_bot - s.bottom_overshoot)

    def _alignment_groove_cutter(self):
        """V-prism cutter for the alignment groove on the bottom face
        of the upper housing. Sits at theta=90° (housing-frame +Y, the
        stop-slot's angular position) so that when the lens locks to the
        camera both end up pointing straight up in camera-frame. Cross-
        section is a triangle of base `alignment_groove_width` and depth
        `alignment_groove_depth`, base on the bottom face (z=mount_offset)
        and apex up into the flange-flange. Extends radially from just
        inside the mating disc's OD out past the flange-flange's OD."""
        gw = self.alignment_groove_width
        gd = self.alignment_groove_depth
        r_inner = self.mating_disc.od / 2
        r_outer = self.flange_flange_od / 2
        overshoot = 0.5
        # Triangle built in the 2D X-Y plane with apex at +Y. Base sits
        # below Y=0 by `overshoot` so the cutter opens past the bottom
        # face for a clean exterior cut.
        tri = polygon(points=[
            (-gw / 2, -overshoot),
            (gw / 2, -overshoot),
            (0, gd),
        ])
        # Extrude in Z, then rotate so Z (extrusion) becomes the radial
        # +Y direction and Y (apex) becomes axial +Z. After rotate
        # [90,0,0]: original Y→Z, original Z→-Y, so the extrusion runs
        # from Y=0 toward -Y. Translating by +(r_outer + overshoot) in
        # Y lands the prism spanning Y ∈ [r_inner − overshoot, r_outer + overshoot].
        # Translating up by mount_offset puts the base on the bottom
        # face (with the overshoot poking past it).
        length = (r_outer - r_inner) + 2 * overshoot
        return (
            tri.linear_extrude(height=length)
            .rotate([90, 0, 0])
            .translate([0, r_outer + overshoot, self.mount_offset])
        )

    def _mating_disc_tabs_geometry(self):
        """Tabs protruding radially outward from the mating disc's OD.

        Each tab is a parallel-sided box (not an angular wedge): in the
        tab's local frame +X is radial outward at the tab's center
        angle, +Y is tangential. The box spans
          x ∈ [disc_r − fuse_eps, disc_r + tabs.radial]
          y ∈ [−tabs.circumferential/2, +tabs.circumferential/2]
          z ∈ [tabs.z_top − tabs.axial, tabs.z_top]
        rotated to each angle in `tabs.angles_deg` (housing-frame).
        Parallel sides ensure a precise fit against a matching pocket
        in the lens-mount ring's bore wall (the ring's notch is the
        same shape, larger by `tabs.clearance` on every face).
        """
        tabs = self.mating_disc_tabs
        disc_r = self.mating_disc.od / 2
        fuse_eps = 0.1
        rect = polygon(points=[
            (disc_r - fuse_eps, -tabs.circumferential / 2),
            (disc_r + tabs.radial, -tabs.circumferential / 2),
            (disc_r + tabs.radial, +tabs.circumferential / 2),
            (disc_r - fuse_eps, +tabs.circumferential / 2),
        ])
        z_bot = tabs.z_top - tabs.axial
        one_tab = rect.linear_extrude(height=tabs.axial).up(z_bot)
        return union(*(one_tab.rotate([0, 0, theta]) for theta in tabs.angles_deg))

    def _mating_disc_bead_geometry(self):
        """Snap-fit bead around the mating disc's OD. Continuous 360°
        triangular ridge: apex at radius disc_r + bead.height, base
        flush with the disc OD over an axial span of bead.axial,
        centered at bead.z_center. Built as a 2D triangle in the
        (radial, axial) plane (= xy in the polygon, x → radial, y →
        axial), rotate-extruded around the z axis.
        """
        bead = self.mating_disc_bead
        disc_r = self.mating_disc.od / 2
        half_w = bead.axial / 2
        # The base sits on the disc OD; sample the inner edge slightly
        # inside the disc (- fuse_eps) so the union with the disc
        # closes cleanly without a coplanar face.
        fuse_eps = 0.05
        cross = polygon(points=[
            (disc_r - fuse_eps, bead.z_center - half_w),
            (disc_r + bead.height, bead.z_center),
            (disc_r - fuse_eps, bead.z_center + half_w),
        ])
        return cross.rotate_extrude()

    def tight_bbox(self):                                  # framework hook: declare true post-Difference extents
        # Default tight_bbox would walk into the slot's `difference()`
        # and raise. The slot is fully contained within the barrel, so
        # it doesn't change outer extents. Compute the true envelope
        # from the wall sections (max OD across all of them) plus the
        # front fillet's truncated rim height (read from the fillet's
        # own equation-derived z_t — no math duplication).
        sections = self._sections()
        max_r = max(
            max(s.od_at(s.z_bot) for s in sections),
            max(s.od_at(s.z_top) for s in sections),
        ) / 2
        min_z = -self.housing_insertion_depth
        max_z = self.upper_housing_len + self._front_fillet().z_t
        return BBox(min=(-max_r, -max_r, min_z), max=(max_r, max_r, max_z))

    def build(self):
        # Above the flange the bore is uniform (outer continues through
        # the mount-ring zone, then the flange-flange/funnel/upper take
        # over), so `upper_id` is one value. Below the flange the bore
        # steps through outer/mid/inner; constricted-element holders pick
        # their OD from the local wall bore via `wall_id_at_z(spacing)`
        # so each holder sits cleanly inside the segment containing it.
        upper_id = self.max_upper_ele_dia if self.is_wide else self.lower_outer_id

        # Wall sections: outer / mid / inner / flange-flange / (funnel /
        # upper) / optional mating disc. Single source of truth
        # (`_sections()`) used by both this build and `wall_od_at_z`.
        sections = self._sections()
        # Bare barrel — engravings are no longer part of build() so the
        # force_render scope in the variant chain caches just the
        # structural mesh. See `engravings()` for the cutter geometry
        # and the variant methods for where it's applied.
        barrel = union(*sections)

        # Slot OD: the maximum housing OD at the slot's z range. In the
        # uniform-OD allowed bands this is just the local OD; in the
        # funnel band the slot's TOP has the largest local OD (funnel
        # widens upward), so we use that. +1 mm radial overshoot avoids
        # cylinder-on-cylinder coplanar faces in the difference.
        if self.stop is not None:
            s = self.stop
            slot_h = s.thk + s.clr
            half_gw = 0.5 * self.grip_width
            slot_od = self.wall_od_at_z(s.spacing + slot_h / 2)
            slot_id = self.wall_id_at_z(s.spacing) - 0.1
            slot = Tube(
                h=slot_h, od=slot_od + 1, id=slot_id,
            ).halve([0, 1, 0]).up(s.spacing - slot_h / 2)
            barrel = difference(barrel, slot)

        if self.helicoid_focus_slot is not None:
            barrel = difference(
                barrel,
                self._swept_slot_cutter(self.helicoid_focus_slot, self.lower_mid_od),
            )
        if self.aperture_feeler_slot is not None:
            barrel = difference(
                barrel,
                self._swept_slot_cutter(self.aperture_feeler_slot, self.lower_inner_od),
            )

        barrel = difference(barrel, self._alignment_groove_cutter())

        if self.mating_disc_tabs is not None and self.mating_disc is not None:
            barrel = union(barrel, self._mating_disc_tabs_geometry())

        if self.mating_disc_bead is not None and self.mating_disc is not None:
            barrel = union(barrel, self._mating_disc_bead_geometry())

        yield barrel

        for e in self.elements:
            # Constricted elements sit inside the stepped lower bore, so
            # pick the holder OD from the local wall ID at the element's
            # center — the holder mates with whatever segment contains it.
            # Unconstricted elements live above the flange where the bore
            # is uniform.
            holder_od = self.wall_id_at_z(e.spacing) if e.constricted else upper_id
            # Known limitation (wide variants only): when an unconstricted
            # element's dia equals max_upper_ele_dia, holder_od == its
            # own dia and the holder's surround tube has thk =
            # -e.clearances.radial/2 (negative). The fix is to size the
            # widest element's holder off upper_housing_od (wall outer)
            # rather than upper_id (wall inner == element dia). Leaving
            # as a follow-up.
            yield ElementHolder(
                element=e, od=holder_od,
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        if self.stop is not None:
            # Per-gripper OD: each gripper's outer cylinder is sized to
            # the local wall OD at the gripper's BOTTOM (the narrowest
            # point in its z extent for an upward-widening funnel), so
            # the gripper is fully embedded in wall material with no
            # radial overshoot anywhere along its height.
            upper_z_bot = s.spacing + slot_h / 2
            lower_z_bot = s.spacing - slot_h / 2 - half_gw
            yield StopHolder(
                stop=self.stop,
                od_top=self.wall_od_at_z(upper_z_bot),
                od_bot=self.wall_od_at_z(lower_z_bot),
                barrel_id=self.wall_id_at_z(s.spacing),
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        yield self._front_fillet().attach(barrel, fuse=True)

    def engravings(self):
        """Cutter geometry for the two engravings, in housing-local frame.

        Returned as a single union so a variant chain can apply
        ``difference(housing.force_render(), housing.engravings())``
        and keep the per-glyph CGAL work out of the cached subtree.

        - Upper-housing label: text on the topmost uniform section's
          ``outer_wall``. Picks the same section ``build()`` would have
          decorated (``z_top == upper_housing_len`` and uniform OD).
        - Front-fillet label: text on the truncated fillet's
          ``slanted_face``. Positioned with ``.up(upper_housing_len)``
          to match where ``attach(barrel, fuse=True)`` lands the fillet
          in ``build()`` (sub-mm fuse offset is below engraving tolerance)."""
        upper_section = next(
            s for s in self._sections()
            if s.z_top == self.upper_housing_len and s.bot_id == s.top_id
        )
        upper_label = "\n".join(
            [f"{design_name}:"]
            + [e.code for e in self.elements]
            + [print_stamp()]
        )
        upper_cutter = upper_section.text_geometry(
            label=upper_label, on="outer_wall", angle=0,
            font_size=4, line_spacing=1.4, relief=-0.6,
        )
        fillet_cutter = self._front_fillet().up(self.upper_housing_len).text_geometry(
            label=FRONT_FILLET_LABEL,
            on="slanted_face", angle=0,
            font_size=4, relief=-0.6,
        )
        return union(upper_cutter, fillet_cutter)


class LensHood(Component):
    """Generic clip-on hood sized by a paired housing. `housing_upper_od`
    and `hood_base_angle` come from the housing; the rest are hood-specific.
    Built in its mounted orientation: coupler at z=0, funnel flaring upward.
    The print variant flips it."""

    equations = """
        housing_upper_od, hood_base_angle, wall_thk, hood_length, coupler_overlap > 0
        hood_clr >= 0
        id_coupler = housing_upper_od + hood_clr
        od_coupler = id_coupler + 2 * wall_thk
        flare_od = housing_upper_od + 2 * hood_length * tan(90 - hood_base_angle)
        # Optional raised-text label wrapped around the coupler's outer
        # wall. Empty string = no engraving. Applied directly to the
        # coupler Tube in build() (via `add_text` on Tube's built-in
        # `outer_wall` anchor) so the text wraps with the framework's
        # default cylindrical orientation: upright glyphs, line reading
        # L-to-R when viewed from outside, glyph bottoms toward -Z.
        ?label:str = ?label or ""
    """

    def build(self):                                       # framework hook: required; returns the shape
        coupler = Tube(
            h=self.coupler_overlap, id=self.id_coupler, thk=self.wall_thk,
        )
        if self.label:
            # at_z nudges the line axially. The framework pre-shifts the
            # text by -font_size/2 to "center" the line on the surface,
            # but that centers the full em-box; the visible cap body
            # (~0.7 * font_size) ends up biased toward -Z because the
            # descender space contributes to the shift without contributing
            # visible mass. at_z = (font_size - cap_height) / 2 ≈
            # 0.15 * font_size compensates so the cap body's centerline
            # sits at the anchor's z.
            coupler = coupler.add_text(
                label=self.label, on="outer_wall",
                font_size=4, relief=0.5,
                at_z=1.8,
            )
        yield coupler
        yield Funnel(
            h=self.hood_length, thk=self.wall_thk,
            bot_od=self.housing_upper_od, top_od=self.flare_od,
        ).attach(coupler, fuse=True)
        yield FilletRing(
            id=self.id_coupler, od=self.od_coupler,
            base_angle=63, slant="inwards",
        ).attach(coupler, fuse=True)


def _lap_split_x_tight_bbox(child, *, side, overlap, clearance=0.0, **_):
    """tight_bbox hook for `lap_split_x`. The transform's body builds a
    top-level Difference (groove subtracted from union(half, tongue)),
    which the framework's bbox visitor can't tighten on its own. We know
    the answer: the result keeps one X half of the housing plus a
    `tongue_w = overlap - clearance` tongue extending past the cut plane
    on the other side. Z and Y are unchanged from the child."""
    from scadwright import tight_bbox as _tb
    cb = _tb(child)
    tongue_w = overlap - clearance
    if side == "minus":
        return BBox(min=cb.min, max=(tongue_w, cb.max[1], cb.max[2]))
    return BBox(min=(-tongue_w, cb.min[1], cb.min[2]), max=cb.max)


@transform("lap_split_x", tight_bbox=_lap_split_x_tight_bbox)
def lap_split_x(node, *, side, overlap, mid_radius, z_min=None, clearance=0.0):
    """Halve the host shape at X=0 with a stepped lap joint of depth `overlap`
    at radial position `mid_radius`. `side` is 'minus' (keep X<=0) or
    'plus' (keep X>=0). The 'minus' and 'plus' results mate INVERSELY
    across the cut plane (not as mirror images): one carries the outer
    extension and the inner recess; the other carries the matching outer
    recess and inner extension.

    Specifically:
      - minus keeps X<=0; its OUTER layer (r >= mid_radius) is extended
        past X=0 into +X by `overlap` (tongue), and its INNER layer
        (r < mid_radius) is recessed from X=0 in -X by `overlap` (groove).
      - plus keeps X>=0; its OUTER layer is recessed (groove) at +X for
        `overlap` mm to receive minus's outer tongue, and its INNER layer
        is extended into -X by `overlap` (tongue) to fill minus's inner
        groove.

    Joint planes therefore land at X=+overlap (outer layer) and at
    X=-overlap (inner layer). Light path between bore and outer surface
    zigzags through the step — light-tight. The step constrains relative
    XY position — self-aligning. Mates by pure X-translation (radial
    press-fit), no axial sliding required.

    `mid_radius` must lie inside the wall everywhere along Z (between
    the bore and the outer wall in every section), or the layers will
    have zero thickness somewhere.

    `z_min` (optional) confines the lap features to z >= z_min. Below
    z_min the housing is just cleanly halved at X=0 with no lap geometry
    — useful when the wall is too thin to host the step (e.g. the M57-fit
    section of a lens housing).

    `clearance` (mm) shrinks the tongue (NOT the groove) so the press
    seats with some play. The shrink is applied two ways: tongue X-extent
    is shorter by `clearance` at the TIP (gives axial seating play); the
    tongue's step-face boundary is pulled away from `mid_radius` by
    `clearance` (gives radial play at the step inside the joint). The
    tongue's outer-cylinder surface (or bore surface for the inner
    tongue) is unchanged so the visible cylinder surface flushes at the
    joint. Default 0 (zero-clearance, may bind on tight prints).
    """
    if side not in ("minus", "plus"):
        raise ValueError(f"side must be 'minus' or 'plus', got {side!r}")
    sign = -1 if side == "minus" else 1
    # `halve()` would auto-size its cutter from the input shape's bbox.
    # As a hoisted custom transform, the shape arg here is a placeholder
    # (1x1x1) at module-build time, not the real housing — so we pass an
    # explicit `size` to suppress bbox introspection.
    big = 200.0
    half = node.halve([sign, 0, 0], size=big)

    # Slabs need only enclose the housing, not be globe-sized. Intersection
    # clips them to the wall geometry, so the step automatically conforms
    # to varying OD/ID along Z (e.g. the funnel transition in wide
    # variants). `big` is sized generously vs typical lens housings (a few
    # hundred mm in any axis), so any reasonable design is enclosed; the
    # exact value matters because OpenSCAD's preview mode draws the full
    # auxiliary geometry every frame and very large slabs cost real
    # interactivity. When z_min is set, the slab is anchored at z=z_min
    # (not Z-centered) so only z >= z_min material is included.
    z_centered = z_min is None
    z_axes = "yz" if z_centered else "y"

    def _slab(width):
        c = cube([width, big, big], center=z_axes)
        return c if z_centered else c.up(z_min)

    tongue_w = overlap - clearance
    # Groove: full overlap on the slab, mid_radius for the radial split.
    # Tongue: shorter slab (clearance at the tip) and the radial split is
    # pulled away from mid_radius by clearance (further out for an outer-
    # layer tongue, further in for an inner-layer tongue), giving the
    # tongue play at both the step face and the tip when seated.
    pos_groove_slab = _slab(overlap)                       # X in [0, overlap]
    neg_groove_slab = _slab(overlap).left(overlap)         # X in [-overlap, 0]
    pos_tongue_slab = _slab(tongue_w)                      # X in [0, tongue_w]
    neg_tongue_slab = _slab(tongue_w).left(tongue_w)       # X in [-tongue_w, 0]

    # `inner_volume` is the cylinder of radius `mid_radius` around Z;
    # outer-layer = node - inner_volume; inner-layer = node & inner_volume.
    # `fn=8` keeps the mask cheap to draw in OpenSCAD preview — the
    # cylinder is invisible in the final geometry, so its radial polygon
    # count doesn't affect output, only per-frame preview cost.
    inner_volume = cylinder(r=mid_radius, h=big, center="z", fn=8)
    inner_volume_outer_tongue = cylinder(r=mid_radius + clearance, h=big, center="z", fn=8)
    inner_volume_inner_tongue = cylinder(r=mid_radius - clearance, h=big, center="z", fn=8)

    if side == "minus":
        # Outer-layer tongue at +X, inner-layer groove at -X.
        tongue = difference(intersection(node, pos_tongue_slab), inner_volume_outer_tongue)
        groove = intersection(intersection(node, neg_groove_slab), inner_volume)
    else:  # plus
        # Inner-layer tongue at -X, outer-layer groove at +X.
        tongue = intersection(intersection(node, neg_tongue_slab), inner_volume_inner_tongue)
        groove = difference(intersection(node, pos_groove_slab), inner_volume)

    return difference(union(half, tongue), groove)


@transform("lap_splay")
def lap_splay(node, *, side, lap_overlap=0.0):
    """Lay one housing half flat on the print bed: rotate so the cut
    face lies parallel to the bed (cut-face-down) and lift the result
    by `lap_overlap` so the lap-joint tongue (which extends past the
    cut plane and would otherwise dip below Z=0 after the rotation)
    rests on the bed.

    `side` selects the rotation direction so the kept material lands
    above the bed regardless of which half was cut. `lap_overlap` is
    the same value passed to `.lap_split_x()`; it's explicit here because
    the framework's `bbox()` returns a conservative AABB across `halve`,
    so the actual minimum Z can't be derived from the splayed shape.
    Pass 0.0 if the half has no lap joint.
    """
    angle = 90 if side == "minus" else -90
    return node.rotate([0, angle, 0]).up(lap_overlap)


# =============================================================================
# CONCRETE: the specific M57 design
# =============================================================================


GRIP_DEPTH = 1.5
GRIP_WIDTH = 1.0

# Bayonet contract — single source of truth for dimensions shared with
# the lens mount. The housing reads three values from `BronicaS2Bayonet`:
#   - mount_protrusion: axial extent of the lens-mount ring above the
#     camera flange (z=[0, mount_protrusion]). The M57-restricted lower
#     tube extends up to this z; the flange-flange rests on top of the
#     ring; the funnel starts here with a sharper angle so the housing
#     stays the same total length and no elements move in absolute z.
#   - lens_mount_od: OD of the lens-mount ring; sets `flange_flange_od`
#     so the two parts rest flush at the assembly seam.
#   - lens_mount_bore: inner bore of the ring; the mating disc fits
#     inside it (with MATING_DISC_CLEARANCE slip).
# Local alias for the most-used value — variant code stays readable.
MOUNT_OFFSET = BronicaS2Bayonet.mount_protrusion

# MATING_DISC_CLEARANCE is imported above from housing_lock_spec so both
# the housing (sizing the mating disc OD) and the locking ring (sizing
# the tab-notch cutout relative to the disc edge) agree on one value.

# Waterhouse stop: 1.5mm disc, 0.5mm slot clearance for sliding fit.
# Depth and hole-diameter list come from the design (defaults below or
# loaded from --config).
STOP_THK = 1.5
STOP_CLR = .5

# Built-in defaults (used unless --from-json overrides). Front to rear.
# `mounted_od` is optional and only applies to the element that carries it
# (its mount/cell is wider than the bare lens); the housing uses
# max(diameter, mounted_od) for clearance on those elements.
# `extra_radial` (mm) is added on top of DEFAULT_ELEMENT_CLEARANCES.radial
# for that element's holder — looser fit for elements whose OD measures
# slightly larger than the catalog dia or whose edge profile chips into
# the surround. Default 0 (use the project-wide radial clearance as-is).
DEFAULT_ELEMENTS_DATA = (
    {"code": "L7325",  "type": "NMN", "diameter": 52.0, "edge_thickness": 6.2, "spacing":  34.6, "extra_radial": 0.3, "extra_axial": -0.1},
    {"code": "L14523", "type": "ACH", "diameter": 35.0, "mounted_od": 44.4, "edge_thickness": 13, "spacing":  12.6, "extra_radial": 0.8},
    {"code": "L13088", "type": "BCX", "diameter": 42.5, "edge_thickness":  2.2, "spacing":  -9.4, "extra_radial": 0.3, "extra_axial": 0.1},
)
DEFAULT_STOP_DEPTH = -2.7
DEFAULT_STOP_HOLE_D = (20.0, 14.3, 10.0, 7.3)
DEFAULT_FOV_ANGLE = 57.0
DEFAULT_FOCAL_LENGTH = 89
DEFAULT_MAX_APERTURE = 2.9
DEFAULT_DESIGN_NAME = "lens_housing"


# Optional design override: invoke with `--from-json <path>`. The JSON
# carries `elements` (list of element dicts) and `stop` (dict with `depth`
# and `hole_diameters`); optionally `fov` (hood half-angle source), `name`
# (design label, surfaced as `design_name` for downstream use), and
# `focal_length` / `max_aperture` (engraved on the front fillet ring).
# Missing required keys surface as KeyError when the data is consumed
# below; the framework absorbs file-not-found / invalid-JSON at parse time.
_cfg = from_json()
if _cfg is not None:
    _elements_data = _cfg["elements"]
    STOP_DEPTH = float(_cfg["stop"]["depth"])
    STOP_HOLE_D = tuple(float(d) for d in _cfg["stop"]["hole_diameters"])
    FOV_ANGLE = float(_cfg.get("fov", DEFAULT_FOV_ANGLE))
    design_name = _cfg.get("name", DEFAULT_DESIGN_NAME)
    FOCAL_LENGTH = float(_cfg.get("focal_length", DEFAULT_FOCAL_LENGTH))
    MAX_APERTURE = float(_cfg.get("max_aperture", DEFAULT_MAX_APERTURE))
else:
    _elements_data = DEFAULT_ELEMENTS_DATA
    STOP_DEPTH = DEFAULT_STOP_DEPTH
    STOP_HOLE_D = DEFAULT_STOP_HOLE_D
    FOV_ANGLE = DEFAULT_FOV_ANGLE
    design_name = DEFAULT_DESIGN_NAME
    FOCAL_LENGTH = DEFAULT_FOCAL_LENGTH
    MAX_APERTURE = DEFAULT_MAX_APERTURE

FRONT_FILLET_LABEL = f"BRIOTAR {FOCAL_LENGTH:g}mm f/{MAX_APERTURE:g}"

def _effective_dia(e):
    """Use the mount OD when wider than the bare lens; bare diameter otherwise."""
    d = float(e["diameter"])
    if "mounted_od" in e:
        return max(d, float(e["mounted_od"]))
    return d


def _element_clearances(e):
    """Per-element clearances. Starts from the project default and adds
    the dict's `extra_radial` (a DIAMETER delta — `clearances.radial`
    is added directly to the element diameter to get the holder's bore,
    so the actual per-side radial gap is `radial / 2`). Axial uses the
    default; override per-element with an `extra_axial` key if a future
    element needs it."""
    return ElementClearances(
        axial=DEFAULT_ELEMENT_CLEARANCES.axial + float(e.get("extra_axial", 0)),
        radial=DEFAULT_ELEMENT_CLEARANCES.radial + float(e.get("extra_radial", 0)),
    )


ELEMENTS = tuple(
    element(
        code=e["code"], type=e["type"],
        dia=_effective_dia(e), edge_thk=float(e["edge_thickness"]),
        spacing=float(e["spacing"]),
        grip_width=GRIP_WIDTH,
        mount_offset=BronicaS2Bayonet.mount_protrusion,
        clearances=_element_clearances(e),
    )
    for e in _elements_data
)
THE_STOP = Stop(spacing=STOP_DEPTH, thk=STOP_THK, clr=STOP_CLR)


# Stepped lap joint between the two printed housing halves. Confined to
# z >= MOUNT_OFFSET (the lap_split z_min in `_splayed_halves` below), so
# it only runs through the flange-flange / funnel / upper sections — the
# thin-walled stepped lower segments below the flange get a clean halve
# only. The upper wall is thick enough (5 mm radial) to host the step
# internally with both layers >=2.5 mm thick everywhere; no external rib
# needed. `LAP_MID_RADIUS = 29.5` sits roughly midway between the upper-
# section bore (r ≈ 26.5, set by outer's ID continued upward) and the
# flange/funnel/upper OD (r ≈ 31–34, depending on element widths).
LAP_OVERLAP = 3.0
LAP_MID_RADIUS = 29.5
# Press-fit clearance between the lap-joint tongue and groove: shrinks
# the tongue (NOT the groove) at the tip and at the radial step face,
# so the parts seat with ~LAP_CLEARANCE mm of play in both directions
# instead of binding on a tight FDM print. Outer (visible) cylinder
# surface is unchanged so the joint flushes at the wall.
# Was 0.2 — that snap was too aggressive: the joint went together fine
# but cracked the wall on disassembly. Bumped to 0.4 since the lens-
# mount ring and hood handle alignment, the lap joint just needs to
# keep the halves indexed (light-tight + radial register, not load-
# bearing).
LAP_CLEARANCE = 0.4


class M57LensHousing(LensHousing):
    # Lower housing — three stepped segments sourced from the bayonet
    # spec. The M57 throat narrows in steps as the housing reaches deeper,
    # and each segment's OD matches one step. Outer is the flange-side
    # (widest, continues above the flange through the mount-ring zone);
    # mid carries the helicoid focus slot; inner is the deepest and
    # narrowest. Physical fit, not a design choice.
    lower_outer_od = BronicaS2Bayonet.lower_housing_outer_od
    lower_outer_len = BronicaS2Bayonet.lower_housing_outer_len
    lower_outer_thk = BronicaS2Bayonet.lower_housing_outer_thk
    lower_mid_od = BronicaS2Bayonet.lower_housing_mid_od
    lower_mid_len = BronicaS2Bayonet.lower_housing_mid_len
    lower_mid_thk = BronicaS2Bayonet.lower_housing_mid_thk
    lower_inner_od = BronicaS2Bayonet.lower_housing_inner_od
    lower_inner_len = BronicaS2Bayonet.lower_housing_inner_len
    lower_inner_thk = BronicaS2Bayonet.lower_housing_inner_thk
    # Upper section (flange-flange / funnel / upper) wall thickness: thick
    # enough to host the stepped lap joint internally (5 mm radial gives
    # 2.5/2.5 mm layers around mid_radius). The upper section sits outside
    # the camera body so its OD is unconstrained by the throat.
    upper_barrel_thk = 5.0   # radial wall (thick — hosts the lap joint internally)
    # Bore-side fillet ring angle at each interior step in the stacked
    # lower housing. 45° is the self-supporting threshold for FDM
    # overhangs printed lens-side-down (the slanted inner cone IS the
    # overhang surface). Steeper would print easier but consume more
    # axial extent inside the wider segment.
    bore_fillet_base_angle = 45.0
    # Alignment groove cross-section, sourced from the bayonet spec so
    # the housing's bottom-face groove and the lens-mount ring's outer-
    # wall groove match in profile.
    alignment_groove_depth = BronicaS2Bayonet.alignment_groove_depth
    alignment_groove_width = BronicaS2Bayonet.alignment_groove_width
    # The flange-flange is the wider band of the housing's wall (above the
    # lower segments) whose bottom rim rests on top of the lens-mount
    # ring. Set equal to the ring's OD (from the bayonet spec) so the
    # joint flushes at the seam.
    flange_flange_od = BronicaS2Bayonet.lens_mount_od
    flange_flange_len = 5.0
    fov_angle = FOV_ANGLE
    grip_depth = GRIP_DEPTH
    grip_width = GRIP_WIDTH
    mount_offset = BronicaS2Bayonet.mount_protrusion
    # Mating disc: bridges the radial gap between the outer segment and
    # the lens-mount ring's bore (from the bayonet spec). Disc OD = bore
    # − MATING_DISC_CLEARANCE (slip-fit, ~0.15 mm radial). Spans
    # z=[1.2, mount_offset] in the housing's world frame: the bottom is
    # 1.2 mm above the rotation channel's roof (the channel cavity tops
    # out at world z=0 = mount_offset − rest_z; that 1.2 mm of axial
    # clearance keeps the disc out of the channel and away from the
    # camera lugs that sit there when locked); the top flushes with the
    # lens-mount tube's top face at world z=mount_offset.
    mating_disc = MatingDisc(
        od=BronicaS2Bayonet.lens_mount_bore - MATING_DISC_CLEARANCE,
        z_bot=1.2, z_top=BronicaS2Bayonet.mount_protrusion,
    )
    # Tabs on the mating disc — shared module-level constant so the
    # locking lens-mount ring can import the same spec and cut matching
    # pockets in its bore wall.
    mating_disc_tabs = BRONICA_S2_MATING_DISC_TABS
    # Snap-fit retention bead — shared module-level constant so the
    # locking ring can cut the matching groove in its bore wall.
    mating_disc_bead = BRONICA_S2_MATING_DISC_BEAD
    # Helicoid focus slot: lives entirely within the mid segment. z_top
    # stays at -offset_from_flange (top of the slot, fixed by the camera-
    # body pin position). z_bot sits at the mid/inner step so the slot
    # never opens into the inner segment. The sweep portion extends CW
    # from the locked-side center by `lock_angle_deg` so the pin clears
    # at every angle as the lens rotates from insertion to locked.
    helicoid_focus_slot = HelicoidFocusSlot(
        angle=BronicaS2Bayonet.helicoid_focus_slot_angle,
        width=BronicaS2Bayonet.helicoid_focus_slot_width,
        depth=BronicaS2Bayonet.helicoid_focus_slot_depth,
        z_bot=-(BronicaS2Bayonet.lower_housing_outer_len
                + BronicaS2Bayonet.lower_housing_mid_len),
        z_top=-BronicaS2Bayonet.helicoid_focus_slot_offset_from_flange,
        sweep_arc_deg=BronicaS2Bayonet.lock_angle_deg,
        # 1 mm overshoot past z_bot — the slot's deep end sits exactly
        # on the mid/inner step plane, so the cutter pokes into the
        # inner-segment z-range (cutting no extra material since the
        # inner wall is at a much smaller radius) to drop the otherwise-
        # coplanar bottom face.
        bottom_overshoot=1.0,
    )
    # Aperture feeler slot: lives in the inner segment, directly opposite
    # the helicoid focus slot (3 o'clock vs the helicoid's 9). Same sweep
    # arc so the feeler clears at every angle during lens rotation. Axial
    # extent spans the entire inner segment — z_top at the mid/inner step
    # so the feeler doesn't catch on the slot's flange-side rim as the
    # lens slides in, z_bot at inner's deep end (the housing's deepest
    # point) with 1 mm overshoot past it so the slot opens cleanly off
    # the end of the throat rather than terminating on a coplanar bottom
    # face.
    aperture_feeler_slot = ApertureFeelerSlot(
        angle=BronicaS2Bayonet.aperture_feeler_slot_angle,
        width=BronicaS2Bayonet.aperture_feeler_slot_width,
        depth=BronicaS2Bayonet.aperture_feeler_slot_depth,
        z_top=-(BronicaS2Bayonet.lower_housing_outer_len
                + BronicaS2Bayonet.lower_housing_mid_len),
        z_bot=-(BronicaS2Bayonet.lower_housing_outer_len
                + BronicaS2Bayonet.lower_housing_mid_len
                + BronicaS2Bayonet.lower_housing_inner_len),
        sweep_arc_deg=BronicaS2Bayonet.lock_angle_deg,
        bottom_overshoot=1.0,
    )
    elements = ELEMENTS
    stop = THE_STOP


class M57LensHood(LensHood):
    wall_thk = 2.0
    hood_clr = 0.25
    hood_length = 20.0
    coupler_overlap = 6.0


# =============================================================================
# DESIGN: shared parts + variant methods
# =============================================================================


def _make_stop_discs(housing, hole_diameters):
    """One `WaterhouseStop` per hole diameter, all sharing the same
    barrel dimensions, thickness, and depth. Disc diameters are sourced
    from the housing at the stop's z, so the inner semicircle fills the
    local bore and the outer semicircle flushes with the local wall OD
    regardless of which section (lower / flange / funnel / upper) the
    stop sits in."""
    z = STOP_DEPTH
    return tuple(
        WaterhouseStop(
            inner_diameter=housing.wall_id_at_z(z),
            outer_diameter=housing.wall_od_at_z(z),
            thk=STOP_THK,
            hole_d=h,
            spacing=STOP_DEPTH,
        )
        for h in hole_diameters
    )


# Bambu X2D buildable area on the bed (mm). Layouts must fit within these.
BAMBU_X2D_PLATE = (256.0, 256.0)


class LensHousingDesign(Design):
    housing = M57LensHousing()
    hood = M57LensHood(
        housing_upper_od=housing.upper_housing_od,
        hood_base_angle=housing.hood_base_angle,
        label=FRONT_FILLET_LABEL,
    )
    stop_discs = _make_stop_discs(housing, STOP_HOLE_D)

    def _splayed_halves(self):
        """The two housing halves, lap-jointed at X=0 and laid flat for
        the bed. Returned as a (minus, plus) pair. The lap is confined
        to z >= MOUNT_OFFSET (the thick-walled section above the mount
        ring); the thin-walled lower section below z=MOUNT_OFFSET gets
        a clean halve only.

        Each lap_split_x result is wrapped in `force_render()` so
        OpenSCAD computes the lap-jointed half once via CGAL on first
        compile and caches the resulting mesh; subsequent F5 frames
        (camera rotation in preview) draw the cached mesh instead of
        re-evaluating the deep CSG tree every frame.

        Engravings live OUTSIDE force_render: the bare structural half
        is what gets cached, and the engraving cutter (~42 glyph cuts)
        is differenced in via preview-CSG per frame. Without this split,
        every glyph difference ends up inside the CGAL evaluation and
        preview-open time balloons. The engravings sit on the +X half
        (angle=0 for both labels), so only the plus side needs the
        difference; the minus half goes through unmodified."""
        eng = self.housing.engravings()
        minus = self.housing.lap_split_x(
            side="minus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
            z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE,
        ).force_render()
        plus_bare = self.housing.lap_split_x(
            side="plus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
            z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE,
        )
        plus = difference(plus_bare.force_render(), eng).with_bbox_from(plus_bare)
        return (
            minus.lap_splay(side="minus", lap_overlap=LAP_OVERLAP),
            plus.lap_splay(side="plus", lap_overlap=LAP_OVERLAP),
        )


    @variant(fn=60, default=True)
    def print_vertical(self):
        # Both halves printed vertically (optical axis = print Z), lens-
        # side-down: the OD step at the flange is an inward step (no
        # overhang), the lap-joint features get first-layer accuracy at
        # the bed, and the wider lens-side face gives a generous bed-
        # contact area. Suited for the Bambu X2D's dual-head PETG-on-PLA
        # support workflow — element-gripper undersides print over PETG
        # and break off cleanly. Trades ~25% extra wall-clock vs the
        # horizontal `print` variant for smoother bore circumferential
        # finish and stronger resistance to bayonet-engagement torque.
        # `.force_render()` collapses each lap-jointed half into a single
        # CGAL-evaluated mesh on first compile; subsequent OpenSCAD F5
        # frames just draw the cached mesh, sidestepping the expensive
        # per-frame CSG re-evaluation that makes preview-mode camera
        # rotation painful on this geometry.
        eng = self.housing.engravings()
        minus = self.housing.lap_split_x(
            side="minus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
            z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE,
        ).force_render()
        plus_bare = self.housing.lap_split_x(
            side="plus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
            z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE,
        )
        plus = difference(plus_bare.force_render(), eng).with_bbox_from(plus_bare)

        # Lens-side-down: rotate 180° about X (flips Y and Z, keeps X
        # so minus stays at world X<=0 and plus at world X>=0). The
        # lens-side face ends up below z=0; pack_on_bed below uses
        # tight_bbox to lift it back to the bed (LensHousing's
        # tight_bbox override gives the truncated fillet rim's true
        # z-extent, so the rim lands flush with z=0).
        minus_v = minus.rotate([180, 0, 0])
        plus_v = plus.rotate([180, 0, 0])

        gap = 12   # ~1.2cm clearance between objects

        # Place each half so its cut face sits at world X = ±gap/2. Lap
        # tongues extend at most LAP_OVERLAP - LAP_CLEARANCE past the cut
        # face, so the actual material gap between the two halves is
        # gap - 2*(LAP_OVERLAP - LAP_CLEARANCE) — comfortably non-zero
        # for any reasonable gap. pack_on_bed can't preserve this overlap
        # if the halves are passed in individually (it would space them
        # apart by `gap`), so the pair is bonded into one unit first and
        # then laid out alongside the stop disc.
        pair = union(minus_v.left(gap / 2), plus_v.right(gap / 2))

        # flat_stop = self.stop_discs[0].down(STOP_DEPTH - STOP_THK / 2)
        # return pack_on_bed(pair, flat_stop, gap=gap, plate=BAMBU_X2D_PLATE)
        return pack_on_bed(pair, gap=gap, plate=BAMBU_X2D_PLATE)

    @variant(fn=48)
    def print_hood(self):
        # Hood by itself, flare-down on the bed (the wide flare gives
        # the largest bed-contact footprint and the coupler / fillet
        # detail prints upward without overhangs). The coupler's label
        # is baked into `LensHood.build()` (via `add_text` on the inner
        # Tube before assembly), so it travels with the hood through
        # the flip and lands oriented correctly on the print surface.
        return pack_on_bed(self.hood.rotate([180, 0, 0]), plate=BAMBU_X2D_PLATE)

    @variant(fn=48)
    def print_stops(self):
        # Two waterhouse stop discs, laid flat on the bed. Picks the
        # f/5.6 and f/11 hole sizes from the JSON's `hole_diameters`
        # list (indices 1 and 3 by construction — index 0 is widest).
        # Adjust the slice if the JSON list ordering changes.
        flat_stops = [
            self.stop_discs[i].down(STOP_DEPTH - STOP_THK / 2)
            for i in (0,2,3)  # f4, f8, f11
            #for i in (1, 3)
        ]
        return pack_on_bed(*flat_stops, gap=10, plate=BAMBU_X2D_PLATE)

    @variant(fn=60)
    def lower_housing_testfit(self):
        """One-piece truncated housing for trial-fitting against the
        camera throat. Strips the assembled housing down to the
        structural lower wall (outer + mid + inner segments + mating
        disc) plus the bottom 2 mm of the flange-flange rim, with the
        helicoid focus slot still cut. No element holders, no stop
        slot/holder/disc, no front fillet, no lap split — slip the
        printed result into the camera body to check stepped-OD
        clearance and helicoid-pin clearance without committing to a
        full housing print. Element data is irrelevant; defaults or
        any --from-json design produce the same geometry.

        Lens-side-down orientation (matches print_vertical): rotated
        180° about X so the truncated flange-flange rim (the widest
        cross-section) sits on the bed for solid adhesion. The throat
        extends upward; every OD step is inward in this orientation,
        so no support material is needed."""
        h = self.housing
        barrel = union(*h._sections())
        if h.helicoid_focus_slot is not None:
            barrel = difference(
                barrel,
                h._swept_slot_cutter(h.helicoid_focus_slot, h.lower_mid_od),
            )
        if h.aperture_feeler_slot is not None:
            barrel = difference(
                barrel,
                h._swept_slot_cutter(h.aperture_feeler_slot, h.lower_inner_od),
            )
        barrel = difference(barrel, h._alignment_groove_cutter())
        # Trim everything above the bottom 2 mm of the upper housing.
        # The slab spans z = [z_bot, z_top] generously past the housing's
        # vertical extent on the bottom side (overshoot is harmless;
        # intersection clips to the barrel).
        z_top = h.mount_offset + 2.0
        z_bot = -h.housing_insertion_depth - 1
        big = 200.0
        trimmer = cube([big, big, z_top - z_bot], center="xy").up(z_bot)
        trimmed = intersection(barrel, trimmer)
        # Lens-side-down: rotate so the rim faces the bed, then lift so
        # the (formerly top) trim plane lands at z=0.
        return trimmed.rotate([180, 0, 0]).up(z_top)

    @variant(fn=48)
    def design_spread_out(self):
        # Inspection layout: hood + the two distinct splayed halves
        # (showing the lap joint) + one stop disc per entry in
        # `STOP_HOLE_D`, all in a single +X row. Too large for the print
        # bed; use the `print` variant for actual printing — `assert_fit`
        # is disabled so this layout is allowed to overflow.
        minus, plus = self._splayed_halves()
        flipped_hood = self.hood.flip("z")   # wide flare on the print bed
        flat_stops = [
            disc.down(STOP_DEPTH - STOP_THK / 2) for disc in self.stop_discs
        ]
        gap = self.housing.upper_housing_od   # ~one barrel-diameter of breathing room

        return pack_on_bed(
            flipped_hood, minus, plus, *flat_stops,
            gap=gap, assert_fit=False,
        )

    @variant(fn=48)
    def display(self):
        # Lift the hood one coupler_overlap above the true housing top (which
        # sits above upper_housing_len because of the front fillet ring) so
        # the housing's upper rim is visible between the two parts. The
        # widest-aperture stop disc shows fully inserted at its real depth.
        housing_top_z = self.housing.bbox.max[2]
        gap = self.hood.coupler_overlap
        return union(
            difference(self.housing, self.housing.engravings()),
            self.hood.up(housing_top_z + gap),
            self.stop_discs[0],
        )

    @variant(fn=48)
    def element_grippers(self):
        # Per-element diagnostic half-grippers for test-fitting individual
        # elements without printing a full housing. Each gripper is the
        # same three-tube stack as ElementHolder (rim / middle / rim) with
        # rim and middle inner diameters and axial extents matched to the
        # housing exactly — a successful fit here predicts a fit in the
        # real part. Outer wall is a uniform 2 mm-walled cylinder per
        # gripper (sized off the middle tube; rim tubes come out thicker).
        # Halved at X=0 keeping +X so each gripper prints as a half-shell
        # with the element code engraved on its outer apex (the anchor
        # sits at +X, so engravings stay on the kept half). Standing up
        # along Z; pack_on_bed lays them along +X in elements-tuple order.
        halves = []
        for e in self.housing.elements:
            g = ElementTestGripper(
                element=e,
                grip_depth=GRIP_DEPTH,
                grip_width=GRIP_WIDTH,
                wall_thk=2.0,
                radial_clr=e.clearances.radial,
            )
            cutter = g.text_geometry(
                label=e.code, on="outer_wall", angle=0,
                font_size=2.5, relief=-0.4,
            )
            # with_bbox_from(g): difference()'s bbox can't be tightened
            # without CSG evaluation, but the engraving only removes
            # material from the gripper's outer face, so the true bbox
            # is the gripper's. Without this, halve()'s Intersection
            # bbox can't be clipped and pack_on_bed below errors out.
            engraved = difference(g, cutter).with_bbox_from(g)
            halves.append(engraved.halve([1, 0, 0]))
        return pack_on_bed(*halves, gap=10, plate=BAMBU_X2D_PLATE)

    @variant(fn=48)
    def testing(self):
        # One splayed half (the -X half, with lap-joint features visible)
        # for inspecting a single shell in isolation.
        minus, _ = self._splayed_halves()
        minus_bb = minus.bbox
        gap = self.housing.upper_housing_od
        return minus.left(minus_bb.max[0] + gap / 2)


# Output basename follows the JSON-supplied design name (or
# DEFAULT_DESIGN_NAME). The framework derives the output filename as
# `f"{design_cls.__name__}-{variant}.scad"`, so mutating `__name__`
# after class definition is enough.
LensHousingDesign.__name__ = design_name


if __name__ == "__main__":
    run()
