# Custom supports for the v12c lens housing — design notes

Notes for future use, in case Bambu's slicer-side supports (Snug + dual-filament
PLA/PETG, 0 mm top z-distance) don't release cleanly enough on the housing.
The lens mount's `LensMountSupports` Component pattern is the model to follow.

## When this is worth doing

Skip if Snug + PETG-on-PLA + 0 mm gap releases cleanly. Custom supports
are a real chunk of code (Component + 2 variants + per-gripper geometry).
Only worth it if:

- Slicer-generated supports leave visible scarring on the gripper
  undersides that affects lens seat (the gripper face is what holds the
  glass flat — surface roughness there matters).
- Removal requires force that risks cracking the wall (the housing's
  upper-section wall is 5 mm radial, but the lap-joint zone has stepped
  features that make it locally weaker).
- The slicer wraps the bore wall in support material that's a pain to
  pull out without damaging the bore surface (lenses slide along the
  bore wall during installation).

If none of these bite, leave the slicer to do its job.

## Overhang inventory (print_vertical orientation only)

The print_vertical orientation puts the truncated fillet rim on the
bed; lens-side down, M57-throat-side up. This is the right orientation —
no reorientation reduces the overhang count.

### External: nothing needs support

- Bed contact: truncated fillet rim (small annular footprint, but it
  IS a real bed-contact surface — no first-layer issue).
- Fillet flares **outward** from rim up to the wall (upward slope, no
  overhang).
- Upper section: vertical cylinder, OD = 68.1 (= LENS_MOUNT_OD).
- Flange-flange/lower-section transition steps **inward** going up
  (the OD shrinks from 68.1 to 56). Inward steps in print = upward-
  facing horizontal annular ring, which is fine — not an overhang.
- Mating disc: sits at the same z as the flange-flange's top face
  (the disc starts at z = mount_protrusion in original = top of
  flange-flange in print). No air gap underneath. Not an overhang.
- Lower section: vertical cylinder, OD = 56.
- M57 throat extension: vertical cylinder up to print z ≈ 60.8.

### Internal: 6 overhangs per half (the element grippers)

Each of the 3 elements (L7325 / L14523 / L13088) has a holder
consisting of two grippers + one full-height surround tube, mirrored
about the element center. The grippers have smaller ID than the
surround (= e.dia − grip_depth = e.dia − 1.5). The transition from
surround ID to gripper ID is a sharp inward step.

In print_vertical, the cluster has a "bottom-of-cluster gripper" and a
"top-of-cluster gripper" relative to the bed:

- **Bottom-of-cluster gripper** (was the upper gripper in the original
  housing orientation): its bottom face is a full annular ring,
  r ∈ [(e.dia − grip_depth) / 2, holder_od / 2], hanging in the bore
  air with nothing below until the next element's cluster (or the bed).
  Annular width ≈ (grip_depth + clr.radial) / 2 + thk ≈ 1.25 mm.

- **Top-of-cluster gripper**: its bottom face is partially supported by
  the surround tube directly below it, but the inner part of the ring
  (where gripper ID < surround ID) overhangs by ~1 mm radially.

Per element cluster: 1 large overhang (full ring) + 1 partial overhang
(thin inner ring). Per housing half: 3 clusters × 2 = 6 overhangs total.

The waterhouse stop slot (in M57LensHousing — `THE_STOP` carries the
slot through the lower section) cuts a horizontal slot through the
wall. In print_vertical, this slot is high in the print (above the
flange-flange). The slot's "roof" (in print orientation) is the upper
edge of the cut, which is downward-facing across a small area —
support-worthy but very minor.

## Proposed support geometry

Mirror the `LensMountSupports` pattern: a single connected piece per
half that prints alongside the housing half (PETG body, PLA model;
or vice versa for whichever filament's on the support nozzle).

### Spine + shelves

Per half, one connected support body:

1. **Vertical spine**: a thin arc segment standing on the bed,
   extending up past the topmost gripper. Sits in the half-bore,
   inset radially by `support_inward_offset` (1.0 mm, like the lens
   mount) so it doesn't trap under any gripper inner edge during
   removal. Arc angular extent: maybe 30–60° (less than the half-bore's
   180°), positioned so it doesn't conflict with the lap-joint cut
   plane along its full height.

   - Inner radius: `bore_inner_r − support_inward_offset − support_tube_wall_thk`
   - Outer radius: `bore_inner_r − support_inward_offset`
   - Height: from print z = 0 (bed) up to just under the topmost gripper's
     bottom face, minus `support_air_gap`.

2. **Per-gripper shelves** (6 per half): annular sectors that branch
   off the spine and extend out to just under each gripper's overhang,
   stopping `support_air_gap` (0.1 mm) below the gripper's bottom face.
   Same angular extent as the spine. Inner radius matches the spine's
   outer radius (overlap by `fuse_overlap = 0.1` so they print as one
   piece, like the lens mount's filler/pillar fuse). Outer radius
   reaches `holder_od / 2 − support_air_gap` (just inside the housing
   wall).

   For the bottom-of-cluster gripper: shelf inner edge can extend to
   `(e.dia − grip_depth) / 2 + fuse_overlap` (covers the full overhang).

   For the top-of-cluster gripper: shelf only needs to cover the inner
   ring (between gripper ID and surround ID).

3. **Stop-slot lip support** (optional, only if the slot is in the
   variant): a small tab supporting the slot's roof. Probably skip in
   v1 unless print testing shows the slot roof sagging.

Print orientation: same as the housing half (cut-face-toward-other-half,
lens-side-down). Pre-aligned in housing world coords; load both STLs
into Bambu Studio without auto-arrange.

## Implementation pattern

Mirror the lens mount supports, three components:

```python
class LensHousingSupports(LensHousing):
    """Modeled PETG supports for printing one half of `LensHousing`
    in print_vertical orientation. Yields the spine + per-gripper
    shelves; pairs with the matching `LensHousing` (lap-split) half."""

    support_air_gap = 0.1
    support_air_gap_deg = 0.5
    support_tube_wall_thk = 1.5
    support_inward_offset = 1.0
    fuse_overlap = 0.1
    spine_arc_deg = 60.0          # angular extent of the spine arc
    spine_center_deg = 0.0        # angular position; 0 = +X (cut-plane direction)

    def build(self):
        # ... compute spine, then loop over self.elements yielding shelves
        pass

    def tight_bbox(self):
        # Walk the supports build tree (don't inherit LensHousing's override).
        return Component.tight_bbox(self)


class M57LensHousingSupports(LensHousingSupports, M57LensHousing):
    pass
```

Plus variants on the `v12c` Design:

```python
@variant(fn=48)
def print_vertical_supports(self):
    # Modeled supports only, in housing world coords. Load alongside
    # print_vertical's STL in Bambu without auto-arrange.
    return self.housing_supports.lap_split_x(...).force_render()...

@variant(fn=48)
def print_vertical_print(self):
    # Combined: housing pair + supports pair, all in one STL.
    # Same Split→To Objects + dual-filament workflow as s2_mount_locking's
    # lens_locking_print.
    pass
```

## Lap-split interaction

The trickiest bit: the supports need to be lap-split alongside the
housing. The simplest move is to apply the same `lap_split_x`
transform to the supports component as we do to the housing. The
support spine + shelves should be designed so that:

- The spine sits entirely on one side of the cut plane (X ≤ 0 or X ≥ 0
  depending on side), no tongue/groove features.
- The shelves don't cross the cut plane.

If the spine is centered at angle 0° (+X axis, the cut plane normal),
half of it would land in each split half. Better: put two spines, one
per side, offset 90° from the cut plane (so each spine lives entirely
in one half).

Actually simplest: the spine angular position should be such that the
WHOLE spine is on one side of X = 0. For minus side (kept material at
X ≤ 0), put spine_center_deg = 180° (centered on −X axis); for plus
side, spine_center_deg = 0° (centered on +X axis). Generate a
side-aware support per half — same pattern as `lap_split_x`'s side
parameter.

Or simplest of all: don't lap-split the supports. Generate them as
flat half-supports directly (each support is for ONE half, pre-cut).

## Open questions

- **Spine angular position**: cut plane is at X = 0; spine should be
  away from it. Maybe ±90° (along ±Y axis) so the support is in the
  "deep" middle of the half-bore. Or possibly two thin spines per half
  (e.g., at 45° and 135°) for redundancy.

- **Shelf coverage angle**: the bottom-of-cluster gripper has a full
  annular overhang. Shelves at 60° angular extent only cover 1/6 of
  the ring — the rest of the ring's underside still hangs over the
  bore. Is that OK? PLA can bridge unsupported spans up to ~5–10 mm
  reliably; the bore radius is ~26 mm so the unsupported chord at
  60°-from-spine is ~26 × sin(30°) × 2 ≈ 26 mm. Too far to bridge.

  Probably need wider shelf angular extent — maybe a near-full 180°
  (matching the half-bore extent), with a small gap at the cut plane
  (similar to the lens mount supports' 0.5° air_gap_deg).

- **Removal mechanics**: with shelves at 180° angular extent, pulling
  the support out axially (along print Z) requires it to slide past
  each gripper's inner edge. The support's outer edge at each shelf
  is `holder_od / 2 − support_air_gap` ≈ 26.4 mm. The gripper inner
  edge is `(e.dia − grip_depth) / 2`. For L7325: 25.25 mm. The shelf
  outer edge (26.4) is OUTSIDE the gripper inner edge (25.25), so the
  shelf would catch on the gripper during removal.

  Fix: the shelf's outer edge should be ≤ gripper inner edge, with
  shrinkage. Set shelf outer = `(e.dia − grip_depth) / 2 − support_air_gap`.
  Then it's 0.1 mm INSIDE the gripper edge — slides past cleanly.

  But then the shelf doesn't directly support the gripper's underside —
  it supports the surround's underside (which is at r = (e.dia + clr.radial) / 2,
  even larger). Hmm.

  Actually: the gripper bottom face at radius r ∈ [(e.dia − grip_depth) / 2,
  holder_od / 2] is what we want to support. To NOT catch the gripper on
  removal, the shelf must be entirely inside the gripper's inner edge
  (r < (e.dia − grip_depth) / 2). That's INSIDE the lens position —
  the lens itself sits at r ≤ e.dia / 2, which overlaps with the
  gripper-inner zone. The shelf would be in the lens-installation path.

  This is fundamentally a topology problem: a support that touches the
  gripper's underside can't slide axially past the gripper without
  collision. The lens mount's analogous problem (rotation channel
  fillers) is solved by pulling them OUT through the gap left by the
  bayonet lip cutaway. The housing's bore has no such gap — it's a
  closed cylinder past each gripper.

  Resolution options:
  1. Pull the support out through the M57 throat (top of print).
     The throat ID is `lower_housing_id − inner_shrink` ≈ 53 mm;
     the gripper ID is 50.5 mm for L7325. The support's outer edge
     must fit through the gripper IDs (50.5, 41 for L14523, 39.5 for
     L13088 — actually L13088 is constricted and likely below the
     M57 throat plane in original orientation, so it's at the bottom
     of the print, not above the M57 throat).
  2. Make the support break up at each gripper level — top section
     pulls out separately. Multiple support pieces per half.
  3. Make the shelves narrower angular sectors that thread through
     between elements (if there's enough cleared angular space).

  This is the real design question. Lens mount's pull-out path was
  simpler because the lugs only block 3 small angular sectors;
  housing grippers block 360°.

- **Lens insertion afterwards**: lenses go in from the lens-side
  (bed-side in print, top-side after final assembly orientation flip).
  Each lens slides down the bore until it seats on its gripper. The
  bore must be clear of any leftover support residue. Slicer-marked
  scars on the gripper face = bad seat. Custom supports leaving clean
  surfaces = good seat.

## Summary

- The geometry is favorable: only 6 small internal overhangs per half,
  no external support needed.
- The lap-split + lens-extraction topology constraints are the hard
  part. Removable supports inside the bore need a clear axial path,
  which the closed cylindrical bore doesn't easily provide.
- Per-segment supports (one piece per inter-element zone) are likely
  more workable than a single spine spanning the full height.
- Probably worth doing only after Snug-mode supports prove inadequate.
