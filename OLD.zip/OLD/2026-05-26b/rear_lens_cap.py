"""Bronica S2 rear lens cap.

A camera-side-bayonet stub (3 lugs on a tube, same dimensions as the
S2 camera mount) plus a cup that closes off the rear of the lens when
no camera is attached. Mimics what the camera looks like from the
lens's perspective — the lens-mount ring on the lens clicks onto the
cap's lugs the same way it clicks onto the camera.

Geometry (cap's own frame, z=0 = closing disc bottom = print bed,
z=total_h = lug-tube top = lens-mating side):

  - z = 0 .. disc_thk           closing disc (solid, OD = cup_od)
  - z = disc_thk .. cup_h       cup tube (hollow, OD = cup_od, ID = cup_id)
  - z = cup_h .. total_h        lug tube (a CameraMount, length = lug_tube_len)
  - z = total_h − lug_axial..   3 lugs protruding radially outward from
        total_h                 the lug-tube outer wall.

The lug tube's axial extent matches the lh_outer segment of the lens
housing (`BronicaS2Bayonet.lower_housing_outer_len`). With `cup_od`
equal to `cam_barrel_od`, the cap's outer surface is a uniform-OD
cylinder; the "lug tube / cup tube" distinction is a conceptual one
that records where the bayonet engagement happens.

Run:
    python s2-evolving/rear_lens_cap.py
"""

from scadwright import Component
from scadwright.composition_helpers import pack_on_bed
from scadwright.design import Design, run, variant
from scadwright.primitives import cylinder
from scadwright.shapes import Tube

from printer import BAMBU_X2D_PLATE
from s2_body_cap import CameraMount
from s2_spec import BronicaS2Bayonet


class RearLensCap(Component):
    """Rear lens cap with a `CameraMount`-style bayonet stub on the
    lens side and a hollow cup with a closing disc on the camera side.

    The lug-bearing tube reuses `CameraMount` directly (same OD/ID,
    same lug pattern), with its `length` overridden to `lug_tube_len`
    (typically matching the lens housing's lh_outer segment so the
    bayonet engagement region is sized like a real camera's). The
    cup is a longer hollow tube below the lug section, closed at the
    far end by a flat disc.

    Tiny axial `*_axial_eps` overlaps at the disc–cup and cup–lug
    seams keep the CSG union preview-clean (same idiom as the body
    cap's radial disc-overlap).
    """

    equations = """
        cam_barrel_od, cam_barrel_id, lug_axial > 0
        cam_barrel_od > cam_barrel_id
        cup_od, cup_wall_thk > 0
        lug_tube_len, disc_thk, total_h > 0
        total_h > lug_tube_len + disc_thk
        cup_h = total_h - lug_tube_len
        cup_tube_len = cup_h - disc_thk
        cup_id = cup_od - 2 * cup_wall_thk
        # Cup interior must be wide enough to clear the lug-tube interior
        # so the hollow interior is continuous across the seam.
        cup_id >= cam_barrel_id
        # Lug pattern (center_deg, width_deg, radial_proj_mm) per lug.
        len(lugs:tuple) >= 1
        # Axial eps overlaps for clean CSG at the disc-cup and cup-lug
        # interfaces.
        disc_axial_eps = 0.01
        lug_tube_axial_eps = 0.01
    """

    def build(self):                                       # framework hook: required; returns the shape
        # Cup tube: hollow section between the closing disc and the lug
        # tube. OD matches the lug tube (per design choice), so the
        # cap's outer surface is uniform.
        yield (
            Tube(h=self.cup_tube_len, od=self.cup_od, id=self.cup_id)
            .up(self.disc_thk)
        )
        # Closing disc at z=0 (camera-side end). Extended by `disc_axial_eps`
        # into the cup's hollow interior so the union is preview-clean.
        yield cylinder(
            h=self.disc_thk + self.disc_axial_eps,
            r=self.cup_od / 2,
        )
        # Lug tube: a CameraMount with `length = lug_tube_len`,
        # geometrically identical to the camera-side bayonet stub.
        # Shifted up by `cup_h − eps` so the bottom of its tube
        # overlaps the cup tube's top by `lug_tube_axial_eps` for a
        # clean CSG seam.
        lug_section = CameraMount(
            barrel_id=self.cam_barrel_id,
            wall_thk=(self.cam_barrel_od - self.cam_barrel_id) / 2,
            length=self.lug_tube_len + self.lug_tube_axial_eps,
            lug_axial=self.lug_axial,
            lugs=self.lugs,
        )
        yield lug_section.up(self.cup_h - self.lug_tube_axial_eps)


class BronicaS2RearLensCap(RearLensCap):
    """Concrete rear lens cap sized to the Bronica S2 bayonet. Lug
    geometry comes from the shared bayonet spec; cup OD matches the
    lug-tube OD so the cap is a uniform 60.5 mm cylinder."""

    cam_barrel_od = BronicaS2Bayonet.cam_barrel_od
    cam_barrel_id = BronicaS2Bayonet.cam_barrel_id
    lug_axial     = BronicaS2Bayonet.cam_lug_axial
    lugs          = BronicaS2Bayonet.lugs
    # Lug-bearing tube length matches the lh_outer segment of the lens
    # housing — the axial extent the bayonet engagement region occupies
    # when a real lens is mounted on a real camera.
    lug_tube_len  = BronicaS2Bayonet.lower_housing_outer_len
    # Cup OD equal to the lug-tube OD: cap reads as a single uniform
    # cylinder rather than a stepped shoulder.
    cup_od        = BronicaS2Bayonet.cam_barrel_od
    cup_wall_thk  = 2.0
    disc_thk      = 2.0
    total_h       = 50.0


class rear_lens_cap(Design):
    """Bronica S2 rear lens cap variant."""

    cap_part = BronicaS2RearLensCap()

    @variant(fn=96, default=True)
    def rear_cap(self):
        return pack_on_bed(self.cap_part, plate=BAMBU_X2D_PLATE)


if __name__ == "__main__":
    run()
