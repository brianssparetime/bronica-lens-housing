"""Lens housing with stacked optical elements and a matching clip-on hood.

Shows the recommended multi-part layout (see
docs/organizing_a_project.md). Generic Components live in the REUSABLE
zone with no project-specific defaults; the specific design for an
M57-throat camera lives in the CONCRETE zone as thin subclasses that
fill in measurements as class attributes.

Run:
    python examples/lens-housing.py                                  # print variant (default)
    scadwright build examples/lens-housing.py --variant=display        # assembled view
    scadwright build examples/lens-housing.py --variant=print          # split + spread for inspection
"""

import os
import sys
from collections import namedtuple

# Make sibling-file imports work under `scadwright build` (the CLI doesn't
# add the script's directory to sys.path; running via plain Python does).
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from scadwright import BBox, Component, Param, from_json, print_stamp
from scadwright.api.tolerances import default_eps
from scadwright.component.anchors import anchor

from s2_spec import BronicaS2Bayonet
from scadwright.boolops import difference, intersection, union
from scadwright.composition_helpers import mirror_copy, pack_on_bed
from scadwright.design import Design, run, variant
from scadwright.primitives import circle, cube, cylinder
from scadwright.shapes import FilletRing, Funnel, Sector, Tube
from scadwright.transforms import transform


# =============================================================================
# REUSABLE: generic Components, helpers, value types
# =============================================================================


# Per-element fit clearances around the lens body, separately tunable
# per element (different glass shapes/edge profiles benefit from
# different fit looseness). Both fields in mm.
#
# `axial` is per-side: the gap between the element's flat face (top or
# bottom) and the holder's surround floor. Total axial slop = 2 * axial
# (one gap above, one below).
#
# `radial` is DIAMETER-based, NOT radius-based: it's added directly to
# the element diameter to compute the surround tube's bore
# (`id = e.dia + clearances.radial` in ElementHolder.build()). So the
# actual per-side radial gap between the element's outer edge and the
# surround's inner wall is `radial / 2`. A `radial` of 0.4 mm means
# 0.2 mm gap on each side, not 0.4 mm. (Naming is legacy; the math is
# what counts.)
ElementClearances = namedtuple("ElementClearances", "axial radial")
DEFAULT_ELEMENT_CLEARANCES = ElementClearances(axial=0.2, radial=0.3)


# Mating disc: an annular ring on the lens-housing's outer surface that
# bridges the radial gap between the housing's lower (M57-fit) section
# and the lens-mount ring's inner bore. Built as part of the housing
# (so it gets halved with the housing's lap-split halves and needs no
# separate support); functionally it's the physical interface to the
# lens-mount ring.
#   - od: lens-mount ring's bore (the disc fits snugly inside it).
#   - z_bot, z_top: axial range in housing world frame. Typically z_bot
#     sits a small clearance above the rotation channel's roof, and
#     z_top flushes with the top of the lens-mount tube (= MOUNT_OFFSET
#     in the housing's world frame).
# The disc's ID is taken from `lower_housing_od` so the disc wraps the
# lower section concentrically.
MatingDisc = namedtuple("MatingDisc", "od z_bot z_top")


# Helicoid focus slot: a cut through the lower-housing wall that clears a
# focus-helicoid pin from the camera body. All five fields are camera
# attributes (live in `BronicaS2Bayonet`); the housing reads them via the
# namedtuple and cuts the wall accordingly.
#   - angle: deg, 0 = +X axis (3 o'clock looking from camera toward subject).
#   - width: mm circumferential, arc length at the lower housing's OD.
#   - depth: mm radial, from OD inward. Equals the lower-housing wall
#     thickness by design, so the cut goes all the way through.
#   - z_bot, z_top: axial range in housing world frame.
# The cut is positioned at the slot's angle and only intersects the wall
# material — element holders sit inside the wall bore and a clean cylindrical
# inner face on the cutter (matched to `lower_housing_id` minus a sub-eps
# overshoot smaller than the holders' own outward overshoot) keeps them
# untouched.
HelicoidFocusSlot = namedtuple("HelicoidFocusSlot", "angle width depth z_bot z_top")


class HousingSection(Component):
    """One axial section of the lens housing's wall. Cylindrical when
    bot_id == top_id, conical (a Funnel) otherwise. Carries both its
    axial extent and its radial profile in one Component, so the
    housing's geometry (built from sections) and its `wall_od_at_z`
    lookup (querying sections) share one source of truth — no parallel
    analytic predictor."""

    equations = """
        z_top > z_bot
        bot_id, top_id, thk > 0
    """

    # Cylindrical anchor for the outer wall — lets `add_text(on="outer_wall")`
    # wrap a label around the section. Safe only on cylindrical sections
    # (`bot_id == top_id`); conical (funnel) sections would need a separate
    # conical anchor with r1/r2/length surface_params.
    outer_wall = anchor(
        at="(bot_id + 2*thk) / 2.0, 0, (z_bot + z_top) / 2",
        normal=(1.0, 0.0, 0.0),
        kind="cylindrical",
        surface_params={
            "axis": (0.0, 0.0, 1.0),
            "radius": "(bot_id + 2*thk) / 2.0",
            "length": "z_top - z_bot",
        },
    )

    def build(self):                                       # framework hook: required; returns the shape
        h = self.z_top - self.z_bot
        if self.bot_id == self.top_id:
            return Tube(h=h, od=self.bot_id + 2 * self.thk, id=self.bot_id).up(self.z_bot)
        return Funnel(
            h=h, thk=self.thk, bot_id=self.bot_id, top_id=self.top_id,
        ).up(self.z_bot)

    def od_at(self, z):
        """Outer diameter at axial position z (must be in [z_bot, z_top])."""
        return self.id_at(z) + 2 * self.thk

    def id_at(self, z):
        """Inner diameter at axial position z (must be in [z_bot, z_top])."""
        if self.bot_id == self.top_id:
            return self.bot_id
        t = (z - self.z_bot) / (self.z_top - self.z_bot)
        return self.bot_id + t * (self.top_id - self.bot_id)


# spacing is from flange (z=0) to element center; +z = toward object.
# `face_z_top`, `face_z_bot`, `constricted`, `throat_dia_required` are
# precomputed by `element(...)` so the housing's `equations` list can
# reference them as attributes directly. `clearances` is an
# `ElementClearances(axial, radial)` namedtuple; the holder reads both
# values from this field. `code` (catalog code, e.g. "L7325") and
# `type` (e.g. "NMN", "ACH", "BCX") identify the lens.
Element = namedtuple(
    "Element",
    "code type dia edge_thk spacing face_z_top face_z_bot constricted throat_dia_required clearances",
)


class ElementHolder(Component):
    """Two-sided clamp around one Element, symmetric about the element center."""

    element = Param(Element)
    equations = """
        od, grip_depth, grip_width > 0
    """

    def build(self):                                       # framework hook: required; returns the shape
        e = self.element
        clr = e.clearances
        # Source of truth for the holder's z-extent: e.face_z_top,
        # computed once by element() factory and used by housing
        # equations to size upper_housing_len. We DERIVE surround_h from
        # it (subtracting the gripper's per-side contribution) so the
        # actual holder geometry can never drift from the predicted
        # face_z_top — change face_z_top's formula and the holder
        # follows automatically.
        gripper_h = 0.5 * self.grip_width
        surround_h = (e.face_z_top - e.spacing) - gripper_h
        # Diametral eps: the holder's outer cylinder otherwise sits at
        # exactly the housing wall's inner bore (`od == section.id` in
        # the non-wide case). The shared cylindrical face survives the
        # yield-union as an internal seam, and `halve` later exposes
        # that seam as a non-manifold edge along the cut plane. Bumping
        # the OD by 2*default_eps() pokes the holder a hair into the
        # wall material; the union with the barrel absorbs the overlap
        # and the inner bore geometry is unchanged at any meaningful
        # scale.
        eps = default_eps()
        od = self.od + 2 * eps
        surround = Tube(h=surround_h, od=od, id=e.dia + clr.radial)
        gripper = Tube(
            h=gripper_h,
            od=od,
            id=e.dia - self.grip_depth,
        ).attach(surround, bond="shift")
        half = union(surround, gripper).flip("z")
        return mirror_copy(half, normal=[0, 0, 1]).up(e.spacing)


def element(*, code, type, dia, edge_thk, spacing, grip_width, mount_offset=0,
            clearances=DEFAULT_ELEMENT_CLEARANCES):
    """Build an `Element` with its computed geometric fields filled in.

    The caller supplies `grip_width` (the holder's per-side gripper
    height) so the housing's equations can reason about each element's
    z-extent through attribute access. `mount_offset` is the axial
    extent of the lens-mount ring above the camera flange (z=0); the
    M57-restricted lower section of the housing extends up to this z,
    so an element is `constricted` when its lower face is below the
    top of the mount-ring zone (face_z_bot < mount_offset).
    `clearances` is an `ElementClearances(axial, radial)` pair; defaults
    to the project-wide `DEFAULT_ELEMENT_CLEARANCES`. Override per
    element when a particular piece of glass needs a tighter or looser
    fit (e.g. a chipped edge, an irregular OD, or a known-bad-tolerance
    cell).
    """
    # Half-extent of the element holder in z, computed from the EXACT
    # geometry built in ElementHolder.build(): one half = surround_h
    # (= 0.5 * edge_thk + axial clearance) + 0.5 * grip_width (the
    # mirror-copied gripper above the surround). Element spacings
    # (relative to the camera flange) are the source of truth; the
    # housing's `upper_housing_len = max(e.face_z_top)` is then EXACTLY
    # the topmost holder's top face, with no approximate-formula gap.
    half = 0.5 * edge_thk + clearances.axial + 0.5 * grip_width
    return Element(
        code=code, type=type,
        dia=dia, edge_thk=edge_thk, spacing=spacing,
        face_z_top=spacing + half,
        face_z_bot=spacing - half,
        constricted=(spacing - half) < mount_offset,
        throat_dia_required=dia + clearances.radial,
        clearances=clearances,
    )


class ElementTestGripper(Component):
    """Stand-alone diagnostic half-shell of one element's gripper.

    Three stacked tubes (bottom rim / middle / top rim) reproducing
    `ElementHolder`'s inward features — rim ID, middle ID, and axial
    extents — exactly, so a successful fit here predicts a fit in the
    housing. The outer wall is a smooth uniform-OD cylinder sized to
    give the middle (surround) tube `wall_thk` radial wall; rim tubes
    consequently have slightly thicker walls (the surplus being half
    of `grip_depth + radial_clr`). Intended to be halved sagittally
    and printed individually for per-element fit checks without
    committing to a full housing.

    `radial_clr` is the element's diametral radial clearance, passed
    in separately because the equations DSL only handles single-level
    attribute access and the value lives in `element.clearances.radial`.
    """

    element = Param(Element)
    equations = """
        grip_depth, grip_width, wall_thk, radial_clr > 0
        gripper_h = grip_width / 2
        surround_h = element.face_z_top - element.spacing - gripper_h
        rim_id = element.dia - grip_depth
        surround_id = element.dia + radial_clr
        od = surround_id + 2 * wall_thk
        total_h = 2 * (gripper_h + surround_h)
    """

    outer_wall = anchor(
        at="od / 2, 0, total_h / 2",
        normal=(1.0, 0.0, 0.0),
        kind="cylindrical",
        surface_params={
            "axis": (0.0, 0.0, 1.0),
            "radius": "od / 2",
            "length": "total_h",
        },
    )

    def build(self):                                       # framework hook: required; returns the shape
        bottom_rim = Tube(h=self.gripper_h, od=self.od, id=self.rim_id)
        middle = Tube(
            h=2 * self.surround_h, od=self.od, id=self.surround_id,
        ).up(self.gripper_h)
        top_rim = Tube(
            h=self.gripper_h, od=self.od, id=self.rim_id,
        ).up(self.gripper_h + 2 * self.surround_h)
        return union(bottom_rim, middle, top_rim)


# A waterhouse stop is a thin disc slid laterally into the lens barrel
# through a side slot to set the aperture. `spacing` is the stop center's
# z-position, `thk` the disc thickness, `clr` the slot's z-clearance.
Stop = namedtuple("Stop", "spacing thk clr")


class WaterhouseStop(Component):
    """A waterhouse stop disc.

    Viewed face-on, it's a 2D paddle: a smaller semicircle of radius
    `inner_diameter`/2 in -Y joined to a larger semicircle of radius
    `outer_diameter`/2 in +Y along their flat edges, with a central
    aperture hole of diameter `hole_d`. Extruded by `thk` along the
    lens axis and centered on `spacing`. When inserted, the lower
    (inner-diameter) semicircle sits in the bore as the aperture plate;
    the upper (outer-diameter) semicircle fills the wall slot, leaving
    a flush exterior. The hole sits on the barrel's axis."""

    equations = """
        inner_diameter, outer_diameter, thk, hole_d > 0
        outer_diameter > inner_diameter
        hole_d < inner_diameter
        # `spacing` is the disc's z-center; `slot_bottom` is the
        # extruder's lower edge. The derivation establishes `spacing` as
        # a Param(float) without an artificial inequality (it can be
        # negative — the stop sits below the flange in the default).
        slot_bottom = spacing - thk / 2
    """

    def build(self):                                       # framework hook: required; returns the shape
        upper = Sector(r=self.outer_diameter / 2, angles=(0, 180))
        lower = Sector(r=self.inner_diameter / 2, angles=(180, 360))
        paddle_2d = difference(union(upper, lower), circle(d=self.hole_d))
        paddle = paddle_2d.linear_extrude(height=self.thk)
        return paddle.up(self.slot_bottom).red()


class StopHolder(Component):
    """Two-sided clamp around a waterhouse stop. Upper and lower grippers
    flank the slot symmetrically along z; both pinch the stop's lower-ID
    semicircle from outside the slot. Each gripper has its own outer
    diameter so the holder can sit in a section where the local wall OD
    differs above vs. below the stop (e.g. when the stop lands inside the
    expansion funnel). When `od_top == od_bot` the result matches a
    uniform-OD section. ID is shared across both grippers since the disc
    they pinch is one diameter regardless of where it sits."""

    stop = Param(Stop)
    equations = """
        od_top, od_bot, grip_depth, grip_width, barrel_id > 0
        barrel_id > grip_depth
    """

    def build(self):                                       # framework hook: required; returns the shape
        s = self.stop
        slot_h = s.thk + s.clr
        half_gw = 0.5 * self.grip_width
        upper = Tube(
            h=half_gw, od=self.od_top, id=self.barrel_id - self.grip_depth,
        ).up(slot_h / 2)
        lower = Tube(
            h=half_gw, od=self.od_bot, id=self.barrel_id - self.grip_depth,
        ).down(slot_h / 2 + half_gw)
        return union(upper, lower).up(s.spacing).green()


class TruncFilletRing(Component):
    """A `FilletRing` with its sharp apex chopped to a flat rim of
    `rim_width` radial width."""

    equations = """
        id, od, base_angle, rim_width > 0
        base_angle < 90
        id < od
        rim_width < (od - id) / 2
        ?slant:str = ?slant or "outwards"
        slant in ("outwards", "inwards")
        h_full = tan(base_angle) * (od - id) / 2
        z_t = tan(base_angle) * ((od - id) / 2 - rim_width)
    """

    # Conical anchor for the inner slanted surface (slant="inwards" only:
    # the inner cone widens from id/2 at z=0 to (od/2 - rim_width) at z=z_t).
    # Lets add_text() wrap a label around the sloped face.
    slanted_face = anchor(
        at="(id + od - 2*rim_width) / 4.0, 0, z_t / 2",
        normal=(-1.0, 0.0, 0.0),
        kind="conical",
        surface_params={
            "axis": (0.0, 0.0, 1.0),
            "r1": "id / 2.0",
            "r2": "(od - 2*rim_width) / 2.0",
            "length": "z_t",
            "inner": True,
        },
    )

    def build(self):                                       # framework hook: required; returns the shape
        # Radial eps: the chopper's outer cylindrical surface sits at d=od, same
        # as the FilletRing's outer wall. through() handles planar-bbox coplanar
        # faces but not cylinder-on-cylinder coincidence, so nudge the chopper
        # outward by a hair.
        eps = 0.01
        base = FilletRing(id=self.id, od=self.od, base_angle=self.base_angle, slant=self.slant)
        chopper = cylinder(
            h=self.h_full - self.z_t, d=self.od + 2 * eps,
        ).up(self.z_t).through(base, axis="z")
        return difference(base, chopper)

    def tight_bbox(self):                                  # framework hook: declare true post-truncation extents
        # Default tight_bbox would walk into our top-level Difference and
        # raise. We know the truth: the chopper removes the apex from
        # z_t to h_full, so the truncated rim's actual top is at z=z_t
        # (not h_full as the conservative bbox would say).
        r = self.od / 2
        return BBox(min=(-r, -r, 0), max=(r, r, self.z_t))

    def prefers_shift_at_anchor(self, anchor) -> bool:
        # Same rationale as the standard-library `FilletRing`: our bottom
        # annular cap exactly matches the host wall's top face, so the
        # framework's `cross_section_extend` slab is itself coplanar with
        # the host's outer cylinder and CGAL leaves non-manifold edges.
        # Opt the planar top/bottom anchors into `bond='shift'` so
        # `.attach(host, fuse=True)` resolves to the shift path. The
        # eps drift on the opposite face is invisible on a fillet rim.
        if anchor.kind != "planar":
            return False
        return abs(anchor.normal[2]) > 1.0 - 1e-9


class LensHousing(Component):
    """Generic lens barrel: lower recess + flange + upper housing (narrow
    or funnel-widened) + element holders + front fillet. A matching hood
    Component can read the outer dimensions and hood cone angle off this
    housing to mate without shared scope."""

    FRONT_FILLET_OFFSET = 5.0   # aperture rim inset from the front element's grip ID

    stop = Param(Stop, default=None)
    mating_disc = Param(MatingDisc, default=None)
    helicoid_focus_slot = Param(HelicoidFocusSlot, default=None)
    equations = """
        # Wall-thickness split: the lower (M57-fit) section needs to fit
        # inside the camera's M57 throat, so its OD is constrained from
        # above by camera-body geometry — typically a thin (~1 mm radial)
        # wall. The flange-flange/funnel/upper section sits outside the
        # camera body and is wide enough to host a stepped lap joint
        # internally — typically a thick (~5 mm radial) wall. The two
        # are independent because they're constrained by different
        # physical realities.
        lower_housing_od = lower_housing_id + 2 * lower_barrel_thk
        hood_base_angle = 90 - fov_angle / 2
        lower_housing_od, lower_housing_id, housing_insertion_depth, lower_barrel_thk, upper_barrel_thk > 0
        flange_flange_od, flange_flange_len, fov_angle, hood_base_angle > 0
        grip_depth, grip_width > 0
        mount_offset >= 0
        # `housing_insertion_depth` is how far the lower housing reaches
        # into the camera body below the camera flange plane (z=0). It's
        # set by the camera's M57 throat depth — a fixed physical
        # constraint of the camera body, not a design choice.
        # `lower_housing_len` is the TOTAL length of the lower (M57-fit)
        # tube, spanning from the deepest point inside the throat
        # (z = -housing_insertion_depth) up through the camera flange and
        # the mount-ring zone to the top of the mount ring (z = mount_offset).
        # The flange plane (z=0) sits inside this section, not at one of
        # its boundaries.
        lower_housing_len = housing_insertion_depth + mount_offset
        unconstricted = tuple(e for e in elements:tuple if not e.constricted)
        max_upper_ele_dia = max((e.dia for e in unconstricted), default=0.0)
        is_wide = max_upper_ele_dia > lower_housing_id
        expansion_funnel_len = min((e.face_z_bot for e in unconstricted), default=inf)
        upper_housing_len = max(e.face_z_top for e in elements)
        upper_housing_od = (max_upper_ele_dia + 2 * upper_barrel_thk) if is_wide else flange_flange_od
        all(not e.constricted or e.throat_dia_required <= lower_housing_id for e in elements)
        # Wide-mode invariant: in funnel variants the funnel runs from
        # mount_offset (the top of the mount-ring zone, where the lower
        # tube ends) to expansion_funnel_len (the bottom of the lowest
        # unconstricted element). The funnel needs positive height, so the
        # lowest unconstricted element must sit strictly above the mount-
        # ring zone. (`element()` now defines constricted as face_z_bot <
        # mount_offset, so unconstricted elements have face_z_bot >=
        # mount_offset; this rule guards the equality edge case.)
        not is_wide or expansion_funnel_len > mount_offset
        # Stop slot must lie entirely in a section we can handle:
        #   (a) below the flange-flange (z <= mount_offset) — uniform
        #       lower-housing OD;
        #   (b) above the flange/funnel transition — uniform upper-
        #       housing OD;
        #   (c) (wide variant only) entirely within the funnel range
        #       [mount_offset, expansion_funnel_len] — handled by the
        #       per-gripper-OD logic in `wall_od_at_z` and the StopHolder
        #       od_top/od_bot pair.
        # The flange-overlap and mount-ring/flange transition zones stay
        # forbidden because they have a wall-OD discontinuity no cylindrical
        # gripper can span. The `?stop` references make these lines auto-
        # skip when no stop is supplied.
        slot_lo = ?stop.spacing - (stop.thk + stop.clr) / 2
        slot_hi = ?stop.spacing + (stop.thk + stop.clr) / 2
        upper_floor = expansion_funnel_len if is_wide else mount_offset + flange_flange_len
        ?slot_hi <= mount_offset or slot_lo >= upper_floor or (is_wide and slot_lo >= mount_offset and slot_hi <= expansion_funnel_len)
    """

    def _sections(self):
        """List of `HousingSection` Components describing the housing's
        wall geometry, top to bottom (order doesn't matter — sections
        may overlap in z, e.g. flange + funnel in wide mode where the
        flange's wider OD wins). The single source of truth for both
        `build()` and `wall_od_at_z`."""
        lower_id = self.lower_housing_id
        mo = self.mount_offset
        flange_top = mo + self.flange_flange_len
        sections = [
            # Lower (M57-fit) section: spans the M57 throat plus the
            # mount-ring zone, all at the thin wall.
            HousingSection(
                z_bot=-self.housing_insertion_depth, z_top=mo,
                bot_id=lower_id, top_id=lower_id,
                thk=self.lower_barrel_thk,
            ),
            # Flange-flange: thicker wall, sits on top of the mount ring.
            HousingSection(
                z_bot=mo, z_top=flange_top,
                bot_id=lower_id, top_id=lower_id,
                thk=(self.flange_flange_od - lower_id) / 2,
            ),
        ]
        if self.is_wide:
            # Funnel widens the bore to clear the largest unconstricted
            # element; its wall uses upper_barrel_thk. Overlaps the
            # flange in z=[mo, flange_top]; in wall_od_at_z the flange's
            # wider OD wins via the max() over containing sections.
            sections.append(HousingSection(
                z_bot=mo, z_top=self.expansion_funnel_len,
                bot_id=lower_id, top_id=self.max_upper_ele_dia,
                thk=self.upper_barrel_thk,
            ))
            # Upper (above the funnel): uniform wide bore.
            sections.append(HousingSection(
                z_bot=self.expansion_funnel_len, z_top=self.upper_housing_len,
                bot_id=self.max_upper_ele_dia, top_id=self.max_upper_ele_dia,
                thk=self.upper_barrel_thk,
            ))
        else:
            # Non-wide upper: just continues the flange-flange's OD.
            sections.append(HousingSection(
                z_bot=flange_top, z_top=self.upper_housing_len,
                bot_id=lower_id, top_id=lower_id,
                thk=(self.upper_housing_od - lower_id) / 2,
            ))
        if self.mating_disc is not None:
            # Mating disc: extra ring on the housing's outer surface
            # bridging the gap to the lens-mount ring's bore. ID =
            # lower_housing_od (wraps the lower section); OD and z range
            # come from the MatingDisc spec.
            md = self.mating_disc
            sections.append(HousingSection(
                z_bot=md.z_bot, z_top=md.z_top,
                bot_id=self.lower_housing_od, top_id=self.lower_housing_od,
                thk=(md.od - self.lower_housing_od) / 2,
            ))
        return sections

    def wall_od_at_z(self, z):
        """Outer-wall diameter at axial position z. Used to size each
        stop-holder gripper to its local wall thickness so a gripper
        that lands in a narrowing funnel doesn't poke out past the wall.
        Returns the max OD across all sections containing z (overlapping
        sections — flange + funnel in wide mode — resolve via max)."""
        matching = [s for s in self._sections() if s.z_bot <= z <= s.z_top]
        if not matching:
            return 0.0
        return max(s.od_at(z) for s in matching)

    def wall_id_at_z(self, z):
        """Inner bore diameter at axial position z. Used to size the
        stop disc and the gripper's inner cylinder to the local bore,
        so the disc fills the bore and the gripper intrudes only
        `grip_depth/2` into the optical path regardless of which
        section the stop lands in. Overlapping sections resolve via
        MIN — wall material lives wherever any section has material,
        so the bore is bounded by the narrowest inner radius at z."""
        matching = [s for s in self._sections() if s.z_bot <= z <= s.z_top]
        if not matching:
            return 0.0
        return min(s.id_at(z) for s in matching)

    def _front_fillet(self):
        """Build the same TruncFilletRing instance used in `build()`,
        so its tight_bbox / equations are usable from here without
        duplicating the construction args."""
        front_ele = max(self.elements, key=lambda e: e.spacing)
        return TruncFilletRing(
            id=front_ele.dia - self.grip_depth + self.FRONT_FILLET_OFFSET,
            od=self.upper_housing_od,
            base_angle=self.hood_base_angle,
            slant="inwards",
            rim_width=2,
        )

    def _helicoid_slot_cutter(self):
        """Curved-bar cutter for the helicoid focus slot. Cylindrical
        shell (matching the lower wall radially) intersected with a
        circumferential wedge centered at `slot.angle`. The inner
        cylinder radius (`lower_housing_id/2 − inner_eps`) stays inside
        the element-holder outward overshoot (`+ default_eps()`), so
        the cutter never reaches holder material. The outer cylinder
        pokes past the wall OD by a small delta for a clean cut at the
        outer surface."""
        import math
        s = self.helicoid_focus_slot
        h = s.z_top - s.z_bot
        inner_eps = 0.5 * default_eps()       # < holder's outward overshoot, safe
        outer_delta = 0.1                     # past OD; just for clean exterior cut
        outer_r = self.lower_housing_od / 2 + outer_delta
        inner_r = self.lower_housing_id / 2 - inner_eps
        # Angular half-width = (arc / 2) / radius, in degrees. Use the
        # OD as the reference radius so `width` reads as the arc length
        # along the visible outer face.
        half_arc_deg = math.degrees((s.width / 2) / (self.lower_housing_od / 2))
        shell = Tube(h=h, od=2 * outer_r, id=2 * inner_r)
        wedge = Sector(
            r=outer_r,
            angles=(s.angle - half_arc_deg, s.angle + half_arc_deg),
        ).linear_extrude(height=h)
        return intersection(shell, wedge).up(s.z_bot)

    def tight_bbox(self):                                  # framework hook: declare true post-Difference extents
        # Default tight_bbox would walk into the slot's `difference()`
        # and raise. The slot is fully contained within the barrel, so
        # it doesn't change outer extents. Compute the true envelope
        # from the wall sections (max OD across all of them) plus the
        # front fillet's truncated rim height (read from the fillet's
        # own equation-derived z_t — no math duplication).
        sections = self._sections()
        max_r = max(
            max(s.od_at(s.z_bot) for s in sections),
            max(s.od_at(s.z_top) for s in sections),
        ) / 2
        min_z = -self.housing_insertion_depth
        max_z = self.upper_housing_len + self._front_fillet().z_t
        return BBox(min=(-max_r, -max_r, min_z), max=(max_r, max_r, max_z))

    def build(self):
        lower_id = self.lower_housing_id
        upper_id = self.max_upper_ele_dia if self.is_wide else lower_id

        # Wall sections: lower thin / flange-flange / (funnel / upper) /
        # optional mating disc. Single source of truth (`_sections()`)
        # used by both this build and `wall_od_at_z`.
        sections = self._sections()
        # Bare barrel — engravings are no longer part of build() so the
        # force_render scope in the variant chain caches just the
        # structural mesh. See `engravings()` for the cutter geometry
        # and the variant methods for where it's applied.
        barrel = union(*sections)

        # Slot OD: the maximum housing OD at the slot's z range. In the
        # uniform-OD allowed bands this is just the local OD; in the
        # funnel band the slot's TOP has the largest local OD (funnel
        # widens upward), so we use that. +1 mm radial overshoot avoids
        # cylinder-on-cylinder coplanar faces in the difference.
        if self.stop is not None:
            s = self.stop
            slot_h = s.thk + s.clr
            half_gw = 0.5 * self.grip_width
            slot_od = self.wall_od_at_z(s.spacing + slot_h / 2)
            slot_id = self.wall_id_at_z(s.spacing) - 0.1
            slot = Tube(
                h=slot_h, od=slot_od + 1, id=slot_id,
            ).halve([0, 1, 0]).up(s.spacing - slot_h / 2)
            barrel = difference(barrel, slot)

        if self.helicoid_focus_slot is not None:
            barrel = difference(barrel, self._helicoid_slot_cutter())

        yield barrel

        for e in self.elements:
            holder_od = lower_id if e.constricted else upper_id
            # Known limitation (wide variants only): when an unconstricted
            # element's dia equals max_upper_ele_dia, holder_od == its
            # own dia and the holder's surround tube has thk =
            # -e.clearances.radial/2 (negative). The fix is to size the
            # widest element's holder off upper_housing_od (wall outer)
            # rather than upper_id (wall inner == element dia). Leaving
            # as a follow-up.
            yield ElementHolder(
                element=e, od=holder_od,
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        if self.stop is not None:
            # Per-gripper OD: each gripper's outer cylinder is sized to
            # the local wall OD at the gripper's BOTTOM (the narrowest
            # point in its z extent for an upward-widening funnel), so
            # the gripper is fully embedded in wall material with no
            # radial overshoot anywhere along its height.
            upper_z_bot = s.spacing + slot_h / 2
            lower_z_bot = s.spacing - slot_h / 2 - half_gw
            yield StopHolder(
                stop=self.stop,
                od_top=self.wall_od_at_z(upper_z_bot),
                od_bot=self.wall_od_at_z(lower_z_bot),
                barrel_id=self.wall_id_at_z(s.spacing),
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        yield self._front_fillet().attach(barrel, fuse=True)

    def engravings(self):
        """Cutter geometry for the two engravings, in housing-local frame.

        Returned as a single union so a variant chain can apply
        ``difference(housing.force_render(), housing.engravings())``
        and keep the per-glyph CGAL work out of the cached subtree.

        - Upper-housing label: text on the topmost uniform section's
          ``outer_wall``. Picks the same section ``build()`` would have
          decorated (``z_top == upper_housing_len`` and uniform OD).
        - Front-fillet label: text on the truncated fillet's
          ``slanted_face``. Positioned with ``.up(upper_housing_len)``
          to match where ``attach(barrel, fuse=True)`` lands the fillet
          in ``build()`` (sub-mm fuse offset is below engraving tolerance)."""
        upper_section = next(
            s for s in self._sections()
            if s.z_top == self.upper_housing_len and s.bot_id == s.top_id
        )
        upper_label = "\n".join(
            [f"{design_name}:"]
            + [e.code for e in self.elements]
            + [print_stamp()]
        )
        upper_cutter = upper_section.text_geometry(
            label=upper_label, on="outer_wall", angle=0,
            font_size=4, line_spacing=1.4, relief=-0.6,
        )
        fillet_cutter = self._front_fillet().up(self.upper_housing_len).text_geometry(
            label=FRONT_FILLET_LABEL,
            on="slanted_face", angle=0,
            font_size=4, relief=-0.6,
        )
        return union(upper_cutter, fillet_cutter)


class LensHood(Component):
    """Generic clip-on hood sized by a paired housing. `housing_upper_od`
    and `hood_base_angle` come from the housing; the rest are hood-specific.
    Built in its mounted orientation: coupler at z=0, funnel flaring upward.
    The print variant flips it."""

    equations = """
        housing_upper_od, hood_base_angle, wall_thk, hood_length, coupler_overlap > 0
        hood_clr >= 0
        id_coupler = housing_upper_od + hood_clr
        od_coupler = id_coupler + 2 * wall_thk
        flare_od = housing_upper_od + 2 * hood_length * tan(90 - hood_base_angle)
        # Optional raised-text label wrapped around the coupler's outer
        # wall. Empty string = no engraving. Applied directly to the
        # coupler Tube in build() (via `add_text` on Tube's built-in
        # `outer_wall` anchor) so the text wraps with the framework's
        # default cylindrical orientation: upright glyphs, line reading
        # L-to-R when viewed from outside, glyph bottoms toward -Z.
        ?label:str = ?label or ""
    """

    def build(self):                                       # framework hook: required; returns the shape
        coupler = Tube(
            h=self.coupler_overlap, id=self.id_coupler, thk=self.wall_thk,
        )
        if self.label:
            # at_z nudges the line axially. The framework pre-shifts the
            # text by -font_size/2 to "center" the line on the surface,
            # but that centers the full em-box; the visible cap body
            # (~0.7 * font_size) ends up biased toward -Z because the
            # descender space contributes to the shift without contributing
            # visible mass. at_z = (font_size - cap_height) / 2 ≈
            # 0.15 * font_size compensates so the cap body's centerline
            # sits at the anchor's z.
            coupler = coupler.add_text(
                label=self.label, on="outer_wall",
                font_size=4, relief=0.5,
                at_z=1.8,
            )
        yield coupler
        yield Funnel(
            h=self.hood_length, thk=self.wall_thk,
            bot_od=self.housing_upper_od, top_od=self.flare_od,
        ).attach(coupler, fuse=True)
        yield FilletRing(
            id=self.id_coupler, od=self.od_coupler,
            base_angle=63, slant="inwards",
        ).attach(coupler, fuse=True)


def _lap_split_x_tight_bbox(child, *, side, overlap, clearance=0.0, **_):
    """tight_bbox hook for `lap_split_x`. The transform's body builds a
    top-level Difference (groove subtracted from union(half, tongue)),
    which the framework's bbox visitor can't tighten on its own. We know
    the answer: the result keeps one X half of the housing plus a
    `tongue_w = overlap - clearance` tongue extending past the cut plane
    on the other side. Z and Y are unchanged from the child."""
    from scadwright import tight_bbox as _tb
    cb = _tb(child)
    tongue_w = overlap - clearance
    if side == "minus":
        return BBox(min=cb.min, max=(tongue_w, cb.max[1], cb.max[2]))
    return BBox(min=(-tongue_w, cb.min[1], cb.min[2]), max=cb.max)


@transform("lap_split_x", tight_bbox=_lap_split_x_tight_bbox)
def lap_split_x(node, *, side, overlap, mid_radius, z_min=None, clearance=0.0):
    """Halve the host shape at X=0 with a stepped lap joint of depth `overlap`
    at radial position `mid_radius`. `side` is 'minus' (keep X<=0) or
    'plus' (keep X>=0). The 'minus' and 'plus' results mate INVERSELY
    across the cut plane (not as mirror images): one carries the outer
    extension and the inner recess; the other carries the matching outer
    recess and inner extension.

    Specifically:
      - minus keeps X<=0; its OUTER layer (r >= mid_radius) is extended
        past X=0 into +X by `overlap` (tongue), and its INNER layer
        (r < mid_radius) is recessed from X=0 in -X by `overlap` (groove).
      - plus keeps X>=0; its OUTER layer is recessed (groove) at +X for
        `overlap` mm to receive minus's outer tongue, and its INNER layer
        is extended into -X by `overlap` (tongue) to fill minus's inner
        groove.

    Joint planes therefore land at X=+overlap (outer layer) and at
    X=-overlap (inner layer). Light path between bore and outer surface
    zigzags through the step — light-tight. The step constrains relative
    XY position — self-aligning. Mates by pure X-translation (radial
    press-fit), no axial sliding required.

    `mid_radius` must lie inside the wall everywhere along Z (between
    the bore and the outer wall in every section), or the layers will
    have zero thickness somewhere.

    `z_min` (optional) confines the lap features to z >= z_min. Below
    z_min the housing is just cleanly halved at X=0 with no lap geometry
    — useful when the wall is too thin to host the step (e.g. the M57-fit
    section of a lens housing).

    `clearance` (mm) shrinks the tongue (NOT the groove) so the press
    seats with some play. The shrink is applied two ways: tongue X-extent
    is shorter by `clearance` at the TIP (gives axial seating play); the
    tongue's step-face boundary is pulled away from `mid_radius` by
    `clearance` (gives radial play at the step inside the joint). The
    tongue's outer-cylinder surface (or bore surface for the inner
    tongue) is unchanged so the visible cylinder surface flushes at the
    joint. Default 0 (zero-clearance, may bind on tight prints).
    """
    if side not in ("minus", "plus"):
        raise ValueError(f"side must be 'minus' or 'plus', got {side!r}")
    sign = -1 if side == "minus" else 1
    # `halve()` would auto-size its cutter from the input shape's bbox.
    # As a hoisted custom transform, the shape arg here is a placeholder
    # (1x1x1) at module-build time, not the real housing — so we pass an
    # explicit `size` to suppress bbox introspection.
    big = 200.0
    half = node.halve([sign, 0, 0], size=big)

    # Slabs need only enclose the housing, not be globe-sized. Intersection
    # clips them to the wall geometry, so the step automatically conforms
    # to varying OD/ID along Z (e.g. the funnel transition in wide
    # variants). `big` is sized generously vs typical lens housings (a few
    # hundred mm in any axis), so any reasonable design is enclosed; the
    # exact value matters because OpenSCAD's preview mode draws the full
    # auxiliary geometry every frame and very large slabs cost real
    # interactivity. When z_min is set, the slab is anchored at z=z_min
    # (not Z-centered) so only z >= z_min material is included.
    z_centered = z_min is None
    z_axes = "yz" if z_centered else "y"

    def _slab(width):
        c = cube([width, big, big], center=z_axes)
        return c if z_centered else c.up(z_min)

    tongue_w = overlap - clearance
    # Groove: full overlap on the slab, mid_radius for the radial split.
    # Tongue: shorter slab (clearance at the tip) and the radial split is
    # pulled away from mid_radius by clearance (further out for an outer-
    # layer tongue, further in for an inner-layer tongue), giving the
    # tongue play at both the step face and the tip when seated.
    pos_groove_slab = _slab(overlap)                       # X in [0, overlap]
    neg_groove_slab = _slab(overlap).left(overlap)         # X in [-overlap, 0]
    pos_tongue_slab = _slab(tongue_w)                      # X in [0, tongue_w]
    neg_tongue_slab = _slab(tongue_w).left(tongue_w)       # X in [-tongue_w, 0]

    # `inner_volume` is the cylinder of radius `mid_radius` around Z;
    # outer-layer = node - inner_volume; inner-layer = node & inner_volume.
    # `fn=8` keeps the mask cheap to draw in OpenSCAD preview — the
    # cylinder is invisible in the final geometry, so its radial polygon
    # count doesn't affect output, only per-frame preview cost.
    inner_volume = cylinder(r=mid_radius, h=big, center="z", fn=8)
    inner_volume_outer_tongue = cylinder(r=mid_radius + clearance, h=big, center="z", fn=8)
    inner_volume_inner_tongue = cylinder(r=mid_radius - clearance, h=big, center="z", fn=8)

    if side == "minus":
        # Outer-layer tongue at +X, inner-layer groove at -X.
        tongue = difference(intersection(node, pos_tongue_slab), inner_volume_outer_tongue)
        groove = intersection(intersection(node, neg_groove_slab), inner_volume)
    else:  # plus
        # Inner-layer tongue at -X, outer-layer groove at +X.
        tongue = intersection(intersection(node, neg_tongue_slab), inner_volume_inner_tongue)
        groove = difference(intersection(node, pos_groove_slab), inner_volume)

    return difference(union(half, tongue), groove)


@transform("lap_splay")
def lap_splay(node, *, side, lap_overlap=0.0):
    """Lay one housing half flat on the print bed: rotate so the cut
    face lies parallel to the bed (cut-face-down) and lift the result
    by `lap_overlap` so the lap-joint tongue (which extends past the
    cut plane and would otherwise dip below Z=0 after the rotation)
    rests on the bed.

    `side` selects the rotation direction so the kept material lands
    above the bed regardless of which half was cut. `lap_overlap` is
    the same value passed to `.lap_split_x()`; it's explicit here because
    the framework's `bbox()` returns a conservative AABB across `halve`,
    so the actual minimum Z can't be derived from the splayed shape.
    Pass 0.0 if the half has no lap joint.
    """
    angle = 90 if side == "minus" else -90
    return node.rotate([0, angle, 0]).up(lap_overlap)


# =============================================================================
# CONCRETE: the specific M57 design
# =============================================================================


GRIP_DEPTH = 1.5
GRIP_WIDTH = 1.0

# Bayonet contract — single source of truth for dimensions shared with
# the lens mount. The housing reads three values from `BronicaS2Bayonet`:
#   - mount_protrusion: axial extent of the lens-mount ring above the
#     camera flange (z=[0, mount_protrusion]). The M57-restricted lower
#     tube extends up to this z; the flange-flange rests on top of the
#     ring; the funnel starts here with a sharper angle so the housing
#     stays the same total length and no elements move in absolute z.
#   - lens_mount_od: OD of the lens-mount ring; sets `flange_flange_od`
#     so the two parts rest flush at the assembly seam.
#   - lens_mount_bore: inner bore of the ring; the mating disc fits
#     inside it (with MATING_DISC_CLEARANCE slip).
# Local alias for the most-used value — variant code stays readable.
MOUNT_OFFSET = BronicaS2Bayonet.mount_protrusion

# Diametral slip-fit clearance for the mating disc inside the lens-mount
# ring's bore. 0.3 mm diametral = 0.15 mm radial per side — enough that
# the disc seats without binding on typical FDM over-extrusion / warp.
MATING_DISC_CLEARANCE = 0.25

# Waterhouse stop: 1.5mm disc, 0.5mm slot clearance for sliding fit.
# Depth and hole-diameter list come from the design (defaults below or
# loaded from --config).
STOP_THK = 1.5
STOP_CLR = .5

# Built-in defaults (used unless --from-json overrides). Front to rear.
# `mounted_od` is optional and only applies to the element that carries it
# (its mount/cell is wider than the bare lens); the housing uses
# max(diameter, mounted_od) for clearance on those elements.
# `extra_radial` (mm) is added on top of DEFAULT_ELEMENT_CLEARANCES.radial
# for that element's holder — looser fit for elements whose OD measures
# slightly larger than the catalog dia or whose edge profile chips into
# the surround. Default 0 (use the project-wide radial clearance as-is).
DEFAULT_ELEMENTS_DATA = (
    {"code": "L7325",  "type": "NMN", "diameter": 52.0, "edge_thickness": 6.2, "spacing":  34.6, "extra_radial": 0.3},
    {"code": "L14523", "type": "ACH", "diameter": 35.0, "mounted_od": 44.4, "edge_thickness": 13, "spacing":  12.6, "extra_radial": 0.8},
    {"code": "L13088", "type": "BCX", "diameter": 42.5, "edge_thickness":  2.2, "spacing":  -9.4, "extra_radial": 0.2},
)
DEFAULT_STOP_DEPTH = -2.7
DEFAULT_STOP_HOLE_D = (20.0, 14.3, 10.0, 7.3)
DEFAULT_FOV_ANGLE = 57.0
DEFAULT_FOCAL_LENGTH = 89
DEFAULT_MAX_APERTURE = 2.9
DEFAULT_DESIGN_NAME = "lens_housing"


# Optional design override: invoke with `--from-json <path>`. The JSON
# carries `elements` (list of element dicts) and `stop` (dict with `depth`
# and `hole_diameters`); optionally `fov` (hood half-angle source), `name`
# (design label, surfaced as `design_name` for downstream use), and
# `focal_length` / `max_aperture` (engraved on the front fillet ring).
# Missing required keys surface as KeyError when the data is consumed
# below; the framework absorbs file-not-found / invalid-JSON at parse time.
_cfg = from_json()
if _cfg is not None:
    _elements_data = _cfg["elements"]
    STOP_DEPTH = float(_cfg["stop"]["depth"])
    STOP_HOLE_D = tuple(float(d) for d in _cfg["stop"]["hole_diameters"])
    FOV_ANGLE = float(_cfg.get("fov", DEFAULT_FOV_ANGLE))
    design_name = _cfg.get("name", DEFAULT_DESIGN_NAME)
    FOCAL_LENGTH = float(_cfg.get("focal_length", DEFAULT_FOCAL_LENGTH))
    MAX_APERTURE = float(_cfg.get("max_aperture", DEFAULT_MAX_APERTURE))
else:
    _elements_data = DEFAULT_ELEMENTS_DATA
    STOP_DEPTH = DEFAULT_STOP_DEPTH
    STOP_HOLE_D = DEFAULT_STOP_HOLE_D
    FOV_ANGLE = DEFAULT_FOV_ANGLE
    design_name = DEFAULT_DESIGN_NAME
    FOCAL_LENGTH = DEFAULT_FOCAL_LENGTH
    MAX_APERTURE = DEFAULT_MAX_APERTURE

FRONT_FILLET_LABEL = f"BRIOTAR {FOCAL_LENGTH:g}mm f/{MAX_APERTURE:g}"

def _effective_dia(e):
    """Use the mount OD when wider than the bare lens; bare diameter otherwise."""
    d = float(e["diameter"])
    if "mounted_od" in e:
        return max(d, float(e["mounted_od"]))
    return d


def _element_clearances(e):
    """Per-element clearances. Starts from the project default and adds
    the dict's `extra_radial` (a DIAMETER delta — `clearances.radial`
    is added directly to the element diameter to get the holder's bore,
    so the actual per-side radial gap is `radial / 2`). Axial uses the
    default; override per-element with an `extra_axial` key if a future
    element needs it."""
    return ElementClearances(
        axial=DEFAULT_ELEMENT_CLEARANCES.axial + float(e.get("extra_axial", 0)),
        radial=DEFAULT_ELEMENT_CLEARANCES.radial + float(e.get("extra_radial", 0)),
    )


ELEMENTS = tuple(
    element(
        code=e["code"], type=e["type"],
        dia=_effective_dia(e), edge_thk=float(e["edge_thickness"]),
        spacing=float(e["spacing"]),
        grip_width=GRIP_WIDTH,
        mount_offset=BronicaS2Bayonet.mount_protrusion,
        clearances=_element_clearances(e),
    )
    for e in _elements_data
)
THE_STOP = Stop(spacing=STOP_DEPTH, thk=STOP_THK, clr=STOP_CLR)


# Stepped lap joint between the two printed housing halves. The wall is
# thick enough (5 mm radial) to host the step internally with both layers
# >=2.5 mm thick everywhere; no external rib needed. `LAP_MID_RADIUS` sits
# between the bore (r=27) and the outer wall (r=32 lower, r=33.5 flange/
# upper); the step is centered on the lower wall and biased toward the
# bore in flange/upper, but both layers stay >=2.5 mm.
LAP_OVERLAP = 3.0
LAP_MID_RADIUS = 29.5
# Press-fit clearance between the lap-joint tongue and groove: shrinks
# the tongue (NOT the groove) at the tip and at the radial step face,
# so the parts seat with ~LAP_CLEARANCE mm of play in both directions
# instead of binding on a tight FDM print. Outer (visible) cylinder
# surface is unchanged so the joint flushes at the wall.
# Was 0.2 — that snap was too aggressive: the joint went together fine
# but cracked the wall on disassembly. Bumped to 0.4 since the lens-
# mount ring and hood handle alignment, the lap joint just needs to
# keep the halves indexed (light-tight + radial register, not load-
# bearing).
LAP_CLEARANCE = 0.4


class M57LensHousing(LensHousing):
    # Lower (M57-fit) section: OD must clear the camera's M57 throat
    # (~57 mm), so it's set just under that with a thin (1 mm radial)
    # wall. This is a hard physical constraint, not negotiable for fit.
    lower_housing_od = 55.5
    lower_barrel_thk = 1.5   # radial wall (thin)
    # M57 throat penetration: how far the lower housing reaches into the
    # camera body below the flange plane. Set by the camera's M57 throat
    # depth — physical, not a design choice. The total lower-tube length
    # (`lower_housing_len`) is derived as housing_insertion_depth + mount_offset.
    housing_insertion_depth = 14.5
    # Upper section (flange-flange / funnel / upper) wall thickness: thick
    # enough to host the stepped lap joint internally (5 mm radial gives
    # 2.5/2.5 mm layers around mid_radius). The upper section sits outside
    # the camera body so its OD is unconstrained by the throat.
    upper_barrel_thk = 5.0   # radial wall (thick — hosts the lap joint internally)
    # The flange-flange is the wider band of the housing's wall (above the
    # lower M57-fit section) whose bottom rim rests on top of the lens-
    # mount ring. Set equal to the ring's OD (from the bayonet spec) so
    # the joint flushes at the seam.
    flange_flange_od = BronicaS2Bayonet.lens_mount_od
    flange_flange_len = 5.0
    fov_angle = FOV_ANGLE
    grip_depth = GRIP_DEPTH
    grip_width = GRIP_WIDTH
    mount_offset = BronicaS2Bayonet.mount_protrusion
    # Mating disc: bridges the radial gap between the lower section
    # (OD=56) and the lens-mount ring's bore (from the bayonet spec).
    # Disc OD = bore − MATING_DISC_CLEARANCE (slip-fit, ~0.15 mm radial).
    # Spans z=[1.2, mount_offset] in the housing's world frame: the bottom is
    # 1.2 mm above the rotation channel's roof (the channel cavity tops
    # out at world z=0 = mount_offset − rest_z; that 1.2 mm of axial
    # clearance keeps the disc out of the channel and away from the
    # camera lugs that sit there when locked); the top flushes with the
    # lens-mount tube's top face at world z=mount_offset.
    mating_disc = MatingDisc(
        od=BronicaS2Bayonet.lens_mount_bore - MATING_DISC_CLEARANCE,
        z_bot=1.2, z_top=BronicaS2Bayonet.mount_protrusion,
    )
    # Helicoid focus slot: spans the lower throat from its deepest point
    # (z = -housing_insertion_depth) up to `offset_from_flange` mm below
    # the flange plane (z=0). Position, dimensions, and offset live in
    # the bayonet spec — see `BronicaS2Bayonet`.
    helicoid_focus_slot = HelicoidFocusSlot(
        angle=BronicaS2Bayonet.helicoid_focus_slot_angle,
        width=BronicaS2Bayonet.helicoid_focus_slot_width,
        depth=BronicaS2Bayonet.helicoid_focus_slot_depth,
        z_bot=-housing_insertion_depth,
        z_top=-BronicaS2Bayonet.helicoid_focus_slot_offset_from_flange,
    )
    elements = ELEMENTS
    stop = THE_STOP


class M57LensHood(LensHood):
    wall_thk = 2.0
    hood_clr = 0.25
    hood_length = 20.0
    coupler_overlap = 6.0


# =============================================================================
# DESIGN: shared parts + variant methods
# =============================================================================


def _make_stop_discs(housing, hole_diameters):
    """One `WaterhouseStop` per hole diameter, all sharing the same
    barrel dimensions, thickness, and depth. Disc diameters are sourced
    from the housing at the stop's z, so the inner semicircle fills the
    local bore and the outer semicircle flushes with the local wall OD
    regardless of which section (lower / flange / funnel / upper) the
    stop sits in."""
    z = STOP_DEPTH
    return tuple(
        WaterhouseStop(
            inner_diameter=housing.wall_id_at_z(z),
            outer_diameter=housing.wall_od_at_z(z),
            thk=STOP_THK,
            hole_d=h,
            spacing=STOP_DEPTH,
        )
        for h in hole_diameters
    )


# Bambu X2D buildable area on the bed (mm). Layouts must fit within these.
BAMBU_X2D_PLATE = (256.0, 256.0)


class LensHousingDesign(Design):
    housing = M57LensHousing()
    hood = M57LensHood(
        housing_upper_od=housing.upper_housing_od,
        hood_base_angle=housing.hood_base_angle,
        label=FRONT_FILLET_LABEL,
    )
    stop_discs = _make_stop_discs(housing, STOP_HOLE_D)

    def _splayed_halves(self):
        """The two housing halves, lap-jointed at X=0 and laid flat for
        the bed. Returned as a (minus, plus) pair. The lap is confined
        to z >= MOUNT_OFFSET (the thick-walled section above the mount
        ring); the thin-walled lower section below z=MOUNT_OFFSET gets
        a clean halve only.

        Each lap_split_x result is wrapped in `force_render()` so
        OpenSCAD computes the lap-jointed half once via CGAL on first
        compile and caches the resulting mesh; subsequent F5 frames
        (camera rotation in preview) draw the cached mesh instead of
        re-evaluating the deep CSG tree every frame.

        Engravings live OUTSIDE force_render: the bare structural half
        is what gets cached, and the engraving cutter (~42 glyph cuts)
        is differenced in via preview-CSG per frame. Without this split,
        every glyph difference ends up inside the CGAL evaluation and
        preview-open time balloons. The engravings sit on the +X half
        (angle=0 for both labels), so only the plus side needs the
        difference; the minus half goes through unmodified."""
        eng = self.housing.engravings()
        minus = self.housing.lap_split_x(
            side="minus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
            z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE,
        ).force_render()
        plus_bare = self.housing.lap_split_x(
            side="plus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
            z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE,
        )
        plus = difference(plus_bare.force_render(), eng).with_bbox_from(plus_bare)
        return (
            minus.lap_splay(side="minus", lap_overlap=LAP_OVERLAP),
            plus.lap_splay(side="plus", lap_overlap=LAP_OVERLAP),
        )

    @variant(fn=48)
    def print(self):
        # Compact bed layout sized for the Bambu X2D plate. The housing
        # is split into two distinct halves along X=0 with a stepped lap
        # joint (light-tight, self-aligning); both halves print cut-face-
        # down. Each splayed half is rotated 90° around Z so its long
        # axis runs along Y; the two halves sit side-by-side along Y,
        # forming `pair`. One waterhouse stop disc sits to the +X side
        # of `pair` via pack_on_bed, which also fit-checks the plate.
        minus, plus = self._splayed_halves()
        half_minus = minus.rotate([0, 0, 90])
        half_plus = plus.rotate([0, 0, 90])
        gap = 12   # ~1.2cm clearance between objects

        # Stack minus at -Y, plus at +Y with `gap` between them. This
        # cross-axis stacking is the orientation that fits the housing
        # length on the bed; pack_on_bed only handles single-row layout
        # along +X, so the Y-stack is built by hand and passed in as
        # one unit.
        minus_bb = half_minus.bbox
        plus_bb = half_plus.bbox
        pair = union(
            half_minus.back(minus_bb.max[1] + gap / 2),
            half_plus.forward(-plus_bb.min[1] + gap / 2),
        )

        flat_stop = self.stop_discs[0].down(STOP_DEPTH - STOP_THK / 2)
        return pack_on_bed(pair, flat_stop, gap=gap, plate=BAMBU_X2D_PLATE)

    @variant(fn=60, default=True)
    def print_vertical(self):
        # Both halves printed vertically (optical axis = print Z), lens-
        # side-down: the OD step at the flange is an inward step (no
        # overhang), the lap-joint features get first-layer accuracy at
        # the bed, and the wider lens-side face gives a generous bed-
        # contact area. Suited for the Bambu X2D's dual-head PETG-on-PLA
        # support workflow — element-gripper undersides print over PETG
        # and break off cleanly. Trades ~25% extra wall-clock vs the
        # horizontal `print` variant for smoother bore circumferential
        # finish and stronger resistance to bayonet-engagement torque.
        # `.force_render()` collapses each lap-jointed half into a single
        # CGAL-evaluated mesh on first compile; subsequent OpenSCAD F5
        # frames just draw the cached mesh, sidestepping the expensive
        # per-frame CSG re-evaluation that makes preview-mode camera
        # rotation painful on this geometry.
        eng = self.housing.engravings()
        minus = self.housing.lap_split_x(
            side="minus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
            z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE,
        ).force_render()
        plus_bare = self.housing.lap_split_x(
            side="plus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
            z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE,
        )
        plus = difference(plus_bare.force_render(), eng).with_bbox_from(plus_bare)

        # Lens-side-down: rotate 180° about X (flips Y and Z, keeps X
        # so minus stays at world X<=0 and plus at world X>=0). The
        # lens-side face ends up below z=0; pack_on_bed below uses
        # tight_bbox to lift it back to the bed (LensHousing's
        # tight_bbox override gives the truncated fillet rim's true
        # z-extent, so the rim lands flush with z=0).
        minus_v = minus.rotate([180, 0, 0])
        plus_v = plus.rotate([180, 0, 0])

        gap = 12   # ~1.2cm clearance between objects

        # Place each half so its cut face sits at world X = ±gap/2. Lap
        # tongues extend at most LAP_OVERLAP - LAP_CLEARANCE past the cut
        # face, so the actual material gap between the two halves is
        # gap - 2*(LAP_OVERLAP - LAP_CLEARANCE) — comfortably non-zero
        # for any reasonable gap. pack_on_bed can't preserve this overlap
        # if the halves are passed in individually (it would space them
        # apart by `gap`), so the pair is bonded into one unit first and
        # then laid out alongside the stop disc.
        pair = union(minus_v.left(gap / 2), plus_v.right(gap / 2))

        # flat_stop = self.stop_discs[0].down(STOP_DEPTH - STOP_THK / 2)
        # return pack_on_bed(pair, flat_stop, gap=gap, plate=BAMBU_X2D_PLATE)
        return pack_on_bed(pair, gap=gap, plate=BAMBU_X2D_PLATE)

    @variant(fn=48)
    def print_hood(self):
        # Hood by itself, flare-down on the bed (the wide flare gives
        # the largest bed-contact footprint and the coupler / fillet
        # detail prints upward without overhangs). The coupler's label
        # is baked into `LensHood.build()` (via `add_text` on the inner
        # Tube before assembly), so it travels with the hood through
        # the flip and lands oriented correctly on the print surface.
        return pack_on_bed(self.hood.rotate([180, 0, 0]), plate=BAMBU_X2D_PLATE)

    @variant(fn=48)
    def print_stops(self):
        # Two waterhouse stop discs, laid flat on the bed. Picks the
        # f/5.6 and f/11 hole sizes from the JSON's `hole_diameters`
        # list (indices 1 and 3 by construction — index 0 is widest).
        # Adjust the slice if the JSON list ordering changes.
        flat_stops = [
            self.stop_discs[i].down(STOP_DEPTH - STOP_THK / 2)
            for i in (0,2,3)  # f4, f8, f11
            #for i in (1, 3)
        ]
        return pack_on_bed(*flat_stops, gap=10, plate=BAMBU_X2D_PLATE)

    @variant(fn=48)
    def design_spread_out(self):
        # Inspection layout: hood + the two distinct splayed halves
        # (showing the lap joint) + one stop disc per entry in
        # `STOP_HOLE_D`, all in a single +X row. Too large for the print
        # bed; use the `print` variant for actual printing — `assert_fit`
        # is disabled so this layout is allowed to overflow.
        minus, plus = self._splayed_halves()
        flipped_hood = self.hood.flip("z")   # wide flare on the print bed
        flat_stops = [
            disc.down(STOP_DEPTH - STOP_THK / 2) for disc in self.stop_discs
        ]
        gap = self.housing.upper_housing_od   # ~one barrel-diameter of breathing room

        return pack_on_bed(
            flipped_hood, minus, plus, *flat_stops,
            gap=gap, assert_fit=False,
        )

    @variant(fn=48)
    def display(self):
        # Lift the hood one coupler_overlap above the true housing top (which
        # sits above upper_housing_len because of the front fillet ring) so
        # the housing's upper rim is visible between the two parts. The
        # widest-aperture stop disc shows fully inserted at its real depth.
        housing_top_z = self.housing.bbox.max[2]
        gap = self.hood.coupler_overlap
        return union(
            difference(self.housing, self.housing.engravings()),
            self.hood.up(housing_top_z + gap),
            self.stop_discs[0],
        )

    @variant(fn=48)
    def element_grippers(self):
        # Per-element diagnostic half-grippers for test-fitting individual
        # elements without printing a full housing. Each gripper is the
        # same three-tube stack as ElementHolder (rim / middle / rim) with
        # rim and middle inner diameters and axial extents matched to the
        # housing exactly — a successful fit here predicts a fit in the
        # real part. Outer wall is a uniform 2 mm-walled cylinder per
        # gripper (sized off the middle tube; rim tubes come out thicker).
        # Halved at X=0 keeping +X so each gripper prints as a half-shell
        # with the element code engraved on its outer apex (the anchor
        # sits at +X, so engravings stay on the kept half). Standing up
        # along Z; pack_on_bed lays them along +X in elements-tuple order.
        halves = []
        for e in self.housing.elements:
            g = ElementTestGripper(
                element=e,
                grip_depth=GRIP_DEPTH,
                grip_width=GRIP_WIDTH,
                wall_thk=2.0,
                radial_clr=e.clearances.radial,
            )
            cutter = g.text_geometry(
                label=e.code, on="outer_wall", angle=0,
                font_size=2.5, relief=-0.4,
            )
            # with_bbox_from(g): difference()'s bbox can't be tightened
            # without CSG evaluation, but the engraving only removes
            # material from the gripper's outer face, so the true bbox
            # is the gripper's. Without this, halve()'s Intersection
            # bbox can't be clipped and pack_on_bed below errors out.
            engraved = difference(g, cutter).with_bbox_from(g)
            halves.append(engraved.halve([1, 0, 0]))
        return pack_on_bed(*halves, gap=10, plate=BAMBU_X2D_PLATE)

    @variant(fn=48)
    def testing(self):
        # One splayed half (the -X half, with lap-joint features visible)
        # for inspecting a single shell in isolation.
        minus, _ = self._splayed_halves()
        minus_bb = minus.bbox
        gap = self.housing.upper_housing_od
        return minus.left(minus_bb.max[0] + gap / 2)


# Output basename follows the JSON-supplied design name (or
# DEFAULT_DESIGN_NAME). The framework derives the output filename as
# `f"{design_cls.__name__}-{variant}.scad"`, so mutating `__name__`
# after class definition is enough.
LensHousingDesign.__name__ = design_name


if __name__ == "__main__":
    run()
