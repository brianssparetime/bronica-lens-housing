"""Bronica S2 bayonet contract.

Single source of truth for the dimensions shared by `s2_mount.py` (the
camera/lens-mount pair) and `v12c.py` (the lens housing). Splits cleanly
into three groups, all under one `Spec`:

  - Physical measurements of the camera-side bayonet (rear-cap STL +
    direct measurement of the camera lug). True regardless of which
    part reads them.

  - Design choices for the lens-mount ring (clearance to the camera
    barrel, wall thickness, bore-side wall reinforcement). The lens
    mount and lens housing both must agree on these to interface
    correctly.

  - Derived interface dimensions (lens-mount OD, lens-mount bore). Both
    sides read these directly — no risk of one side hand-computing a
    stale value when the underlying design choice shifts.
"""

from scadwright import Spec


class BronicaS2Bayonet(Spec):
    equations = """
        # === Camera-side bayonet (physical, measured) ===
        # From the rear-cap STL.
        cam_barrel_od = 60.5
        cam_barrel_id = 56.5            # also matches the M57 thread behind the bayonet
        cam_wall_thk = 2.0
        cam_length = 20.0

        # Lug axial thickness — measured directly on the camera lug.
        cam_lug_axial = 1.1
        cam_lug_axial += 0.05           # +0.05 after a test print showed the rotation channel too tight

        # Lug pattern: (center_deg, width_deg, radial_proj_mm) per lug.
        # Centers in camera coords (0° = +X, 90° = +Y = up toward BRONICA logo).
        # Widths shrunk 1° from measured (undersized lugs still mate, oversized jam).
        # One large lug + two smaller, centers ~120° apart with slight asymmetry.
        # Per-lug: large (measured 50°, scan 49.5°); small (measured 40°, scan 174.25°);
        # small (measured 41.5°, scan 283.75°).
        lugs = ((90.0, 49.0, 1.8), (214.75, 39.0, 1.2), (324.25, 40.5, 1.2))
        max_lug_proj = max(p for c, w, p in lugs)

        # === Lens-mount ring design choices ===
        # Radial clearance between the camera barrel and the lens-mount bore.
        mount_clearance = 0.20
        # Lens-mount tube wall thickness, measured outside the lugs.
        mount_wall_thk = 2.0
        # `inner_shrink` shrinks the blank's inner diameter (and the bore cut)
        # by this amount diametral, leaving the OD and channel walls untouched.
        # 0 = bore matches `cam_barrel_od + 2*clearance`. Bumping it makes the
        # bore-side wall thicker and the cuts reach that much deeper inward.
        mount_inner_shrink = 1.0
        # Axial extent of the lens-mount tube above the camera flange plane.
        # Was `protrusion_len` on the lens mount, `MOUNT_OFFSET` on the housing.
        mount_protrusion = 5.0

        # === Derived interface (read by both lens housing and lens mount) ===
        # OD of the lens-mount tube outside the lugs (incl. wall thickness).
        lens_mount_od = cam_barrel_od + 2*max_lug_proj + 2*mount_wall_thk
        # Inner bore of the lens-mount ring after the bore-cutter pass.
        # Mating disc on the housing fits inside this; previous bug had this
        # hand-mirrored in v12c.py and drifted when `mount_inner_shrink` changed.
        lens_mount_bore = cam_barrel_od - mount_inner_shrink + 2*mount_clearance

        # === Helicoid focus slot (camera attribute) ===
        # An axial slot in the lower housing wall that clears a focus-helicoid
        # pin protruding from the camera body. Centered at 9 o'clock (-X axis
        # when looking from the camera toward the subject) — the side of the
        # stop slot opposite the housing's text engravings; present on only
        # the -X half of a split housing. Runs from the bottom of the M57
        # insertion depth toward the flange and stops `offset_from_flange`
        # short of the flange plane (z=0 in the housing's world frame).
        # Radial depth equals the lower-housing wall thickness, so the cut
        # opens fully through the wall.
        helicoid_focus_slot_angle = 180              # deg; 180 = -X axis
        helicoid_focus_slot_width = 6                # mm circumferential (arc length at OD)
        helicoid_focus_slot_depth = 1.5              # mm radial (from OD inward)
        helicoid_focus_slot_offset_from_flange = 11  # mm; slot z_top = -this in housing frame
    """
