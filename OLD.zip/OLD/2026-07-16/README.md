# s2-evolving — Bronica S2 3D-printed parts

A working collection of 3D-printed parts for the Bronica S/S2/S2A/EC/EC-TL camera system, all built in SCADwright:

- **Rear lens cap** — closes off the back of a lens off-camera. Two flavours: a one-orientation cap matching the camera's asymmetric three-lug bayonet, and a symmetric three-orientation variant.
- **Body cap** — closes off the camera body when no lens is mounted.
- **Lens housing with locking mount ring** — a full lens housing built from a JSON optical configuration (focal length, FOV, per-element diameters and spacings, iris stop), with a pivot-lever locking bayonet ring as the lens-to-camera interface.

This is by far the most ambitious SCADwright example in the repo: ~ten source files, nearly every framework feature in use: `Spec` with adjustments, `Component` with `equations`, `@variant`, custom transforms, `attach(fuse=True)`, `through()`, `add_text()`, `print_stamp()`, JSON-driven sizing, snap-fit clearances, lap-joint print splits, bed-fit checks.

## Files

Three groups: the shared bayonet contract, the small camera-side artifacts (caps and the bare mount ring), and the lens housing and everything it pulls in.

- **Bayonet contract & printer config** — read by every part downstream.

  - `spec.py` — the bayonet contract. Single source of truth for the camera-side bayonet (measured from a real Bronica) and the lens-mount ring's design choices.
  - `printer.py` — printer-side constants (the Bambu X2D print-bed footprint, used by `pack_on_bed`).
- **Caps & the bare lens-mount ring** — small standalone Designs that mate with a real camera or lens.

  - `rear_lens_cap.py` — `CameraMount` (the lugs-only test-fit stub used to verify the lens-mount ring against printed dimensions), `RearLensCap` (cap with a bayonet stub on the lens side and a closing cup on the camera side), and `BronicaS2RearLensCapSymmetric` (a three-orientation symmetric variant).
  - `body_cap.py` — a `LensMount` plus a solid plug disc filling the bore. Worn on the camera body.
  - `lens_mount_ring.py` — generic `LensMount` Component, the lens-side bayonet ring that mates with `CameraMount`. Standalone as its own Design (`lens`, `lens_print`, `lens_supports` variants) and the base class extended by `body_cap.py` and `lens_mount_locking_ring.py`.
- **Lens housing** — the main artifact and everything it composes from.

  - `lens_housing.py` — CONCRETE lens-housing Design. Reads `v13f.json` (or any other optical config) and resolves every dimension from it. Mounts on the camera through `lens_mount_locking_ring`.
  - `lens_internals.py` — REUSABLE optical Components: `Element`, `ElementHolder`, `ElementClearances`, `ElementTestGripper`, `Stop`, `SweptSlot`, `FilletSection`, `TruncFilletRing`. S2- and Bronica-agnostic.
  - `lens_mount_locking_ring.py` — `LensMount` extended with two integrated pillow-block bosses on its OD wall and a separate pivot lever pinned through them. The lever's chisel tooth drops into the bayonet rotation channel and locks the lens onto the camera. The lens-housing's mating disc snap-fits inside the ring's bore.
  - `mating_disc_lock.py` — shared spec for the lens-housing ↔ locking-ring tab/notch interface. Kept in its own module so a part can import the spec without pulling in either Design class (avoiding `print`-variant collisions).
  - `lap_joint.py` — generic stepped lap-joint transforms (`lap_split_x`, `lap_splay`) used to halve the housing for printing. No project-specific dimensions.
  - `v13f.json` — the optical config currently in print: a 101 mm f/2.9 lens, three elements, six aperture stops.


## Caps

Each cap is a small Design wrapping one or two Components. Run a script and the default variant lands next to the source as `<file>-<variant>.scad`:

```
python s2-evolving/rear_lens_cap.py                                # default: symmetric three-orientation rear cap
python s2-evolving/rear_lens_cap.py --variant rear_cap              # asymmetric rear cap matching the spec lugs
python s2-evolving/rear_lens_cap.py --variant mount_testfit         # lugs-only camera-mount test stub

python s2-evolving/body_cap.py                                     # body cap, print orientation (default)
python s2-evolving/body_cap.py --variant cap                       # body cap, display orientation

python s2-evolving/lens_mount_ring.py                              # default: bare lens-mount ring + modeled PETG supports, print layout
python s2-evolving/lens_mount_ring.py --variant lens               # ring only, no supports
python s2-evolving/lens_mount_ring.py --variant lens_supports      # PETG supports only (pre-aligned to the ring)
```

All three share the bayonet contract in `spec.py` — adjust a measurement there and every mating part follows.

## Lens housing

The heart of the project. `lens_housing.py` builds a full Bronica S2 lens housing from a JSON optical configuration:

```
python s2-evolving/lens_housing.py --from-json v13f.json -o v13f-print.scad
python s2-evolving/lens_housing.py --from-json v13f.json --variant display -o v13f-display.scad
python s2-evolving/lens_housing.py --from-json v13f.json --variant print_hood -o v13f-hood.scad
python s2-evolving/lens_housing.py --from-json v13f.json --variant print_stops -o v13f-stops.scad
python s2-evolving/lens_housing.py --from-json v13f.json --variant print_shape_stops -o v13f-shape-stops.scad
```

Without `--from-json`, the script falls back to placeholder defaults — always pass the optical config you actually want.

The JSON carries focal length, max aperture, FOV, per-element diameters/edge-thicknesses/spacings, and the iris stop (depth + hole diameters). Every dimension below is derived from the config, not hand-entered.

Features:

- **Optical elements precisely positioned** in `ElementHolder`s sized to each element's diameter, edge thickness, and spacing.
- **Stepped recessed housing** that narrows in three steps (outer → mid → inner), with a **bore-side fillet ring** at each step. This matches the geometry inside the S2's mount barrel very closely.
- **Locking bayonet mount** at the bottom through `lens_mount_locking_ring`: integrated pillow blocks carry a sewing-pin-pivoted curved lever whose tooth swings into the rotation channel.  Music wire torsion spring.
- **Waterhouse stops** from f4 to f/22, calculated from the focal length divided by entrance pupil.
- **Per-element test grippers** (`ElementTestGripper`) — a small printable jig per optical element for verifying the holder dimensions before committing to a full housing print.
- **Clip-on hood** (`LensHood`) sized off the housing's hood-base angle and front-element diameter, with an outer profile that rests flush against the front rim. A snug coupler fit plus a continuous snap ring (bead on the hood coupler, groove on the housing rim) hold it on.
- **Clip-on lens cap** (`LensCap`) sharing the hood's snapping coupler — same fit, same snap groove — but with a flat 2 mm lid in place of the funnel, the lid set at the funnel-shoulder plane so cap and hood seat identically. "ZenzaNOT" is inset on the outward face.
- **Clip-on aperture cover** (`ApertureCover`) that snaps over the skyward Waterhouse-stop slot to block stray light. A C-clip wrapping more than 180° for an over-center snap, with a pair of triangular ridges seating into matching axial grooves the housing cuts at the slot, and a pry tab at each end. Reads the barrel diameter, slot position, groove angle, and ridge profile off the housing. A pair of partial 45° fillet rings on the housing flank the cover (flat face to each cover edge, slant away) as light baffles, closing the gap between cover and barrel.
- **Light-tight, snap-fit seams** via a stepped lap joint (`lap_split_x`) that splits the housing along X.
- **Front fillet rim with text** (`TruncFilletRing`) wrapping the aperture, with the focal-length/aperture label inset into its truncated surface as raised text (e.g. `BRIOTAR 101mm f/2.9` for the v13f config).
- **Funnel-widened upper barrel** when the front element is wider than the bayonet bore — the path opens up cleanly above the mount-ring zone.
- **Tab/notch alignment** between the housing's mating disc and the locking ring (once seated, the housing can't rotate relative to the ring) and a **snap-fit bead** around the housing's mating disc to prevent it pulling off.  Shared spec in `mating_disc_lock.py`.
- **GitHub-commit stamp** (`print_stamp()`) inset on the upper barrel — every printed part carries its source identity.
- **Print-bed-aware layouts** — every `print_*` variant runs through `pack_on_bed` against the Bambu X2D's `256x256` plate, so a layout that won't fit fails before rendering.

Variants:


| Variant                      | Purpose                                                      |
| ------------------------------ | -------------------------------------------------------------- |
| `print_vertical` *(default)* | Housing halved, splayed flat, packed onto the print bed.     |
| `print_vertical_preview`     | Same layout, lower`fn` for fast preview.                     |
| `print_hood`                 | The clip-on hood, print orientation.                         |
| `print_lens_cap`             | The clip-on lens cap, flat disc face-down on the bed.        |
| `print_aperture_cover`       | The clip-on aperture-slot cover, axis-vertical on the bed.   |
| `print_stops`                | The iris stop set, packed onto the bed.                      |
| `lower_housing_testfit`      | Just the bayonet-engagement region — quick fit-check print. |
| `design_spread_out`          | Every sub-part laid out flat, spaced for design review.      |
| `display`                    | Assembled housing + hood, presentation orientation.          |
| `element_grippers`           | Per-element printable test grippers.                         |
| `testing`                    | Scratchpad variant for ad-hoc inspection.                    |

