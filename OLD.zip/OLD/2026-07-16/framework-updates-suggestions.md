# Framework updates and suggestions from your s2-evolving code

We reviewed the s2-evolving codebase against the framework and found
several patterns worth addressing. Five are covered below; each
describes the pattern, cites an example from your code, and notes
what changed or what to do differently.

---

## 1. sys.path boilerplate is no longer needed

Every file in the project starts with:

```python
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
```

`scadwright build` now adds the script's parent directory to
`sys.path` before importing, matching what `python script.py` does
natively. The two-line hack is harmless but unnecessary; you can
remove it from all five files.

---

## 2. Chained attribute access works in equations

`ElementTestGripper` takes a separate `radial_clr` parameter
because the equations DSL appeared to support only one level of
attribute access:

```python
# What you wrote (workaround):
equations = "surround_id = element.dia + radial_clr"
# ...and at the call site:
ElementTestGripper(..., radial_clr=e.clearances.radial)
```

The resolver actually handles arbitrary-depth chains already. You
can write:

```python
equations = "surround_id = element.dia + element.clearances.radial"
```

The LSP now supports chained completion, hover, and goto-definition
for this pattern too (same-file resolution). The cheatsheet and
components docs have been updated with examples.

---

## 3. arg(type=bool) registers a flag

`lens_housing.py` defines a manual `_strtobool` converter for the
`--no_locking_mech` CLI flag:

```python
def _strtobool(s):
    v = str(s).strip().lower()
    if v in ("1", "true", "yes", "on"):
        return True
    ...

NO_LOCKING_MECH = arg("no_locking_mech", default=False, type=_strtobool)
```

`arg(type=bool)` now registers a standard presence/absence flag.
The idiomatic form is:

```python
NO_LOCKING_MECH = arg("no_locking_mech", default=False, type=bool)
```

Pass `--no_locking_mech` to set it True; omit it to keep the
default. No `=1` or `=true` needed. The `_strtobool` helper can
be removed.

---

## 4. Design.name controls the output filename

`lens_housing.py` mutates the class's `__name__` to control the
output filename:

```python
LensHousingDesign.__name__ = design_name
```

Design subclasses now accept a `name` attribute for this:

```python
class LensHousingDesign(Design):
    name = design_name    # "v13f" from JSON, or "lens_housing" default
    ...
```

The framework uses `name` as the output stem when present, falling
back to `__name__` if not set. The post-hoc mutation can be
removed.

---

## 5. Factor cutters for subclass extensibility

`LensMountWithPivotPillows.build()` duplicates almost all of
`LensMount.build()` because the notch cutter needs to be in the
same `difference()` call as the bore, channels, and groove. The
comment says: "duplicated; we need the notch in the same Difference
to avoid leaving a thin veil of wall."

The recommended pattern (now in the style guide) is to factor the
cutters into a generator method:

```python
class LensMount(Component):
    def _cutters(self):
        yield self._bore_cutter()
        yield self._groove_cutter()

    def build(self):
        yield difference(self._blank(), *self._cutters())

class LensMountWithPivotPillows(LensMount):
    def _cutters(self):
        yield from super()._cutters()
        yield self._notch_cutter()
```

The subclass extends the cutters; the blank and the difference stay
in the parent's `build()`. This eliminates the duplication without
any framework machinery.

---

## 6. Recent attach/fuse improvements

The framework has gained `node.fuse(host)` (auto-detected
coincident-surface union with radial extend on Tube, Funnel,
Barrel, and Sphere shapes) and several related features. Most of
the manual epsilon in s2-evolving is on polygon extrusions and
arc extrusions that don't carry the anchors `fuse()` needs, so
these are targeted suggestions rather than a blanket rewrite.

### ElementHolder: `inner_wall` anchor would enable auto-fuse

The holder's OD is manually padded by `2 * default_eps()` to avoid
a non-manifold seam where its outer cylinder sits at exactly the
housing wall's inner bore (lens_housing.py, around line 269):

```python
eps = default_eps()
od = self.od + 2 * eps
surround = Tube(h=surround_h, od=od, id=e.dia + clr.radial)
```

If `HousingSection` declared an `inner_wall` anchor (it currently
only declares `outer_wall`), the holder could use
`holder.fuse(section)` and the framework would auto-detect the
matching cylindrical surfaces and radially extend the holder's OD
by eps. The caveat: the holder is yielded alongside a barrel that's
a union of many sections, and `fuse()` works against a single host,
not a union. You'd need to fuse against the specific section, not
the barrel. Whether that's worth the refactoring depends on how
often the holder construction changes.

### ElementHolder gripper-surround join: `attach(fuse=True)` instead of `bond="shift"`

The gripper Tube is attached to the surround Tube with
`bond="shift"` (line 276):

```python
gripper = Tube(
    h=gripper_h, od=od, id=e.dia - self.grip_depth,
).attach(surround, bond="shift")
```

These are two Tubes sharing a planar face. The default
`attach(fuse=True)` with `bond="overlap"` would extend the
gripper's height by eps at the contact face, keeping both IDs and
ODs exact. `bond="shift"` moves the entire gripper by eps, which
drifts the opposite face. If the drift matters (the gripper's
free face contributes to `face_z_top`), switching to
`attach(fuse=True)` would be more precise.

### Mating disc tabs and bead: manual eps is the right call

The tab boxes (line 915) and bead triangle (line 943) use
`fuse_eps` to push their inner edges slightly inside the disc OD.
Both are polygon extrusions, not Tube/Funnel shapes, so `fuse()`
can't auto-detect or radially extend them. The manual eps is the
correct approach here.

### TruncFilletRing chopper: manual eps is the right call

The chopper cylinder (line 470) is padded past the FilletRing's
OD to avoid cylinder-on-cylinder coincidence in the `difference()`.
This is a cutter, not a union, so `fuse()` doesn't apply.
`through()` handles planar coincidence but not cylindrical; the
manual eps is the correct workaround.

### Features already used correctly

The project already uses `attach(fuse=True)` on the front fillet
(line 1062), the hood's funnel and fillet ring (lines 1142, 1146),
and `prefers_shift_at_anchor` on `TruncFilletRing` (line 483).
These are all correct.

### For future parts

When adding new Tube-on-Tube or Funnel-on-Tube joins (e.g. body
caps, rear-lens caps, new housing rings), `node.fuse(host)` is
the right tool. It auto-detects matching cylindrical or conical
surfaces and applies radial eps extension, keeping user-facing
dimensions exact. No manual eps arithmetic needed. See the
attach docs for the full surface.

---

## 7. Response to your fuse() feedback (items 1 and 2)

Your issues 1 and 2 are the same problem. The `inner` flag in
`surface_params` is not just a label -- it controls how the
framework computes the central axis from the anchor's position.
Without `"inner": True` on a bore-side anchor, the computed axis
origin lands at the wrong location (diameter away from center
instead of on center), so `axis_lines_coincide` fails before
the matcher even reaches the inner-flag compatibility check. The
auto-match correctly rejected the pair; the bridge hint appeared
because bbox-derived planar faces happened to sit near the curved
wall.

The fix on your side: set `surface_params={"inner": True}` on
any bore-side cylindrical, conical, or spherical anchor. Match
the pattern from Tube's built-in `inner_wall` declaration.

The fix on our side (done): `"inner"` is now documented in the
required-surface-parameters table in `docs/anchors.md`, with a
bore-anchor example alongside the existing outer-wall example.
The zero-match error also now reports curved near-misses (the
specific rule that failed) alongside the bridge hint, so you'd
see "both anchors have inner=False" instead of just "bridge
case."

With the correct `inner_wall` declaration, `holder.fuse(section)`
auto-matches without needing `on=`/`from_anchor=`.

---

## 8. Response to your fuse() feedback (item 3)

`fuse()` returns `union(extended_self, host)` because its
contract is "produce a manifold-clean merged shape from two
parts." Inside a generator `build()` where the host is already
yielded separately, that union duplicates the host.

We looked at adding a `fuse_against` variant that returns just
the extended self. The problem: `fuse()` sometimes extends the
host side (when the host carries the extension lever), not self.
A return-self-only mode would silently discard the extended host
and hand back an unextended self. The API would be fragile.

Your original pattern -- `od = self.od + 2 * default_eps()` --
is the right tool for this case. It's direct, explicit about
what's being padded, and avoids the duplication entirely.
`fuse()` is for combining two free-standing shapes into one
result; inside a `build()` generator where parts share a host,
manual eps on the interfacing dimension is cleaner.

---

## 9. Response to your fuse() feedback (items 4 and 5)

**Chained access in surface_params (your item 4):** documented.
`docs/anchors.md` now mentions that chained attribute access
works in `surface_params` strings, with an example.

**`difference(solid, *cutters)` vs `difference(solid, union(*cutters))`
(your item 5):** noted in the style guide. Prefer the splat form;
OpenSCAD's `difference()` already unions children 2..N internally,
so the explicit `union()` just adds a redundant nesting level in
the emitted SCAD.

---

## 10. Response to your from_json() defaults request

Done. `from_json()` now accepts `default=`:

```python
_cfg = from_json(default={
    "elements": DEFAULT_ELEMENTS_DATA,
    "stop": {"depth": DEFAULT_STOP_DEPTH, "hole_diameters": DEFAULT_STOP_HOLE_D},
    "fov": DEFAULT_FOV_ANGLE,
    "name": DEFAULT_DESIGN_NAME,
    "focal_length": DEFAULT_FOCAL_LENGTH,
    "max_aperture": DEFAULT_MAX_APERTURE,
})
# _cfg is always a dict. No --from-json → returns defaults.
# With --from-json → JSON deep-merged over defaults.
```

The merge is recursive: dict values recurse, everything else
(lists, scalars, None) in the JSON replaces the default. So
`{"stop": {"depth": 5}}` in JSON overrides depth but preserves
`hole_diameters` from the default.

Type coercion is still yours (`float()`, `tuple()`) -- the
framework doesn't know your data contract. But each coercion
now appears once instead of in two branches.

---

## 11. Response to your fuse() host-duplication pushback

You were right. `fuse()` now accepts `self_only=True`:

```python
yield barrel
yield holder.fuse(barrel, self_only=True)
```

Returns just the extended self, no union with host. Raises if
the extension lever lives on host rather than self (the error
points at `fuse()` without `self_only` as the fallback).

Under `disable_eps_fuse()`, `self_only=True` returns the aligned
self with no extension and no host union.

---

## 12. `attach` to an asymmetric CSG union silently goes off-axis

Attaching a coaxial part to a `union(...)` places it at the union's
bounding-box center, not on its axis — and the two only coincide while
the union stays symmetric. A part added later that sticks out on one
side moves the bbox center, and every prior `attach` to that union
silently drifts with it. There is no warning.

This bit us on the lens housing. The front bezel is fused to the barrel:

```python
barrel = union(*sections)          # + tabs, bead, baffle rings unioned in
...
fillet = self._front_fillet().attach(barrel, fuse=True)
```

`barrel` is a generic union, so its `"top"` anchor comes from
`anchors_from_bbox` — the center of the bbox top face. The bezel sat
concentric for months because the widest feature was the concentric
upper OD. Then a pair of light-baffle rings that protrude only on the
+Y arc pushed the bbox's +Y edge out with no −Y counterpart; the
`"top"` anchor moved ~+1.25 mm in Y, and the bezel rendered visibly
shifted off the barrel. Nothing about the bezel code changed.

Two things made this hard to diagnose:

- A `tight_bbox` override on the component doesn't help — `attach`
  reads the host's *loose* `bbox()` for its anchors, and the union is
  a local variable inside `build()`, not the component.
- The fuse bond was already correct (`bond='shift'`, via
  `prefers_shift_at_anchor`); only the anchor *position* was wrong, so
  the weld stayed manifold and the error read as pure misplacement.

Our fix was to declare the barrel's true coaxial top and attach to it:

```python
barrel = barrel.with_anchor("top", at=(0, 0, self.upper_housing_len), normal=(0, 0, 1))
fillet = self._front_fillet().attach(barrel, fuse=True)
```

That works and is what we'd recommend today. But the trap is sharp:
`attach(union, ...)` reads as "put it on top," and for a roughly
cylindrical body the user expects coaxial, not bbox-centered. Two
framework-side ideas:

- A warning (or opt-in strict mode) when `attach`'s resolved anchor on
  a boolean node sits far from the host's centroid/axis — the case
  where bbox-center and axis diverge is exactly the surprising one.
- A coaxial-attach helper or convention for stacking parts on a body's
  axis without going through bbox anchors, so the common
  "ring/cap/bezel on top of a tube-like union" case has an obvious
  right tool.
