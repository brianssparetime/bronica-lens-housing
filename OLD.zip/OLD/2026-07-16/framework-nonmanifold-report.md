# Non-manifold STL export from `print_vertical` — suspected framework regression

## Problem

`lens_housing.py --from-json v13f.json --variant print_vertical` produces an STL
that Bambu Studio rejects with **60 non-manifold edges**; it will not slice. The
same project sliced cleanly at our last print, and we have not edited the model
since.

## Why we believe this is framework-side, not model-side

- **The model didn't meaningfully change.** Triangle count is ~57,600 now vs
  ~56,100 at the last good print — same geometry, no source edits on our end.
- **The solid is valid; only the export is broken.** OpenSCAD reports the Nef
  polyhedron as `Simple: yes`, yet the tessellated STL is non-manifold. That is
  the signature of coincident coplanar faces a union failed to dissolve.
- **The defect is one localized interface, not scattered noise.** 123 of the
  ~145 bad edges lie on a *single* flat plane (housing-frame z ≈ 12.3, mirrored
  onto both lap halves). On that plane there are opposing coincident sheets —
  ~290 up-facing and ~520 down-facing triangles over ~590 mm² occupying the same
  z. Two solids are butting at an exactly-coplanar face; the export leaves both
  sheets and the boundary between them becomes T-junction non-manifold edges.
- **The timing matches recent fillet/`through()` work.** This regressed after
  commits that deliberately move fillet/step faces to exact tangency:
  `a4dfa51` (nudge FilletMask cutter past tangency), `2f286a1` (pin
  FilletMask/ChamferMask `through()` axis), `4294e44` / `4a889ff` (`through()`
  cut-axis selection). We believe one of these nudged a bore-side fillet or step
  face into exact coplanar coincidence with its neighbor, which our OpenSCAD
  (2021.01, CGAL backend) then exports as non-manifold.

## What we need

A framework-side fix that prevents fillet/step faces from being emitted exactly
coplanar with the surface they join — i.e. restore a sub-visible overshoot so the
union fully fuses — **without requiring us to edit the model**. The fix must keep
the existing visual result and survive STL export on the CGAL backend (we cannot
rely on the newer Manifold backend; only 2021.01 is available here).

## How to verify a fix from the command line (no Bambu needed)

Run from the repo with a **clean working tree** (the `print_stamp()` call in this
example refuses a dirty tree — commit or stash WIP first). Use the
`print_vertical_preview` variant for fast iteration (same geometry, lower `fn`,
~10x faster render); confirm the final fix on `print_vertical`.

```
cd s2-evolving
../.venv/bin/python3 lens_housing.py --from-json v13f.json \
    --variant print_vertical_preview -o /tmp/pv.scad
/Applications/OpenSCAD.app/Contents/MacOS/OpenSCAD -o /tmp/pv.stl /tmp/pv.scad

../.venv/bin/python3 - <<'PY'
import trimesh, collections
m = trimesh.load('/tmp/pv.stl', process=False)
m.merge_vertices()
counts = collections.Counter(map(tuple, m.edges_sorted))
bad = [e for e, n in counts.items() if n != 2]
print("watertight:", m.is_watertight, "| non-manifold/boundary edges:", len(bad))
assert m.is_watertight and not bad, "FAIL: mesh still non-manifold"
print("PASS: manifold")
PY
```

- **Today (broken):** `watertight: False | non-manifold/boundary edges: ~145` → FAIL.
- **Fixed:** `watertight: True | non-manifold/boundary edges: 0` → PASS.

---

# Response: the framework is not the cause

Bottom line first. The four commits you name do not touch the geometry in
this model, and the non-manifold edges are coincident coplanar faces created
by the model's own boolean construction. The export is honest; the solid you
are handing OpenSCAD has internal coplanar sheets that the 2021.01 CGAL
backend cannot dissolve. You can fix this today without any framework change.

## The commits are exonerated

I reverted the framework to before all four (`2f286a1~1`), regenerated
`print_vertical_preview` from `v13f.json`, and re-rendered. The mesh is
byte-for-byte identical to current: same triangle count, same 78 non-manifold
edges (at preview `fn`), same planes. The commits do not move this geometry
by a single vertex.

The code paths say the same thing. This model uses neither `FilletMask` nor
`ChamferMask`, which is the entirety of what `a4dfa51` and `2f286a1` change.
Your front and bore fillets are custom Components. And your one `.through()`
call in `lens_internals.py:477` passes `axis="z"` explicitly, so it never
reaches the auto-axis detection that `4294e44` and `4a889ff` rewrote. The
timing lined up; the cause did not.

## Where the bad edges actually come from

Render the `display` variant, which has no lap joint and no splay. It is
already non-manifold: 49 bad edges, almost all of them on one plane at
housing-frame z = 5.0. That is your `MOUNT_OFFSET`, where two barrel sections
meet under a plain `union(*sections)` and share an exactly coincident face.
The lap joint then adds more seams of the same kind, which is why
`print_vertical` looks worse than `display`. Your z ≈ 12.3 observation is the
same plane seen after the print rotation and bed lift.

This is a well-known CGAL-2021.01 behavior, not an emit defect. Two coincident
coplanar sheets tessellate into the opposing up-facing and down-facing
triangles you measured. Your own note that the Nef reports `Simple: yes` while
the STL is non-manifold is the textbook signature. The Manifold backend would
dissolve these; 2021.01 will not.

On "it sliced cleanly before": the triangle count moved from about 56,100 to
57,600, and the cited commits produce identical output, so whatever changed
the geometry was a model, parameter, or `fn` change on your side, or an
earlier print that sat just under the threshold where these sheets surface.
It was not the framework.

## What we will not do, and why

You asked for a framework fix that detects fillet and step faces sitting
coplanar with their neighbor and silently restores a sub-visible overshoot,
without you editing the model. That is auto-detecting coincident faces and
injecting geometry behind your back, and we rejected it deliberately. "Almost
coincident but not quite" cannot be told apart reliably, so such a feature
fires unpredictably and silently changes dimensions you did not ask to change.
A silent wrong answer is worse than an honest non-manifold export.

## What to use instead

The framework already gives you the declared tools for exactly this, and you
already use them in places. For unions that share a contact face,
`attach(..., fuse=True)` or `bond='overlap'` extends one side by eps so the
seam is not coplanar. For cuts, `through()` carries the eps overshoot. The two
spots that are biting you do not use them: the section stack
(`union(*sections)`) and the lap rejoin in your `lap_joint.py` both abut
solids on a shared plane with zero overlap. Overlap those boundaries by a
small eps along the stack and cut axes and the coincident sheets disappear.
That is standard CSG hygiene, and it is where the defect lives.

Separately, the recurring need underneath this, stacking sections and
splitting-then-rejoining for print, deserves a first-class declared helper so
you are not hand-rolling the overlap each time. That is on our side to design.
It will be an overlap you ask for, not one we guess at.

------

# Bug: `flip` + `mirror_copy` of `attach(fuse=True)` sub-parts exports non-manifold once a later boolean cuts through it

**Summary.** A symmetric Component built by reflecting abutting, fuse-attached
sub-parts is a valid Nef (`Simple: yes`) but exports a non-manifold STL after a
subsequent boolean cuts across it. Building the identical shape as a single
overlapping `union` exports cleanly. Observed on OpenSCAD 2021.01 (CGAL).

**Why this is a trap.** The failure surfaces far from its cause: the offending
part renders cleanly on its own and nothing in its output flags it — the defect
only materializes when an unrelated later operation cuts across it. So every
direct lead points at the cut or its neighbours, not at the construction that's
actually wrong, and it only yields to a full bisect of the build. It caught a
fairly experienced user and took hours to localize, which is why it warrants a
framework-side guardrail instead of leaving each user to rediscover it.

**Symptom.** Where the cut crosses the reflected part, the exported mesh has
zero-area degenerate triangles and pairs of opposing coincident faces along the
cut plane. `Simple: yes` reports the solid as valid, so the fault is in the
tessellated export, not the geometry.

**Construction that triggers it.**

```python
half = union(surround, gripper.attach(surround, fuse=True)).flip("z")
part = mirror_copy(half, normal=[0, 0, 1])
```

Sub-parts joined by an `attach(fuse=True)` abutting seam, then `flip("z")` +
`mirror_copy`. The part renders fine standalone; the non-manifold geometry
appears only where a later boolean (here `halve`, via a lap-split transform)
cuts through it.

**Scoping observations.**

- The cut alone — on plain tubes, stepped tubes, funnels, and a fully-featured
  cylindrical barrel — is clean.
- The same cut through the reflection-built part is non-manifold.
- The same cut through the identical shape built as one overlapping `union`
  (full-height surround + a tighter-bore ring embedded at each end, no
  reflection, no abutting seam) is clean.
- Plain-stacking the sub-part but keeping `flip` + `mirror_copy` is worse.
- A reduced standalone (a reflected ring fused into a plain wall, then cut) is
  clean — so the trigger needs the part's specific dimensions together with the
  fuse-to-host and the cut. It reads as a marginal-geometry tessellation case,
  not a blanket reflection failure.

**Suggested direction.** `flip`, `mirror_copy`, and `attach(fuse=True)` should
yield geometry robust to a downstream boolean — no coincident mirror-plane
faces, consistent winding, overlapping rather than abutting seams. If that can't
be guaranteed, document the limitation and point users at a direct overlapping
`union` for parts that get cut or split later. (The overlapping-union build is
also strictly better here: the reflected build's reported volume was slightly
off, its mirror seam leaving the mesh marginally non-watertight.)

**Reproduce** (CLI, no slicer). Lap one housing half and count non-manifold
edges; the only variable is `ElementHolder.build` (reflection form vs. direct
`union`):

```python
import sys, subprocess, collections, trimesh
HERE = "s2-evolving"
sys.path.insert(0, HERE)
sys.argv = ["x", "--from-json", f"{HERE}/v13f.json"]
from scadwright import resolution
from scadwright.render import render
import lens_housing as L
from lens_housing import LAP_OVERLAP, LAP_MID_RADIUS, MOUNT_OFFSET, LAP_CLEARANCE

h = L.S2LensHousing()
with resolution(fn=60):
    node = h.lap_split_x(side="minus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
                         z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE)
    render(node, "/tmp/half.scad", banner=False, glossary=False)
subprocess.run(["openscad", "-o", "/tmp/half.stl", "/tmp/half.scad"])

m = trimesh.load("/tmp/half.stl", process=False)
m.merge_vertices()
counts = collections.Counter(map(tuple, m.edges_sorted))
print("non-manifold/boundary edges:", len([e for e, n in counts.items() if n != 2]))
```

- reflection-built sub-component → `6` per cut half
- direct overlapping `union` → `0`
