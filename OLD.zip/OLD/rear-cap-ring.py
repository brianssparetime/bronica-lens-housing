"""Bronica S2 lens-mount barrel.

A short open-ended tube with three outward-projecting bayonet lugs at
the top rim, sized to match the cylindrical portion of the Bronica
S/S2/S2A/EC/EC-TL Rear Lens Cap (Thingiverse 4616679). The body matches
the cap's barrel; the three lugs reproduce the small tabs at the cap's
top rim.

Run:
    python s2-evolving/s2-mount.py
"""

from scadwright import Component, bbox
from scadwright.composition_helpers import rotate_copy
from scadwright.design import Design, run, variant
from scadwright.shapes import Arc, Tube


# Bambu X2D buildable area (mm). Layouts must fit within these.
BAMBU_X2D_PLATE_X = 256
BAMBU_X2D_PLATE_Y = 256


class MountBarrel(Component):
    """Open tube with three outward-projecting lugs at the top rim.

    `barrel_id` / `wall_thk` / `length` define the open cylindrical body
    (`barrel_od = barrel_id + 2 * wall_thk` is computed). Three lugs are
    placed 120 degrees apart, each `lug_angular_deg` wide, projecting
    `lug_radial` mm beyond `barrel_od` and `lug_axial` mm tall, capping
    the top of the barrel.
    """

    equations = [
        "barrel_id, length, wall_thk, lug_axial, lug_radial > 0",
        "barrel_od = barrel_id + 2 * wall_thk",
        "0 < lug_angular_deg < 120",
        "lug_axial <= length",
    ]

    def build(self):
        # Body: open-ended cylindrical tube
        yield Tube(h=self.length, od=self.barrel_od, id=self.barrel_id)

        # One lug at theta=0: an annular sector (Arc) extruded vertically
        # and lifted to the top of the barrel.
        half = self.lug_angular_deg / 2
        single_lug = Arc(
            r=self.barrel_od / 2 + self.lug_radial / 2,
            width=self.lug_radial,
            angles=(-half, half),
        ).linear_extrude(height=self.lug_axial).up(self.length - self.lug_axial)

        # Three-fold symmetric: one lug every 120 degrees about Z.
        yield rotate_copy(120, single_lug, n=3)


class BronicaS2MountBarrel(MountBarrel):
    """Concrete mount sized to the Bronica S/S2/EC rear cap (Thingiverse
    4616679). Body wall and lug dimensions from STL analysis; the barrel
    ID matches the M57 throat behind the camera-side bayonet (56.5 mm).
    """
    barrel_id = 56.5
    wall_thk = 2.0
    length = 20.0
    lug_axial = 1.5
    lug_radial = 1.5
    lug_angular_deg = 36.0


class s2_mount(Design):
    barrel = BronicaS2MountBarrel()

    @variant(fn=96, default=True)
    def print(self):
        node = self.barrel
        bb = bbox(node)
        if bb.size[0] > BAMBU_X2D_PLATE_X or bb.size[1] > BAMBU_X2D_PLATE_Y:
            raise ValueError(
                f"print layout {bb.size[0]:.1f} x {bb.size[1]:.1f} mm "
                f"exceeds Bambu X2D build plate "
                f"{BAMBU_X2D_PLATE_X} x {BAMBU_X2D_PLATE_Y} mm"
            )
        return node


if __name__ == "__main__":
    run()
