"""Lens housing with stacked optical elements and a matching clip-on hood.

Shows the recommended multi-part layout (see
docs/organizing_a_project.md). Generic Components live in the REUSABLE
zone with no project-specific defaults; the specific design for an
M57-throat camera lives in the CONCRETE zone as thin subclasses that
fill in measurements as class attributes.

Run:
    python examples/lens-housing.py                                  # print variant (default)
    scadwright build examples/lens-housing.py --variant=display        # assembled view
    scadwright build examples/lens-housing.py --variant=print          # split + spread for inspection
"""

from collections import namedtuple
from math import radians, tan

from scadwright import Component, Param, bbox, from_json
from scadwright.boolops import difference, intersection, union
from scadwright.composition_helpers import mirror_copy
from scadwright.design import Design, run, variant
from scadwright.primitives import circle, cylinder, square
from scadwright.shapes import FilletRing, Funnel, Tube


# =============================================================================
# REUSABLE: generic Components, helpers, value types
# =============================================================================


# spacing is from flange (z=0) to element center; +z = toward object.
# `face_z_top`, `face_z_bot`, `constricted`, `throat_dia_required` are
# precomputed by `element(...)` so the housing's `equations` list can
# reference them as attributes directly. `code` (catalog code, e.g.
# "L7325") and `type` (e.g. "NMN", "ACH", "BCX") identify the lens.
Element = namedtuple(
    "Element",
    "code type dia edge_thk spacing face_z_top face_z_bot constricted throat_dia_required",
)


class ElementHolder(Component):
    """Two-sided clamp around one Element, symmetric about the element center."""

    AXIAL_CLR = 0.2
    RADIAL_CLR = 0.2

    element = Param(Element)
    equations = """
        od, grip_depth, grip_width > 0
    """

    def build(self):                                       # framework hook: required; returns the shape
        e = self.element
        surround_h = 0.5 * e.edge_thk + self.AXIAL_CLR
        surround = Tube(h=surround_h, od=self.od, id=e.dia + self.RADIAL_CLR)
        gripper = Tube(
            h=0.5 * self.grip_width,
            od=self.od,
            id=e.dia - self.grip_depth,
        ).attach(surround, fuse=True)
        half = union(surround, gripper).flip("z")
        return mirror_copy(half, normal=[0, 0, 1]).up(e.spacing)


def element(*, code, type, dia, edge_thk, spacing, grip_width):
    """Build an `Element` with its computed geometric fields filled in.

    The caller supplies `grip_width` (the holder's per-side gripper
    height) so the housing's equations can reason about each element's
    z-extent through attribute access.
    """
    half = (edge_thk + 2 * grip_width) / 2
    return Element(
        code=code, type=type,
        dia=dia, edge_thk=edge_thk, spacing=spacing,
        face_z_top=spacing + half,
        face_z_bot=spacing - half,
        constricted=(spacing - half) < 0,
        throat_dia_required=dia + ElementHolder.RADIAL_CLR,
    )


# A waterhouse stop is a thin disc slid laterally into the lens barrel
# through a side slot to set the aperture. `spacing` is the stop center's
# z-position, `thk` the disc thickness, `clr` the slot's z-clearance.
Stop = namedtuple("Stop", "spacing thk clr")


def stop(*, spacing, thk, clr):
    """Build a `Stop` value for a waterhouse stop."""
    return Stop(spacing=spacing, thk=thk, clr=clr)


class WaterhouseStop(Component):
    """A waterhouse stop disc.

    Viewed face-on, it's a 2D paddle: a smaller semicircle of radius
    `barrel_id`/2 in -Y joined to a larger semicircle of radius
    `barrel_od`/2 in +Y along their flat edges, with a central aperture
    hole of diameter `hole_d`. Extruded by `thk` along the lens axis
    and centered on `spacing`. When inserted, the lower (ID) semicircle
    sits in the bore as the aperture plate; the upper (OD) semicircle
    fills the wall slot, leaving a flush exterior. The hole sits on the
    barrel's axis."""

    equations = """
        barrel_id, barrel_od, thk, hole_d > 0
        barrel_id < barrel_od
        hole_d < barrel_id
        # `spacing` is the disc's z-center; `slot_bottom` is the
        # extruder's lower edge. The derivation establishes `spacing` as
        # a Param(float) without an artificial inequality (it can be
        # negative — the stop sits below the flange in the default).
        slot_bottom = spacing - thk / 2
    """

    def build(self):                                       # framework hook: required; returns the shape
        big = self.barrel_od + 2
        upper_mask = square([big, big], center="x")              # Y in [0, big]
        lower_mask = square([big, big], center="x").back(big)    # Y in [-big, 0]
        upper_od = intersection(circle(d=self.barrel_od), upper_mask)
        lower_id = intersection(circle(d=self.barrel_id), lower_mask)
        paddle_2d = difference(union(upper_od, lower_id), circle(d=self.hole_d))
        paddle = paddle_2d.linear_extrude(height=self.thk)
        return paddle.up(self.slot_bottom).red()


class StopHolder(Component):
    """Two-sided clamp around a waterhouse stop, symmetric about the
    stop's z-position. Intruding grippers above and below pinch the
    stop's lower-ID semicircle from outside the slot. The slot in the
    barrel is the disc's pocket — no surround needed here."""

    stop = Param(Stop)
    equations = """
        od, grip_depth, grip_width, barrel_id > 0
        barrel_id > grip_depth
    """

    def build(self):                                       # framework hook: required; returns the shape
        s = self.stop
        slot_h = s.thk + s.clr
        gripper = Tube(
            h=0.5 * self.grip_width,
            od=self.od,
            id=self.barrel_id - self.grip_depth,
        ).up(slot_h / 2)
        return mirror_copy(gripper.flip("z"), normal=[0, 0, 1]).up(s.spacing).green()


def trunc_fillet_ring(*, id, od, base_angle, slant="outwards", rim_width):
    """A `FilletRing` with its sharp apex chopped to a flat rim of
    `rim_width` radial width."""
    if rim_width <= 0:
        raise ValueError("rim_width must be > 0")
    if rim_width >= (od - id) / 2:
        raise ValueError("rim_width must be less than the ring's radial extent")
    # Radial eps: the chopper's outer cylindrical surface sits at d=od, same
    # as the FilletRing's outer wall. through() handles planar-bbox coplanar
    # faces but not cylinder-on-cylinder coincidence, so nudge the chopper
    # outward by a hair.
    eps = 0.01
    base = FilletRing(id=id, od=od, base_angle=base_angle, slant=slant)
    h_full = tan(radians(base_angle)) * (od - id) / 2
    z_t = tan(radians(base_angle)) * ((od - id) / 2 - rim_width)
    chopper = cylinder(h=h_full - z_t, d=od + 2 * eps).up(z_t).through(base, axis="z")
    return difference(base, chopper)


class LensHousing(Component):
    """Generic lens barrel: lower recess + flange + upper housing (narrow
    or funnel-widened) + element holders + front fillet. A matching hood
    Component can read the outer dimensions and hood cone angle off this
    housing to mate without shared scope."""

    FRONT_FILLET_OFFSET = 5.0   # aperture rim inset from the front element's grip ID

    stop = Param(Stop, default=None)
    equations = """
        lower_housing_od = lower_housing_id + barrel_thk
        hood_base_angle = 90 - fov_angle / 2
        lower_housing_od, lower_housing_id, lower_housing_len, barrel_thk > 0
        flange_flange_od, flange_flange_len, fov_angle, hood_base_angle > 0
        grip_depth, grip_width > 0
        unconstricted = tuple(e for e in elements:tuple if not e.constricted)
        max_upper_ele_dia = max((e.dia for e in unconstricted), default=0.0)
        is_wide = max_upper_ele_dia > lower_housing_id
        expansion_funnel_len = min((e.face_z_bot for e in unconstricted), default=inf)
        upper_housing_len = max(e.face_z_top for e in elements)
        upper_housing_od = (max_upper_ele_dia + barrel_thk) if is_wide else flange_flange_od
        all(not e.constricted or e.throat_dia_required <= lower_housing_id for e in elements)
        # Stop must lie entirely in a uniform-OD section: either below the flange
        # (z<=0) or above the flange/funnel transition. The `?stop` sigil makes
        # this line auto-skip when no stop is supplied.
        ?stop.spacing + (stop.thk + stop.clr) / 2 <= 0 or stop.spacing - (stop.thk + stop.clr) / 2 >= (expansion_funnel_len if is_wide else flange_flange_len)
    """

    def build(self):
        lower_id = self.lower_housing_id
        upper_id = self.max_upper_ele_dia if self.is_wide else lower_id

        lower = Tube(
            h=self.lower_housing_len, od=self.lower_housing_od, id=lower_id,
        ).down(self.lower_housing_len)

        flange = Tube(
            h=self.flange_flange_len, od=self.flange_flange_od, id=lower_id,
        )

        if self.is_wide:
            funnel_len = self.expansion_funnel_len
            funnel = Funnel(
                h=funnel_len, thk=self.barrel_thk / 2,
                bot_id=lower_id, top_id=self.max_upper_ele_dia,
            )
            upper = Tube(
                h=self.upper_housing_len - funnel_len,
                od=self.max_upper_ele_dia + self.barrel_thk,
                id=self.max_upper_ele_dia,
            ).up(funnel_len)
            barrel = union(lower, flange, funnel, upper)
        else:
            upper = Tube(
                h=self.upper_housing_len, od=self.upper_housing_od, id=lower_id,
            )
            barrel = union(lower, flange, upper)

        # Local barrel OD at the stop's z (shared by slot cut and gripper).
        stop_od = (
            self.lower_housing_od if self.stop is not None and self.stop.spacing < 0
            else self.upper_housing_od
        )

        if self.stop is not None:
            s = self.stop
            slot_h = s.thk + s.clr
            # Slight radial overshoot avoids cylinder-on-cylinder coplanar
            # faces in the difference (through() can't detect those).
            slot = Tube(
                h=slot_h, od=stop_od + 1, id=lower_id - 0.1,
            ).halve([0, 1, 0]).up(s.spacing - slot_h / 2)
            barrel = difference(barrel, slot)

        yield barrel

        for e in self.elements:
            holder_od = lower_id if e.constricted else upper_id
            yield ElementHolder(
                element=e, od=holder_od,
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        if self.stop is not None:
            yield StopHolder(
                stop=self.stop, od=stop_od, barrel_id=lower_id,
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        front_ele_dia = max(self.elements, key=lambda e: e.spacing).dia
        yield trunc_fillet_ring(
            id=front_ele_dia - self.grip_depth + self.FRONT_FILLET_OFFSET,
            od=self.upper_housing_od,
            base_angle=self.hood_base_angle,
            slant="inwards",
            rim_width=2,
        ).attach(upper, fuse=True)


class LensHood(Component):
    """Generic clip-on hood sized by a paired housing. `housing_upper_od`
    and `hood_base_angle` come from the housing; the rest are hood-specific.
    Built in its mounted orientation: coupler at z=0, funnel flaring upward.
    The print variant flips it."""

    equations = """
        housing_upper_od, hood_base_angle, wall_thk, hood_length, coupler_overlap > 0
        hood_clr >= 0
        id_coupler = housing_upper_od + hood_clr
        od_coupler = id_coupler + 2 * wall_thk
        flare_od = housing_upper_od + 2 * hood_length * tan(90 - hood_base_angle)
    """

    def build(self):                                       # framework hook: required; returns the shape
        coupler = Tube(
            h=self.coupler_overlap, id=self.id_coupler, thk=self.wall_thk,
        )
        yield coupler
        yield Funnel(
            h=self.hood_length, thk=self.wall_thk,
            bot_od=self.housing_upper_od, top_od=self.flare_od,
        ).attach(coupler, fuse=True)
        yield FilletRing(
            id=self.id_coupler, od=self.od_coupler,
            base_angle=63, slant="inwards",
        ).attach(coupler, fuse=True)


def half_housing_splay(housing):
    """Cut along the YZ plane (X=0), keep the -X half, and lay flat
    for the print bed. The print variant calls this for one half and
    `mirror_copy` produces the other; halving along X=0 (rather than
    Y=0) splits the +Y stop slot evenly so each shell carries a
    quarter of the slot.
    """
    return housing.halve([-1, 0, 0]).rotate([0, 90, 0])


# =============================================================================
# CONCRETE: the specific M57 design
# =============================================================================


GRIP_DEPTH = 1.5
GRIP_WIDTH = 1.0

# Waterhouse stop: 1.5mm disc, 0.5mm slot clearance for sliding fit.
# Depth and hole-diameter list come from the design (defaults below or
# loaded from --config).
STOP_THK = 1.5
STOP_CLR = .5

# v12c-bowl-swirl defaults (used unless --config overrides). Front to rear.
# `mounted_od` is optional and only applies to the element that carries it
# (its mount/cell is wider than the bare lens); the housing uses
# max(diameter, mounted_od) for clearance on those elements.
DEFAULT_ELEMENTS_DATA = (
    {"code": "L7325",  "type": "NMN", "diameter": 52.0, "edge_thickness": 6.2, "spacing":  34.6},
    {"code": "L14523", "type": "ACH", "diameter": 35.0, "mounted_od": 44.4, "edge_thickness": 13, "spacing":  12.6},
    {"code": "L13088", "type": "BCX", "diameter": 42.5, "edge_thickness":  2.2, "spacing":  -9.4},
)
DEFAULT_STOP_DEPTH = -2.7
DEFAULT_STOP_HOLE_D = (20.0, 14.3, 10.0, 7.3)


# Optional design override: invoke with `--from-json <path>`. The JSON is
# expected to carry `elements` (list of element dicts) and `stop` (dict with
# `depth` and `hole_diameters`). Missing keys surface as KeyError when the
# data is consumed below; the framework absorbs file-not-found / invalid-JSON
# at parse time.
_cfg = from_json()
if _cfg is not None:
    _elements_data = _cfg["elements"]
    STOP_DEPTH = float(_cfg["stop"]["depth"])
    STOP_HOLE_D = tuple(float(d) for d in _cfg["stop"]["hole_diameters"])
else:
    _elements_data = DEFAULT_ELEMENTS_DATA
    STOP_DEPTH = DEFAULT_STOP_DEPTH
    STOP_HOLE_D = DEFAULT_STOP_HOLE_D

def _effective_dia(e):
    """Use the mount OD when wider than the bare lens; bare diameter otherwise."""
    d = float(e["diameter"])
    if "mounted_od" in e:
        return max(d, float(e["mounted_od"]))
    return d


ELEMENTS = tuple(
    element(
        code=e["code"], type=e["type"],
        dia=_effective_dia(e), edge_thk=float(e["edge_thickness"]),
        spacing=float(e["spacing"]),
        grip_width=GRIP_WIDTH,
    )
    for e in _elements_data
)
THE_STOP = stop(spacing=STOP_DEPTH, thk=STOP_THK, clr=STOP_CLR)


class M57LensHousing(LensHousing):
    lower_housing_od = 56.0 # old was 56.4
    lower_housing_len = 14.5
    barrel_thk = 2.0
    flange_flange_od = 59.0
    flange_flange_len = 5.0
    fov_angle = 57.0
    grip_depth = GRIP_DEPTH
    grip_width = GRIP_WIDTH
    # v12c's 52mm front element leaves only ~3.5mm radial space to the
    # housing OD; trim the fillet's inner offset so the rim still fits.
    FRONT_FILLET_OFFSET = 4.0
    elements = ELEMENTS
    stop = THE_STOP


class M57LensHood(LensHood):
    wall_thk = 2.0
    hood_clr = 0.4
    hood_length = 20.0
    coupler_overlap = 6.0


# =============================================================================
# DESIGN: shared parts + variant methods
# =============================================================================


def _make_stop_discs(housing, hole_diameters):
    """One `WaterhouseStop` per hole diameter, all sharing the same
    barrel dimensions, thickness, and depth."""
    return tuple(
        WaterhouseStop(
            barrel_id=housing.lower_housing_id,
            barrel_od=housing.lower_housing_od,
            thk=STOP_THK,
            hole_d=h,
            spacing=STOP_DEPTH,
        )
        for h in hole_diameters
    )


# Bambu X2D buildable area on the bed (mm). Layouts must fit within these.
BAMBU_X2D_PLATE_X = 256
BAMBU_X2D_PLATE_Y = 256


class v12c(Design):
    housing = M57LensHousing()
    hood = M57LensHood(
        housing_upper_od=housing.upper_housing_od,
        hood_base_angle=housing.hood_base_angle,
    )
    stop_discs = _make_stop_discs(housing, STOP_HOLE_D)

    @variant(fn=48, default=True)
    def print(self):
        # Compact bed layout sized for the Bambu X2D plate. Each splayed
        # half is rotated 90° around Z so its long axis runs along Y; the
        # two halves stack along Y mirrored across the XZ plane, and one
        # waterhouse stop disc sits on the +X side centered on Y=0.
        # Asserts the bounding footprint fits the printer's buildable area.
        half = half_housing_splay(self.housing).rotate([0, 0, 90])
        flat_stop = self.stop_discs[0].down(STOP_DEPTH - STOP_THK / 2)
        half_bb = bbox(half)
        flat_bb = bbox(flat_stop)
        gap = 12   # ~1.2cm clearance between objects

        pair = mirror_copy(
            half.translate([0, -(half_bb.max[1] + gap / 2), 0]),
            normal=[0, 1, 0],
        )
        pair_bb = bbox(pair)

        stop_placed = flat_stop.translate([
            pair_bb.max[0] + gap + flat_bb.size[0] / 2 - flat_bb.center[0],
            pair_bb.center[1] - flat_bb.center[1],
            0,
        ])

        layout = union(pair, stop_placed)
        layout_bb = bbox(layout)
        if (layout_bb.size[0] > BAMBU_X2D_PLATE_X
                or layout_bb.size[1] > BAMBU_X2D_PLATE_Y):
            raise ValueError(
                f"print layout {layout_bb.size[0]:.1f} x {layout_bb.size[1]:.1f} mm "
                f"exceeds Bambu X2D build plate "
                f"{BAMBU_X2D_PLATE_X} x {BAMBU_X2D_PLATE_Y} mm"
            )
        return layout

    @variant(fn=48)
    def design_spread_out(self):
        # Inspection layout: hood + a mirrored pair of splayed halves
        # (each with a quarter of the stop slot) + one stop disc per
        # entry in `STOP_HOLE_D`, spaced with a uniform gap and Y-aligned
        # on a shared baseline. Too large for the print bed; use the
        # `print` variant for actual printing.
        half = half_housing_splay(self.housing)
        flipped_hood = self.hood.flip("z")   # wide flare on the print bed
        flat_stops = [
            disc.down(STOP_DEPTH - STOP_THK / 2) for disc in self.stop_discs
        ]
        half_bb = bbox(half)
        hood_bb = bbox(flipped_hood)
        flat_bb = bbox(flat_stops[0])   # all discs share the same outer footprint
        gap = self.housing.upper_housing_od   # ~one barrel-diameter of breathing room

        # Center the half-pair on X=0 with `gap` between the two halves.
        pair = mirror_copy(
            half.translate([-(half_bb.max[0] + gap / 2), 0, 0]),
            normal=[1, 0, 0],
        )
        pair_bb = bbox(pair)

        y_baseline = pair_bb.center[1]

        def place_at_x(node, bb, target_center_x):
            return node.translate([
                target_center_x - bb.center[0],
                y_baseline - bb.center[1],
                0,
            ])

        x_hood = pair_bb.min[0] - gap - hood_bb.size[0] / 2
        disc_pitch = flat_bb.size[0] + gap
        discs_placed = [
            place_at_x(
                flat, flat_bb,
                pair_bb.max[0] + gap + flat_bb.size[0] / 2 + i * disc_pitch,
            )
            for i, flat in enumerate(flat_stops)
        ]

        return union(
            pair,
            place_at_x(flipped_hood, hood_bb, x_hood),
            *discs_placed,
        )

    @variant(fn=48)
    def display(self):
        # Lift the hood one coupler_overlap above the true housing top (which
        # sits above upper_housing_len because of the front fillet ring) so
        # the housing's upper rim is visible between the two parts. The
        # widest-aperture stop disc shows fully inserted at its real depth.
        housing_top_z = bbox(self.housing).max[2]
        gap = self.hood.coupler_overlap
        return union(
            self.housing,
            self.hood.up(housing_top_z + gap),
            self.stop_discs[0],
        )

    @variant(fn=48)
    def testing(self):
        # Just one of the two splayed halves, in the same X position as
        # the left half in the `print` variant. For inspecting a single
        # shell in isolation.
        half = half_housing_splay(self.housing)
        half_bb = bbox(half)
        gap = self.housing.upper_housing_od
        return half.translate([-(half_bb.max[0] + gap / 2), 0, 0])


if __name__ == "__main__":
    run()
