"""Stepped lap-joint transforms for halving a 3D-printed assembly.

Generic transforms — no project-specific dimensions. `lap_split_x`
halves a host at X=0 with a stepped tongue/groove on each side so the
two halves self-align radially when pressed together; `lap_splay` lays
one half cut-face-down on the print bed.

These are framework-style transforms (registered as `Node.lap_split_x`
and `Node.lap_splay` via the `@transform` decorator at import time),
so importing this module is enough to make the methods callable on
any Node.
"""

from scadwright import BBox
from scadwright.boolops import difference, intersection, union
from scadwright.primitives import cube, cylinder
from scadwright.transforms import transform


def _lap_split_x_tight_bbox(child, *, side, overlap, clearance=0.0, **_):
    """tight_bbox hook for `lap_split_x`. The transform's body builds a
    top-level Difference (groove subtracted from union(half, tongue)),
    which the framework's bbox visitor can't tighten on its own. We know
    the answer: the result keeps one X half of the housing plus a
    `tongue_w = overlap - clearance` tongue extending past the cut plane
    on the other side. Z and Y are unchanged from the child."""
    from scadwright import tight_bbox as _tb
    cb = _tb(child)
    tongue_w = overlap - clearance
    if side == "minus":
        return BBox(min=cb.min, max=(tongue_w, cb.max[1], cb.max[2]))
    return BBox(min=(-tongue_w, cb.min[1], cb.min[2]), max=cb.max)


@transform("lap_split_x", tight_bbox=_lap_split_x_tight_bbox)
def lap_split_x(node, *, side, overlap, mid_radius, z_min=None, clearance=0.0):
    """Halve the host shape at X=0 with a stepped lap joint of depth `overlap`
    at radial position `mid_radius`. `side` is 'minus' (keep X<=0) or
    'plus' (keep X>=0). The 'minus' and 'plus' results mate INVERSELY
    across the cut plane (not as mirror images): one carries the outer
    extension and the inner recess; the other carries the matching outer
    recess and inner extension.

    Specifically:
      - minus keeps X<=0; its OUTER layer (r >= mid_radius) is extended
        past X=0 into +X by `overlap` (tongue), and its INNER layer
        (r < mid_radius) is recessed from X=0 in -X by `overlap` (groove).
      - plus keeps X>=0; its OUTER layer is recessed (groove) at +X for
        `overlap` mm to receive minus's outer tongue, and its INNER layer
        is extended into -X by `overlap` (tongue) to fill minus's inner
        groove.

    Joint planes therefore land at X=+overlap (outer layer) and at
    X=-overlap (inner layer). Light path between bore and outer surface
    zigzags through the step — light-tight. The step constrains relative
    XY position — self-aligning. Mates by pure X-translation (radial
    press-fit), no axial sliding required.

    `mid_radius` must lie inside the wall everywhere along Z (between
    the bore and the outer wall in every section), or the layers will
    have zero thickness somewhere.

    `z_min` (optional) confines the lap features to z >= z_min. Below
    z_min the housing is just cleanly halved at X=0 with no lap geometry
    — useful when the wall is too thin to host the step (e.g. the M57-fit
    section of a lens housing).

    `clearance` (mm) shrinks the tongue (NOT the groove) so the press
    seats with some play. The shrink is applied two ways: tongue X-extent
    is shorter by `clearance` at the TIP (gives axial seating play); the
    tongue's step-face boundary is pulled away from `mid_radius` by
    `clearance` (gives radial play at the step inside the joint). The
    tongue's outer-cylinder surface (or bore surface for the inner
    tongue) is unchanged so the visible cylinder surface flushes at the
    joint. Default 0 (zero-clearance, may bind on tight prints).
    """
    if side not in ("minus", "plus"):
        raise ValueError(f"side must be 'minus' or 'plus', got {side!r}")
    sign = -1 if side == "minus" else 1
    # `halve()` would auto-size its cutter from the input shape's bbox.
    # As a hoisted custom transform, the shape arg here is a placeholder
    # (1x1x1) at module-build time, not the real housing — so we pass an
    # explicit `size` to suppress bbox introspection.
    big = 200.0
    half = node.halve([sign, 0, 0], size=big)

    # Slabs need only enclose the housing, not be globe-sized. Intersection
    # clips them to the wall geometry, so the step automatically conforms
    # to varying OD/ID along Z (e.g. the funnel transition in wide
    # variants). `big` is sized generously vs typical lens housings (a few
    # hundred mm in any axis), so any reasonable design is enclosed; the
    # exact value matters because OpenSCAD's preview mode draws the full
    # auxiliary geometry every frame and very large slabs cost real
    # interactivity. When z_min is set, the slab is anchored at z=z_min
    # (not Z-centered) so only z >= z_min material is included.
    z_centered = z_min is None
    z_axes = "yz" if z_centered else "y"

    def _slab(width):
        c = cube([width, big, big], center=z_axes)
        return c if z_centered else c.up(z_min)

    tongue_w = overlap - clearance
    # Groove: full overlap on the slab, mid_radius for the radial split.
    # Tongue: shorter slab (clearance at the tip) and the radial split is
    # pulled away from mid_radius by clearance (further out for an outer-
    # layer tongue, further in for an inner-layer tongue), giving the
    # tongue play at both the step face and the tip when seated.
    pos_groove_slab = _slab(overlap)                       # X in [0, overlap]
    neg_groove_slab = _slab(overlap).left(overlap)         # X in [-overlap, 0]
    pos_tongue_slab = _slab(tongue_w)                      # X in [0, tongue_w]
    neg_tongue_slab = _slab(tongue_w).left(tongue_w)       # X in [-tongue_w, 0]

    # `inner_volume` is the cylinder of radius `mid_radius` around Z;
    # outer-layer = node - inner_volume; inner-layer = node & inner_volume.
    # `fn=8` keeps the mask cheap to draw in OpenSCAD preview — the
    # cylinder is invisible in the final geometry, so its radial polygon
    # count doesn't affect output, only per-frame preview cost.
    inner_volume = cylinder(r=mid_radius, h=big, center="z", fn=8)
    inner_volume_outer_tongue = cylinder(r=mid_radius + clearance, h=big, center="z", fn=8)
    inner_volume_inner_tongue = cylinder(r=mid_radius - clearance, h=big, center="z", fn=8)

    if side == "minus":
        # Outer-layer tongue at +X, inner-layer groove at -X.
        tongue = difference(intersection(node, pos_tongue_slab), inner_volume_outer_tongue)
        groove = intersection(intersection(node, neg_groove_slab), inner_volume)
    else:  # plus
        # Inner-layer tongue at -X, outer-layer groove at +X.
        tongue = intersection(intersection(node, neg_tongue_slab), inner_volume_inner_tongue)
        groove = difference(intersection(node, pos_groove_slab), inner_volume)

    return difference(union(half, tongue), groove)


@transform("lap_splay")
def lap_splay(node, *, side, lap_overlap=0.0):
    """Lay one housing half flat on the print bed: rotate so the cut
    face lies parallel to the bed (cut-face-down) and lift the result
    by `lap_overlap` so the lap-joint tongue (which extends past the
    cut plane and would otherwise dip below Z=0 after the rotation)
    rests on the bed.

    `side` selects the rotation direction so the kept material lands
    above the bed regardless of which half was cut. `lap_overlap` is
    the same value passed to `.lap_split_x()`; it's explicit here because
    the framework's `bbox()` returns a conservative AABB across `halve`,
    so the actual minimum Z can't be derived from the splayed shape.
    Pass 0.0 if the half has no lap joint.
    """
    angle = 90 if side == "minus" else -90
    return node.rotate([0, angle, 0]).up(lap_overlap)
