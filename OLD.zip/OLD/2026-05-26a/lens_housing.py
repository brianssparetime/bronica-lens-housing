"""Lens housing with stacked optical elements and a matching clip-on hood.

Shows the recommended multi-part layout (see
docs/organizing_a_project.md). Generic Components live in the REUSABLE
zone with no project-specific defaults; the specific design for an
M57-throat camera lives in the CONCRETE zone as thin subclasses that
fill in measurements as class attributes.

Run:
    python examples/lens-housing.py                                  # print variant (default)
    scadwright build examples/lens-housing.py --variant=display        # assembled view
    scadwright build examples/lens-housing.py --variant=print          # split + spread for inspection
"""

from scadwright import BBox, Component, Param, arg, from_json, print_stamp
from scadwright.boolops import difference, intersection, union
from scadwright.composition_helpers import pack_on_bed
from scadwright.design import Design, run, variant
from scadwright.primitives import cube, polygon
from scadwright.shapes import FilletRing, Funnel, Sector, Tube

from s2_spec import BronicaS2Bayonet
import lap_joint  # noqa: F401 — registers .lap_split_x() / .lap_splay() on Node
from lens_internals import (
    ApertureFeelerSlot,
    DEFAULT_ELEMENT_CLEARANCES,
    Element,
    ElementClearances,
    ElementHolder,
    ElementTestGripper,
    FilletSection,
    HelicoidFocusSlot,
    HousingSection,
    MatingDisc,
    Stop,
    StopHolder,
    TruncFilletRing,
    WaterhouseStop,
    element,
)


# =============================================================================
# REUSABLE: LensHousing and LensHood
# =============================================================================


# Lock spec for the mating disc ↔ locking lens-mount ring lives in a
# shared module so both designs reference one source of truth without
# pulling each other's Design class into scope (which would collide on
# variant names like `print`).
from housing_lock_spec import (
    BRONICA_S2_MATING_DISC_BEAD,
    BRONICA_S2_MATING_DISC_TABS,
    HOUSING_GROOVE_ANGLE_DEG,
    MATING_DISC_CLEARANCE,
    MatingDiscBead,
    MatingDiscTabs,
)


class LensHousing(Component):
    """Generic lens barrel: lower recess + flange + upper housing (narrow
    or funnel-widened) + element holders + front fillet. A matching hood
    Component can read the outer dimensions and hood cone angle off this
    housing to mate without shared scope."""

    FRONT_FILLET_OFFSET = 5.0   # aperture rim inset from the front element's grip ID

    stop = Param(Stop, default=None)
    mating_disc = Param(MatingDisc, default=None)
    mating_disc_tabs = Param(MatingDiscTabs, default=None)
    mating_disc_bead = Param(MatingDiscBead, default=None)
    helicoid_focus_slot = Param(HelicoidFocusSlot, default=None)
    aperture_feeler_slot = Param(ApertureFeelerSlot, default=None)
    # When False (default), the lower-housing mid and inner segments
    # are only included if at least one element holder or the stop
    # slot reaches into their z range. Outer is always present (needed
    # for mechanical fit with the camera's outer throat step). When
    # True, all three lower segments are always present regardless of
    # element/stop placement — used by the `lower_housing_testfit`
    # variant to exercise the full structural lower-housing geometry.
    force_all_lower_segments = Param(bool, default=False)
    equations = """
        # Wall-thickness split: the lower (M57-fit) section needs to fit
        # inside the camera's stepped M57 throat — its OD is constrained
        # from above by camera-body geometry at each axial step. The lower
        # housing is therefore three stacked segments (outer/mid/inner,
        # flange-side to deepest), each with its own OD and wall. The
        # flange-flange/funnel/upper section sits outside the camera body
        # and is wide enough to host a stepped lap joint internally —
        # typically a thick (~5 mm radial) wall, independent of the lower
        # segments because it's constrained by different physical realities.
        hood_base_angle = 90 - fov_angle / 2
        lower_outer_od, lower_outer_len, lower_outer_thk > 0
        lower_mid_od,   lower_mid_len,   lower_mid_thk   > 0
        lower_inner_od, lower_inner_len, lower_inner_thk > 0
        upper_barrel_thk > 0
        # Bore-side fillet ring angle (from horizontal). 45° is the
        # self-supporting threshold for FDM overhangs; steeper (more
        # vertical, larger angle here) is easier to print but consumes
        # more axial extent inside the wider segment.
        bore_fillet_base_angle > 0
        bore_fillet_base_angle <= 90
        flange_flange_od, flange_flange_len, fov_angle, hood_base_angle > 0
        grip_depth, grip_width > 0
        mount_offset >= 0
        # Alignment-groove cross-section: V-prism cut into the bottom
        # face of the upper housing at the stop-slot's angular position
        # (+Y in housing frame). Width = chord on the surface; depth =
        # how far the apex pokes into the upper-housing material.
        alignment_groove_depth, alignment_groove_width > 0
        # Segment IDs derived from each segment's OD and wall thickness.
        lower_outer_id = lower_outer_od - 2 * lower_outer_thk
        lower_mid_id   = lower_mid_od   - 2 * lower_mid_thk
        lower_inner_id = lower_inner_od - 2 * lower_inner_thk
        # Stepped-bore monotonicity: the throat narrows as we go deeper, so
        # each segment's ID must be no greater than the segment above it.
        lower_outer_id >= lower_mid_id
        lower_mid_id   >= lower_inner_id
        # Axial layout. Outer spans the flange-side step and extends above
        # the flange into the mount-ring zone (so it ends at mount_offset);
        # mid and inner stack below, into the throat. All three lengths
        # measure axial extent.
        lower_outer_z_top = mount_offset
        lower_outer_z_bot = -lower_outer_len
        lower_mid_z_top   = lower_outer_z_bot
        lower_mid_z_bot   = lower_mid_z_top - lower_mid_len
        lower_inner_z_top = lower_mid_z_bot
        lower_inner_z_bot = lower_inner_z_top - lower_inner_len
        # `housing_insertion_depth` is the total depth past the flange the
        # lower segments occupy; `lower_housing_len` is the full lower-tube
        # length including the above-flange mount-ring portion that outer
        # carries.
        housing_insertion_depth = lower_outer_len + lower_mid_len + lower_inner_len
        lower_housing_len = housing_insertion_depth + mount_offset
        unconstricted = tuple(e for e in elements:tuple if not e.constricted)
        max_upper_ele_dia = max((e.dia for e in unconstricted), default=0.0)
        # Bore at the funnel base (top of the lower section) is outer's ID.
        is_wide = max_upper_ele_dia > lower_outer_id
        expansion_funnel_len = min((e.face_z_bot for e in unconstricted), default=inf)
        upper_housing_len = max(e.face_z_top for e in elements)
        upper_housing_od = (max_upper_ele_dia + 2 * upper_barrel_thk) if is_wide else flange_flange_od
        # Per-element fit: the bore only narrows with depth, so the deepest
        # point an element reaches (its face_z_bot) determines the binding
        # segment.
        all(
            not e.constricted
            or e.throat_dia_required <= (
                lower_outer_id if e.face_z_bot >= lower_outer_z_bot
                else lower_mid_id if e.face_z_bot >= lower_mid_z_bot
                else lower_inner_id
            )
            for e in elements
        )
        # Wide-mode invariant: in funnel variants the funnel runs from
        # mount_offset (the top of the mount-ring zone, where the lower
        # tube ends) to expansion_funnel_len (the bottom of the lowest
        # unconstricted element). The funnel needs positive height, so the
        # lowest unconstricted element must sit strictly above the mount-
        # ring zone. (`element()` now defines constricted as face_z_bot <
        # mount_offset, so unconstricted elements have face_z_bot >=
        # mount_offset; this rule guards the equality edge case.)
        not is_wide or expansion_funnel_len > mount_offset
        # Stop slot must lie entirely in a section we can handle:
        #   (a) below the flange-flange (z <= mount_offset) — uniform
        #       lower-housing OD;
        #   (b) above the flange/funnel transition — uniform upper-
        #       housing OD;
        #   (c) (wide variant only) entirely within the funnel range
        #       [mount_offset, expansion_funnel_len] — handled by the
        #       per-gripper-OD logic in `wall_od_at_z` and the StopHolder
        #       od_top/od_bot pair.
        # The flange-overlap and mount-ring/flange transition zones stay
        # forbidden because they have a wall-OD discontinuity no cylindrical
        # gripper can span. The `?stop` references make these lines auto-
        # skip when no stop is supplied.
        slot_lo = ?stop.spacing - (stop.thk + stop.clr) / 2
        slot_hi = ?stop.spacing + (stop.thk + stop.clr) / 2
        upper_floor = expansion_funnel_len if is_wide else mount_offset + flange_flange_len
        ?slot_hi <= mount_offset or slot_lo >= upper_floor or (is_wide and slot_lo >= mount_offset and slot_hi <= expansion_funnel_len)
    """

    def _lower_segments_present(self):
        """Set of lower-housing segment names ({'outer'}, {'outer','mid'},
        or {'outer','mid','inner'}) actually included in the build.
        Outer is always present (needed for mechanical fit with the
        camera's outer throat step). Mid is included only if some
        element holder or the stop slot reaches into mid's z range
        (face_z_bot < lower_outer_z_bot); inner only if something
        reaches into inner's z range (face_z_bot < lower_mid_z_bot).
        `force_all_lower_segments=True` (set on the testfit housing)
        forces all three regardless — exercises the full structural
        geometry for fit-check prints.
        """
        present = {"outer"}
        if self.force_all_lower_segments:
            return {"outer", "mid", "inner"}
        # Deepest z reached by any element holder or the stop slot.
        z_candidates = [e.face_z_bot for e in self.elements]
        if self.stop is not None:
            z_candidates.append(self.stop.spacing - (self.stop.thk + self.stop.clr) / 2)
        if not z_candidates:
            return present  # no elements, no stop — only the structural outer ring
        deepest = min(z_candidates)
        if deepest < self.lower_outer_z_bot:
            present.add("mid")
        if deepest < self.lower_mid_z_bot:
            present.add("inner")
        return present

    def _effective_housing_insertion_depth(self):
        """Actual axial depth below the flange the lower housing extends,
        accounting for any segments trimmed by `_lower_segments_present`.
        Equal to `housing_insertion_depth` (the FULL depth) when all
        three segments are present; less when mid/inner are excluded."""
        present = self._lower_segments_present()
        depth = self.lower_outer_len
        if "mid" in present:
            depth += self.lower_mid_len
        if "inner" in present:
            depth += self.lower_inner_len
        return depth

    def _sections(self):
        """List of `HousingSection` Components describing the housing's
        wall geometry. Order doesn't matter — sections may overlap in z
        (e.g. flange + funnel in wide mode where the flange's wider OD
        wins). The single source of truth for both `build()` and
        `wall_od_at_z`.

        The lower housing is up to three stacked segments — outer
        (flange-side, widest, continues into the mount-ring zone above
        the flange), mid (intermediate, carries the helicoid focus
        slot), inner (deepest, narrowest). Mid and inner are only
        present if `_lower_segments_present()` says so. The flange-
        flange wall sits on top of outer, and the mating disc (if
        present) wraps outer."""
        outer_id = self.lower_outer_id
        outer_od = self.lower_outer_od
        mo = self.mount_offset
        flange_top = mo + self.flange_flange_len
        present = self._lower_segments_present()
        sections = [
            # Lower outer: from the outer/mid step up through the flange
            # plane into the mount-ring zone (z_top = mount_offset). The
            # flange-flange and (in narrow mode) the upper tube continue
            # this OD upward.
            HousingSection(
                z_bot=self.lower_outer_z_bot, z_top=self.lower_outer_z_top,
                bot_id=outer_id, top_id=outer_id,
                thk=self.lower_outer_thk,
            ),
        ]
        if "mid" in present:
            sections.append(
                # Lower mid: middle step. Carries the helicoid focus slot.
                HousingSection(
                    z_bot=self.lower_mid_z_bot, z_top=self.lower_mid_z_top,
                    bot_id=self.lower_mid_id, top_id=self.lower_mid_id,
                    thk=self.lower_mid_thk,
                )
            )
        if "inner" in present:
            sections.append(
                # Lower inner: deepest step. The helicoid slot does NOT enter
                # this segment (the cutter is bounded above by the mid/inner
                # boundary).
                HousingSection(
                    z_bot=self.lower_inner_z_bot, z_top=self.lower_inner_z_top,
                    bot_id=self.lower_inner_id, top_id=self.lower_inner_id,
                    thk=self.lower_inner_thk,
                )
            )
        if "mid" in present:
            sections.append(
                # Bore fillet at the outer/mid step. Sits inside outer just
                # above the step plane; closes the (small) wall-overlap and
                # gives the bore a self-supporting slope for print.
                FilletSection(
                    z_bot=self.lower_outer_z_bot,
                    bot_id=self.lower_mid_id,
                    top_id=self.lower_outer_id,
                    base_angle=self.bore_fillet_base_angle,
                )
            )
        if "inner" in present:
            sections.append(
                # Bore fillet at the mid/inner step. Without this the inner
                # wall doesn't touch mid's wall — there's a 1 mm radial gap
                # at the step plane.
                FilletSection(
                    z_bot=self.lower_mid_z_bot,
                    bot_id=self.lower_inner_id,
                    top_id=self.lower_mid_id,
                    base_angle=self.bore_fillet_base_angle,
                )
            )
        # Flange-flange: thicker wall sitting on top of the mount ring.
        # Bore matches outer (its lower neighbor). Always present.
        sections.append(HousingSection(
            z_bot=mo, z_top=flange_top,
            bot_id=outer_id, top_id=outer_id,
            thk=(self.flange_flange_od - outer_id) / 2,
        ))
        if self.is_wide:
            # Funnel widens the bore from outer's ID to the largest
            # unconstricted element; its wall uses upper_barrel_thk.
            # Overlaps the flange in z=[mo, flange_top]; in wall_od_at_z
            # the flange's wider OD wins via max() across containing
            # sections.
            sections.append(HousingSection(
                z_bot=mo, z_top=self.expansion_funnel_len,
                bot_id=outer_id, top_id=self.max_upper_ele_dia,
                thk=self.upper_barrel_thk,
            ))
            # Upper (above the funnel): uniform wide bore.
            sections.append(HousingSection(
                z_bot=self.expansion_funnel_len, z_top=self.upper_housing_len,
                bot_id=self.max_upper_ele_dia, top_id=self.max_upper_ele_dia,
                thk=self.upper_barrel_thk,
            ))
        else:
            # Non-wide upper: continues outer's bore at the flange-flange OD.
            sections.append(HousingSection(
                z_bot=flange_top, z_top=self.upper_housing_len,
                bot_id=outer_id, top_id=outer_id,
                thk=(self.upper_housing_od - outer_id) / 2,
            ))
        if self.mating_disc is not None:
            # Mating disc: extra ring on the housing's outer surface
            # bridging the gap to the lens-mount ring's bore. ID =
            # lower_outer_od (wraps outer concentrically); OD and z range
            # come from the MatingDisc spec.
            md = self.mating_disc
            sections.append(HousingSection(
                z_bot=md.z_bot, z_top=md.z_top,
                bot_id=outer_od, top_id=outer_od,
                thk=(md.od - outer_od) / 2,
            ))
        return sections

    def wall_od_at_z(self, z):
        """Outer-wall diameter at axial position z. Used to size each
        stop-holder gripper to its local wall thickness so a gripper
        that lands in a narrowing funnel doesn't poke out past the wall.
        Returns the max OD across all sections containing z (overlapping
        sections — flange + funnel in wide mode — resolve via max)."""
        matching = [s for s in self._sections() if s.z_bot <= z <= s.z_top]
        if not matching:
            return 0.0
        return max(s.od_at(z) for s in matching)

    def wall_id_at_z(self, z):
        """Inner bore diameter at axial position z. Used to size the
        stop disc and the gripper's inner cylinder to the local bore,
        so the disc fills the bore and the gripper intrudes only
        `grip_depth/2` into the optical path regardless of which
        section the stop lands in. Overlapping sections resolve via
        MIN — wall material lives wherever any section has material,
        so the bore is bounded by the narrowest inner radius at z."""
        matching = [s for s in self._sections() if s.z_bot <= z <= s.z_top]
        if not matching:
            return 0.0
        return min(s.id_at(z) for s in matching)

    def _front_fillet(self):
        """Build the same TruncFilletRing instance used in `build()`,
        so its tight_bbox / equations are usable from here without
        duplicating the construction args."""
        front_ele = max(self.elements, key=lambda e: e.spacing)
        return TruncFilletRing(
            id=front_ele.dia - self.grip_depth + self.FRONT_FILLET_OFFSET,
            od=self.upper_housing_od,
            base_angle=self.hood_base_angle,
            slant="inwards",
            rim_width=2,
        )

    def _swept_slot_cutter(self, slot, wall_od):
        """Generic curved-bar cutter for a swept slot (helicoid focus
        slot or aperture feeler slot). One shell `slot.depth` mm thick
        (radially, from `wall_od/2` inward), intersected with a wedge
        that covers both the locked-side arc (centered at `slot.angle`,
        `slot.width` wide at `wall_od`) and the sweep arc (extending CW
        from `slot.angle` by `sweep_arc_deg`). Single uniform depth —
        the pin/feeler rides the groove throughout the bayonet rotation;
        nothing needs a full through-cut.

        The shell's outer cylinder pokes past the wall OD by a small
        delta for a clean exterior cut. `slot.bottom_overshoot` extends
        the cutter past `z_bot` axially — set this when the slot's deep
        end sits exactly on a segment boundary (e.g. the helicoid slot's
        z_bot at the mid/inner step) to drop the coplanar bottom face
        and avoid a rendering sliver. Leave it 0 when the slot's deep
        end is in the segment interior."""
        import math
        s = slot
        outer_delta = 0.1                     # past OD; just for clean exterior cut
        h = (s.z_top - s.z_bot) + s.bottom_overshoot
        outer_r = wall_od / 2 + outer_delta
        inner_r = wall_od / 2 - s.depth
        # Angular half-width = (arc / 2) / radius, in degrees. Use the
        # segment OD as the reference radius so `width` reads as the
        # arc length along the visible outer face.
        half_arc_deg = math.degrees((s.width / 2) / (wall_od / 2))
        shell = Tube(h=h, od=2 * outer_r, id=2 * inner_r)
        # Wedge angular extent: swept convex hull of the pin/feeler at
        # LOCK (centered at `slot.angle`, ±half_arc_deg wide) and at
        # INSERTION (centered at `slot.angle − sweep_arc_deg`, also
        # ±half_arc_deg wide). The pin/feeler width contributes half_arc
        # on BOTH sides — locked-side (CCW of `slot.angle`) and
        # insertion-side (CW of `slot.angle − sweep_arc_deg`). Sector
        # `angles=(a, b)` sweeps CCW from a to b.
        wedge = Sector(
            r=outer_r,
            angles=(
                s.angle - s.sweep_arc_deg - half_arc_deg,
                s.angle + half_arc_deg,
            ),
        ).linear_extrude(height=h)
        return intersection(shell, wedge).up(s.z_bot - s.bottom_overshoot)

    def _alignment_groove_cutter(self):
        """V-prism cutter for the alignment groove on the bottom face
        of the upper housing. Sits at theta=90° (housing-frame +Y, the
        stop-slot's angular position) so that when the lens locks to the
        camera both end up pointing straight up in camera-frame. Cross-
        section is a triangle of base `alignment_groove_width` and depth
        `alignment_groove_depth`, base on the bottom face (z=mount_offset)
        and apex up into the flange-flange. Extends radially from just
        inside the mating disc's OD out past the flange-flange's OD."""
        gw = self.alignment_groove_width
        gd = self.alignment_groove_depth
        r_inner = self.mating_disc.od / 2
        r_outer = self.flange_flange_od / 2
        overshoot = 0.5
        # Triangle built in the 2D X-Y plane with apex at +Y. Base sits
        # below Y=0 by `overshoot` so the cutter opens past the bottom
        # face for a clean exterior cut.
        tri = polygon(points=[
            (-gw / 2, -overshoot),
            (gw / 2, -overshoot),
            (0, gd),
        ])
        # Extrude in Z, then rotate so Z (extrusion) becomes the radial
        # +Y direction and Y (apex) becomes axial +Z. After rotate
        # [90,0,0]: original Y→Z, original Z→-Y, so the extrusion runs
        # from Y=0 toward -Y. Translating by +(r_outer + overshoot) in
        # Y lands the prism spanning Y ∈ [r_inner − overshoot, r_outer + overshoot].
        # Translating up by mount_offset puts the base on the bottom
        # face (with the overshoot poking past it).
        length = (r_outer - r_inner) + 2 * overshoot
        return (
            tri.linear_extrude(height=length)
            .rotate([90, 0, 0])
            .translate([0, r_outer + overshoot, self.mount_offset])
        )

    def _mating_disc_tabs_geometry(self):
        """Tabs protruding radially outward from the mating disc's OD.

        Each tab is a parallel-sided box (not an angular wedge): in the
        tab's local frame +X is radial outward at the tab's center
        angle, +Y is tangential. The box spans
          x ∈ [disc_r − fuse_eps, disc_r + tabs.radial]
          y ∈ [−tabs.circumferential/2, +tabs.circumferential/2]
          z ∈ [tabs.z_top − tabs.axial, tabs.z_top]
        rotated to each angle in `tabs.angles_deg + housing_tab_offset_deg`.
        The notches in the lens-mount ring are placed at the UNOFFSET
        angles (via the conversion in s2_locking_mount.py); the
        offset is applied here only to compensate for the testfit
        print's angular mirroring (see housing_lock_spec.py for the
        why). Parallel sides ensure a precise fit against the matching
        pocket in the ring's bore wall.
        """
        tabs = self.mating_disc_tabs
        disc_r = self.mating_disc.od / 2
        fuse_eps = 0.1
        rect = polygon(points=[
            (disc_r - fuse_eps, -tabs.circumferential / 2),
            (disc_r + tabs.radial, -tabs.circumferential / 2),
            (disc_r + tabs.radial, +tabs.circumferential / 2),
            (disc_r - fuse_eps, +tabs.circumferential / 2),
        ])
        z_bot = tabs.z_top - tabs.axial
        one_tab = rect.linear_extrude(height=tabs.axial).up(z_bot)
        return union(*(
            one_tab.rotate([0, 0, theta + tabs.housing_tab_offset_deg])
            for theta in tabs.angles_deg
        ))

    def _mating_disc_bead_geometry(self):
        """Snap-fit bead around the mating disc's OD. Continuous 360°
        triangular ridge: apex at radius disc_r + bead.height, base
        flush with the disc OD over an axial span of bead.axial,
        centered at bead.z_center. Built as a 2D triangle in the
        (radial, axial) plane (= xy in the polygon, x → radial, y →
        axial), rotate-extruded around the z axis.
        """
        bead = self.mating_disc_bead
        disc_r = self.mating_disc.od / 2
        half_w = bead.axial / 2
        # The base sits on the disc OD; sample the inner edge slightly
        # inside the disc (- fuse_eps) so the union with the disc
        # closes cleanly without a coplanar face.
        fuse_eps = 0.05
        cross = polygon(points=[
            (disc_r - fuse_eps, bead.z_center - half_w),
            (disc_r + bead.height, bead.z_center),
            (disc_r - fuse_eps, bead.z_center + half_w),
        ])
        return cross.rotate_extrude()

    def tight_bbox(self):                                  # framework hook: declare true post-Difference extents
        # Default tight_bbox would walk into the slot's `difference()`
        # and raise. The slot is fully contained within the barrel, so
        # it doesn't change outer extents. Compute the true envelope
        # from the wall sections (max OD across all of them) plus the
        # front fillet's truncated rim height (read from the fillet's
        # own equation-derived z_t — no math duplication).
        sections = self._sections()
        max_r = max(
            max(s.od_at(s.z_bot) for s in sections),
            max(s.od_at(s.z_top) for s in sections),
        ) / 2
        min_z = -self._effective_housing_insertion_depth()
        max_z = self.upper_housing_len + self._front_fillet().z_t
        return BBox(min=(-max_r, -max_r, min_z), max=(max_r, max_r, max_z))

    def build(self):
        # Above the flange the bore is uniform (outer continues through
        # the mount-ring zone, then the flange-flange/funnel/upper take
        # over), so `upper_id` is one value. Below the flange the bore
        # steps through outer/mid/inner; constricted-element holders pick
        # their OD from the local wall bore via `wall_id_at_z(spacing)`
        # so each holder sits cleanly inside the segment containing it.
        upper_id = self.max_upper_ele_dia if self.is_wide else self.lower_outer_id

        # Wall sections: outer / mid / inner / flange-flange / (funnel /
        # upper) / optional mating disc. Single source of truth
        # (`_sections()`) used by both this build and `wall_od_at_z`.
        sections = self._sections()
        # Bare barrel — engravings are no longer part of build() so the
        # force_render scope in the variant chain caches just the
        # structural mesh. See `engravings()` for the cutter geometry
        # and the variant methods for where it's applied.
        barrel = union(*sections)

        # Slot OD: the maximum housing OD at the slot's z range. In the
        # uniform-OD allowed bands this is just the local OD; in the
        # funnel band the slot's TOP has the largest local OD (funnel
        # widens upward), so we use that. +1 mm radial overshoot avoids
        # cylinder-on-cylinder coplanar faces in the difference.
        if self.stop is not None:
            s = self.stop
            slot_h = s.thk + s.clr
            half_gw = 0.5 * self.grip_width
            slot_od = self.wall_od_at_z(s.spacing + slot_h / 2)
            slot_id = self.wall_id_at_z(s.spacing) - 0.1
            slot = Tube(
                h=slot_h, od=slot_od + 1, id=slot_id,
            ).halve([0, 1, 0]).up(s.spacing - slot_h / 2)
            barrel = difference(barrel, slot)

        # Skip the slot cutters when the corresponding lower segment is
        # absent — no segment, no material to cut, and no camera-body
        # pin to clear at this depth either.
        present = self._lower_segments_present()
        if self.helicoid_focus_slot is not None and "mid" in present:
            barrel = difference(
                barrel,
                self._swept_slot_cutter(self.helicoid_focus_slot, self.lower_mid_od),
            )
        if self.aperture_feeler_slot is not None and "inner" in present:
            barrel = difference(
                barrel,
                self._swept_slot_cutter(self.aperture_feeler_slot, self.lower_inner_od),
            )

        barrel = difference(barrel, self._alignment_groove_cutter())

        if self.mating_disc_tabs is not None and self.mating_disc is not None:
            barrel = union(barrel, self._mating_disc_tabs_geometry())

        if self.mating_disc_bead is not None and self.mating_disc is not None:
            barrel = union(barrel, self._mating_disc_bead_geometry())

        yield barrel

        for e in self.elements:
            # Constricted elements sit inside the stepped lower bore, so
            # pick the holder OD from the local wall ID at the element's
            # center — the holder mates with whatever segment contains it.
            # Unconstricted elements live above the flange where the bore
            # is uniform.
            holder_od = self.wall_id_at_z(e.spacing) if e.constricted else upper_id
            # Known limitation (wide variants only): when an unconstricted
            # element's dia equals max_upper_ele_dia, holder_od == its
            # own dia and the holder's surround tube has thk =
            # -e.clearances.radial/2 (negative). The fix is to size the
            # widest element's holder off upper_housing_od (wall outer)
            # rather than upper_id (wall inner == element dia). Leaving
            # as a follow-up.
            holder = ElementHolder(
                element=e, od=holder_od,
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )
            # Fuse the holder against the cylindrical section whose
            # inner bore matches its OD: this is the case where holder
            # and barrel share a coincident cylindrical surface that
            # would otherwise survive the yield-union as an internal
            # seam (exposed as a non-manifold edge after `halve`).
            # `self_only=True` returns just the extended holder; the
            # host section is already in the barrel union we yielded
            # above, so it doesn't need to come along here too. Funnel
            # sections (`bot_id != top_id`) don't qualify — their inner
            # radius varies with z, so they have no flat cylindrical
            # match to the holder. When no match exists (e.g. a
            # wide-mode unconstricted element inside a funnel), the
            # holder and barrel don't share a coincident face and a
            # plain yield is fine.
            host_section = next(
                (s for s in sections
                 if s.z_bot <= e.spacing <= s.z_top
                 and s.bot_id == s.top_id
                 and abs(s.bot_id - holder_od) < 1e-6),
                None,
            )
            if host_section is not None:
                yield holder.fuse(host_section, self_only=True)
            else:
                yield holder

        if self.stop is not None:
            # Per-gripper OD: each gripper's outer cylinder is sized to
            # the local wall OD at the gripper's BOTTOM (the narrowest
            # point in its z extent for an upward-widening funnel), so
            # the gripper is fully embedded in wall material with no
            # radial overshoot anywhere along its height.
            upper_z_bot = s.spacing + slot_h / 2
            lower_z_bot = s.spacing - slot_h / 2 - half_gw
            yield StopHolder(
                stop=self.stop,
                od_top=self.wall_od_at_z(upper_z_bot),
                od_bot=self.wall_od_at_z(lower_z_bot),
                barrel_id=self.wall_id_at_z(s.spacing),
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        yield self._front_fillet().attach(barrel, fuse=True)

    def engravings(self):
        """Cutter geometry for the two engravings, in housing-local frame.

        Returned as a single union so a variant chain can apply
        ``difference(housing.force_render(), housing.engravings())``
        and keep the per-glyph CGAL work out of the cached subtree.

        - Upper-housing label: text on the topmost uniform section's
          ``outer_wall``. Picks the same section ``build()`` would have
          decorated (``z_top == upper_housing_len`` and uniform OD).
        - Front-fillet label: text on the truncated fillet's
          ``slanted_face``. Positioned with ``.up(upper_housing_len)``
          to match where ``attach(barrel, fuse=True)`` lands the fillet
          in ``build()`` (sub-mm fuse offset is below engraving tolerance)."""
        upper_section = next(
            s for s in self._sections()
            if s.z_top == self.upper_housing_len and s.bot_id == s.top_id
        )
        upper_label = "\n".join(
            [f"{design_name}:"]
            + [e.code for e in self.elements]
            + [print_stamp()]
        )
        upper_cutter = upper_section.text_geometry(
            label=upper_label, on="outer_wall", angle=0,
            font_size=4, line_spacing=1.4, relief=-0.6,
        )
        fillet_cutter = self._front_fillet().up(self.upper_housing_len).text_geometry(
            label=FRONT_FILLET_LABEL,
            on="slanted_face", angle=0,
            font_size=4, relief=-0.6,
        )
        return union(upper_cutter, fillet_cutter)


class LensHood(Component):
    """Generic clip-on hood sized by a paired housing. `housing_upper_od`
    and `hood_base_angle` come from the housing; the rest are hood-specific.
    Built in its mounted orientation: coupler at z=0, funnel flaring upward.
    The print variant flips it."""

    equations = """
        housing_upper_od, hood_base_angle, wall_thk, hood_length, coupler_overlap > 0
        hood_clr >= 0
        id_coupler = housing_upper_od + hood_clr
        od_coupler = id_coupler + 2 * wall_thk
        flare_od = housing_upper_od + 2 * hood_length * tan(90 - hood_base_angle)
        # Optional raised-text label wrapped around the coupler's outer
        # wall. Empty string = no engraving. Applied directly to the
        # coupler Tube in build() (via `add_text` on Tube's built-in
        # `outer_wall` anchor) so the text wraps with the framework's
        # default cylindrical orientation: upright glyphs, line reading
        # L-to-R when viewed from outside, glyph bottoms toward -Z.
        ?label:str = ?label or ""
    """

    def build(self):                                       # framework hook: required; returns the shape
        coupler = Tube(
            h=self.coupler_overlap, id=self.id_coupler, thk=self.wall_thk,
        )
        if self.label:
            # at_z nudges the line axially. The framework pre-shifts the
            # text by -font_size/2 to "center" the line on the surface,
            # but that centers the full em-box; the visible cap body
            # (~0.7 * font_size) ends up biased toward -Z because the
            # descender space contributes to the shift without contributing
            # visible mass. at_z = (font_size - cap_height) / 2 ≈
            # 0.15 * font_size compensates so the cap body's centerline
            # sits at the anchor's z.
            coupler = coupler.add_text(
                label=self.label, on="outer_wall",
                font_size=4, relief=0.5,
                at_z=1.8,
            )
        yield coupler
        yield Funnel(
            h=self.hood_length, thk=self.wall_thk,
            bot_od=self.housing_upper_od, top_od=self.flare_od,
        ).attach(coupler, fuse=True)
        yield FilletRing(
            id=self.id_coupler, od=self.od_coupler,
            base_angle=63, slant="inwards",
        ).attach(coupler, fuse=True)


# =============================================================================
# CONCRETE: the specific M57 design
# =============================================================================


GRIP_DEPTH = 1.5
GRIP_WIDTH = 1.0

# Bayonet contract — single source of truth for dimensions shared with
# the lens mount. The housing reads three values from `BronicaS2Bayonet`:
#   - mount_protrusion: axial extent of the lens-mount ring above the
#     camera flange (z=[0, mount_protrusion]). The M57-restricted lower
#     tube extends up to this z; the flange-flange rests on top of the
#     ring; the funnel starts here with a sharper angle so the housing
#     stays the same total length and no elements move in absolute z.
#   - lens_mount_od: OD of the lens-mount ring; sets `flange_flange_od`
#     so the two parts rest flush at the assembly seam.
#   - lens_mount_bore: inner bore of the ring; the mating disc fits
#     inside it (with MATING_DISC_CLEARANCE slip).
# Local alias for the most-used value — variant code stays readable.
MOUNT_OFFSET = BronicaS2Bayonet.mount_protrusion

# MATING_DISC_CLEARANCE is imported above from housing_lock_spec so both
# the housing (sizing the mating disc OD) and the locking ring (sizing
# the tab-notch cutout relative to the disc edge) agree on one value.

# Waterhouse stop: 1.5mm disc, 0.5mm slot clearance for sliding fit.
# Depth and hole-diameter list come from the design (defaults below or
# loaded from --config).
STOP_THK = 1.5
STOP_CLR = .5

# Built-in defaults (used unless --from-json overrides). Front to rear.
# `mounted_od` is optional and only applies to the element that carries it
# (its mount/cell is wider than the bare lens); the housing uses
# max(diameter, mounted_od) for clearance on those elements.
# `extra_radial` (mm) is added on top of DEFAULT_ELEMENT_CLEARANCES.radial
# for that element's holder — looser fit for elements whose OD measures
# slightly larger than the catalog dia or whose edge profile chips into
# the surround. Default 0 (use the project-wide radial clearance as-is).
DEFAULT_ELEMENTS_DATA = (
    {"code": "L7325",  "type": "NMN", "diameter": 52.0, "edge_thickness": 6.2, "spacing":  34.6, "extra_radial": 0.3, "extra_axial": -0.1},
    {"code": "L14523", "type": "ACH", "diameter": 35.0, "mounted_od": 44.4, "edge_thickness": 13, "spacing":  12.6, "extra_radial": 0.8},
    {"code": "L13088", "type": "BCX", "diameter": 42.5, "edge_thickness":  2.2, "spacing":  -9.4, "extra_radial": 0.3, "extra_axial": 0.1},
)
DEFAULT_STOP_DEPTH = -2.7
DEFAULT_STOP_HOLE_D = (20.0, 14.3, 10.0, 7.3)
DEFAULT_FOV_ANGLE = 57.0
DEFAULT_FOCAL_LENGTH = 89
DEFAULT_MAX_APERTURE = 2.9
DEFAULT_DESIGN_NAME = "lens_housing"


# CLI flag: suppress the lock mechanism (tabs + bead) in the
# `lower_housing_testfit` variant. Default: lock mech IS present, so the
# testfit piece exercises the same disc geometry the production housing
# uses against the locking lens-mount ring. Pass `--no_locking_mech` to
# print a plain disc instead (e.g. to test pre-lock-mech fit, or to
# isolate which feature is causing a fit problem).
NO_LOCKING_MECH = arg("no_locking_mech", default=False, type=bool)


# Optional design override: invoke with `--from-json <path>`. The JSON
# carries `elements` (list of element dicts) and `stop` (dict with `depth`
# and `hole_diameters`); optionally `fov` (hood half-angle source), `name`
# (design label, surfaced as `design_name` for downstream use), and
# `focal_length` / `max_aperture` (engraved on the front fillet ring).
# `from_json(default=...)` deep-merges the JSON over `default` — recursive
# for dicts, replace-in-place for everything else — so missing keys (or
# no `--from-json` at all) fall through to the defaults automatically.
_cfg = from_json(default={
    "elements": DEFAULT_ELEMENTS_DATA,
    "stop": {"depth": DEFAULT_STOP_DEPTH, "hole_diameters": DEFAULT_STOP_HOLE_D},
    "fov": DEFAULT_FOV_ANGLE,
    "name": DEFAULT_DESIGN_NAME,
    "focal_length": DEFAULT_FOCAL_LENGTH,
    "max_aperture": DEFAULT_MAX_APERTURE,
})
_elements_data = _cfg["elements"]
STOP_DEPTH = float(_cfg["stop"]["depth"])
STOP_HOLE_D = tuple(float(d) for d in _cfg["stop"]["hole_diameters"])
FOV_ANGLE = float(_cfg["fov"])
design_name = _cfg["name"]
FOCAL_LENGTH = float(_cfg["focal_length"])
MAX_APERTURE = float(_cfg["max_aperture"])

FRONT_FILLET_LABEL = f"BRIOTAR {FOCAL_LENGTH:g}mm f/{MAX_APERTURE:g}"

def _effective_dia(e):
    """Use the mount OD when wider than the bare lens; bare diameter otherwise."""
    d = float(e["diameter"])
    if "mounted_od" in e:
        return max(d, float(e["mounted_od"]))
    return d


def _element_clearances(e):
    """Per-element clearances. Starts from the project default and adds
    the dict's `extra_radial` (a DIAMETER delta — `clearances.radial`
    is added directly to the element diameter to get the holder's bore,
    so the actual per-side radial gap is `radial / 2`). Axial uses the
    default; override per-element with an `extra_axial` key if a future
    element needs it."""
    return ElementClearances(
        axial=DEFAULT_ELEMENT_CLEARANCES.axial + float(e.get("extra_axial", 0)),
        radial=DEFAULT_ELEMENT_CLEARANCES.radial + float(e.get("extra_radial", 0)),
    )


ELEMENTS = tuple(
    element(
        code=e["code"], type=e["type"],
        dia=_effective_dia(e), edge_thk=float(e["edge_thickness"]),
        spacing=float(e["spacing"]),
        grip_width=GRIP_WIDTH,
        mount_offset=BronicaS2Bayonet.mount_protrusion,
        clearances=_element_clearances(e),
    )
    for e in _elements_data
)
THE_STOP = Stop(spacing=STOP_DEPTH, thk=STOP_THK, clr=STOP_CLR)


# Stepped lap joint between the two printed housing halves. Confined to
# z >= MOUNT_OFFSET (the lap_split z_min in `_splayed_halves` below), so
# it only runs through the flange-flange / funnel / upper sections — the
# thin-walled stepped lower segments below the flange get a clean halve
# only. The upper wall is thick enough (5 mm radial) to host the step
# internally with both layers >=2.5 mm thick everywhere; no external rib
# needed. `LAP_MID_RADIUS = 29.5` sits roughly midway between the upper-
# section bore (r ≈ 26.5, set by outer's ID continued upward) and the
# flange/funnel/upper OD (r ≈ 31–34, depending on element widths).
LAP_OVERLAP = 3.0
LAP_MID_RADIUS = 29.5
# Press-fit clearance between the lap-joint tongue and groove: shrinks
# the tongue (NOT the groove) at the tip and at the radial step face,
# so the parts seat with ~LAP_CLEARANCE mm of play in both directions
# instead of binding on a tight FDM print. Outer (visible) cylinder
# surface is unchanged so the joint flushes at the wall.
# Was 0.2 — that snap was too aggressive: the joint went together fine
# but cracked the wall on disassembly. Bumped to 0.4 since the lens-
# mount ring and hood handle alignment, the lap joint just needs to
# keep the halves indexed (light-tight + radial register, not load-
# bearing).
LAP_CLEARANCE = 0.4


class M57LensHousing(LensHousing):
    # Lower housing — three stepped segments sourced from the bayonet
    # spec. The M57 throat narrows in steps as the housing reaches deeper,
    # and each segment's OD matches one step. Outer is the flange-side
    # (widest, continues above the flange through the mount-ring zone);
    # mid carries the helicoid focus slot; inner is the deepest and
    # narrowest. Physical fit, not a design choice.
    lower_outer_od = BronicaS2Bayonet.lower_housing_outer_od
    lower_outer_len = BronicaS2Bayonet.lower_housing_outer_len
    lower_outer_thk = BronicaS2Bayonet.lower_housing_outer_thk
    lower_mid_od = BronicaS2Bayonet.lower_housing_mid_od
    lower_mid_len = BronicaS2Bayonet.lower_housing_mid_len
    lower_mid_thk = BronicaS2Bayonet.lower_housing_mid_thk
    lower_inner_od = BronicaS2Bayonet.lower_housing_inner_od
    lower_inner_len = BronicaS2Bayonet.lower_housing_inner_len
    lower_inner_thk = BronicaS2Bayonet.lower_housing_inner_thk
    # Upper section (flange-flange / funnel / upper) wall thickness: thick
    # enough to host the stepped lap joint internally (5 mm radial gives
    # 2.5/2.5 mm layers around mid_radius). The upper section sits outside
    # the camera body so its OD is unconstrained by the throat.
    upper_barrel_thk = 5.0   # radial wall (thick — hosts the lap joint internally)
    # Bore-side fillet ring angle at each interior step in the stacked
    # lower housing. 45° is the self-supporting threshold for FDM
    # overhangs printed lens-side-down (the slanted inner cone IS the
    # overhang surface). Steeper would print easier but consume more
    # axial extent inside the wider segment.
    bore_fillet_base_angle = 45.0
    # Alignment groove cross-section, sourced from the bayonet spec so
    # the housing's bottom-face groove and the lens-mount ring's outer-
    # wall groove match in profile.
    alignment_groove_depth = BronicaS2Bayonet.alignment_groove_depth
    alignment_groove_width = BronicaS2Bayonet.alignment_groove_width
    # The flange-flange is the wider band of the housing's wall (above the
    # lower segments) whose bottom rim rests on top of the lens-mount
    # ring. Set equal to the ring's OD (from the bayonet spec) so the
    # joint flushes at the seam.
    flange_flange_od = BronicaS2Bayonet.lens_mount_od
    flange_flange_len = 5.0
    fov_angle = FOV_ANGLE
    grip_depth = GRIP_DEPTH
    grip_width = GRIP_WIDTH
    mount_offset = BronicaS2Bayonet.mount_protrusion
    # Mating disc: bridges the radial gap between the outer segment and
    # the lens-mount ring's bore (from the bayonet spec). Disc OD = bore
    # − MATING_DISC_CLEARANCE (slip-fit, ~0.15 mm radial). Spans
    # z=[1.2, mount_offset] in the housing's world frame: the bottom is
    # 1.2 mm above the rotation channel's roof (the channel cavity tops
    # out at world z=0 = mount_offset − rest_z; that 1.2 mm of axial
    # clearance keeps the disc out of the channel and away from the
    # camera lugs that sit there when locked); the top flushes with the
    # lens-mount tube's top face at world z=mount_offset.
    mating_disc = MatingDisc(
        od=BronicaS2Bayonet.lens_mount_bore - MATING_DISC_CLEARANCE,
        z_bot=1.2, z_top=BronicaS2Bayonet.mount_protrusion,
    )
    # Tabs on the mating disc — shared module-level constant so the
    # locking lens-mount ring can import the same spec and cut matching
    # pockets in its bore wall.
    mating_disc_tabs = BRONICA_S2_MATING_DISC_TABS
    # Snap-fit retention bead — shared module-level constant so the
    # locking ring can cut the matching groove in its bore wall.
    mating_disc_bead = BRONICA_S2_MATING_DISC_BEAD
    # Helicoid focus slot: lives entirely within the mid segment. z_top
    # stays at -offset_from_flange (top of the slot, fixed by the camera-
    # body pin position). z_bot sits at the mid/inner step so the slot
    # never opens into the inner segment. The sweep portion extends CW
    # from the locked-side center by `lock_angle_deg` so the pin clears
    # at every angle as the lens rotates from insertion to locked.
    helicoid_focus_slot = HelicoidFocusSlot(
        angle=BronicaS2Bayonet.helicoid_focus_slot_angle,
        width=BronicaS2Bayonet.helicoid_focus_slot_width,
        depth=BronicaS2Bayonet.helicoid_focus_slot_depth,
        z_bot=-(BronicaS2Bayonet.lower_housing_outer_len
                + BronicaS2Bayonet.lower_housing_mid_len),
        z_top=-BronicaS2Bayonet.helicoid_focus_slot_offset_from_flange,
        sweep_arc_deg=BronicaS2Bayonet.lock_angle_deg,
        # 1 mm overshoot past z_bot — the slot's deep end sits exactly
        # on the mid/inner step plane, so the cutter pokes into the
        # inner-segment z-range (cutting no extra material since the
        # inner wall is at a much smaller radius) to drop the otherwise-
        # coplanar bottom face.
        bottom_overshoot=1.0,
    )
    # Aperture feeler slot: lives in the inner segment, directly opposite
    # the helicoid focus slot (3 o'clock vs the helicoid's 9). Same sweep
    # arc so the feeler clears at every angle during lens rotation. Axial
    # extent spans the entire inner segment — z_top at the mid/inner step
    # so the feeler doesn't catch on the slot's flange-side rim as the
    # lens slides in, z_bot at inner's deep end (the housing's deepest
    # point) with 1 mm overshoot past it so the slot opens cleanly off
    # the end of the throat rather than terminating on a coplanar bottom
    # face.
    aperture_feeler_slot = ApertureFeelerSlot(
        angle=BronicaS2Bayonet.aperture_feeler_slot_angle,
        width=BronicaS2Bayonet.aperture_feeler_slot_width,
        depth=BronicaS2Bayonet.aperture_feeler_slot_depth,
        z_top=-(BronicaS2Bayonet.lower_housing_outer_len
                + BronicaS2Bayonet.lower_housing_mid_len),
        z_bot=-(BronicaS2Bayonet.lower_housing_outer_len
                + BronicaS2Bayonet.lower_housing_mid_len
                + BronicaS2Bayonet.lower_housing_inner_len),
        sweep_arc_deg=BronicaS2Bayonet.lock_angle_deg,
        bottom_overshoot=1.0,
    )
    elements = ELEMENTS
    stop = THE_STOP


class M57LensHood(LensHood):
    wall_thk = 2.0
    hood_clr = 0.25
    hood_length = 20.0
    coupler_overlap = 6.0


# =============================================================================
# DESIGN: shared parts + variant methods
# =============================================================================


def _make_stop_discs(housing, hole_diameters):
    """One `WaterhouseStop` per hole diameter, all sharing the same
    barrel dimensions, thickness, and depth. Disc diameters are sourced
    from the housing at the stop's z, so the inner semicircle fills the
    local bore and the outer semicircle flushes with the local wall OD
    regardless of which section (lower / flange / funnel / upper) the
    stop sits in."""
    z = STOP_DEPTH
    return tuple(
        WaterhouseStop(
            inner_diameter=housing.wall_id_at_z(z),
            outer_diameter=housing.wall_od_at_z(z),
            thk=STOP_THK,
            hole_d=h,
            spacing=STOP_DEPTH,
        )
        for h in hole_diameters
    )


# Bambu X2D buildable area on the bed (mm). Layouts must fit within these.
BAMBU_X2D_PLATE = (256.0, 256.0)


class LensHousingDesign(Design):
    name = design_name    # output filename stem; from JSON or DEFAULT_DESIGN_NAME
    housing = M57LensHousing()
    # Dedicated housing instance for the `lower_housing_testfit` variant
    # that always includes ALL three lower segments (outer + mid + inner)
    # regardless of element/stop placement. The default `housing` trims
    # unused mid/inner segments; this one doesn't, so the printed test
    # piece exercises the full structural lower-housing geometry against
    # the camera's stepped throat.
    testfit_housing = M57LensHousing(force_all_lower_segments=True)
    hood = M57LensHood(
        housing_upper_od=housing.upper_housing_od,
        hood_base_angle=housing.hood_base_angle,
        label=FRONT_FILLET_LABEL,
    )
    stop_discs = _make_stop_discs(housing, STOP_HOLE_D)

    def _lap_split_halves(self):
        """The two housing halves, lap-jointed at X=0, engravings cut
        into the +X half — but NOT yet laid out for the bed. Returned
        as a (minus, plus) pair, each in the housing's native upright
        orientation (optical axis along +Z). Callers post-process for
        whichever bed layout they want (`_splayed_halves` adds
        `lap_splay`, `print_vertical` rotates lens-side-down).

        The lap is confined to z >= MOUNT_OFFSET (the thick-walled
        section above the mount ring); the thin-walled lower section
        below z=MOUNT_OFFSET gets a clean halve only.

        Each lap_split_x result is wrapped in `force_render()` so
        OpenSCAD computes the lap-jointed half once via CGAL on first
        compile and caches the resulting mesh; subsequent F5 frames
        (camera rotation in preview) draw the cached mesh instead of
        re-evaluating the deep CSG tree every frame.

        Engravings live OUTSIDE force_render: the bare structural half
        is what gets cached, and the engraving cutter (~42 glyph cuts)
        is differenced in via preview-CSG per frame. Without this split,
        every glyph difference ends up inside the CGAL evaluation and
        preview-open time balloons. The engravings sit on the +X half
        (angle=0 for both labels), so only the plus side needs the
        difference; the minus half goes through unmodified."""
        eng = self.housing.engravings()
        minus = self.housing.lap_split_x(
            side="minus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
            z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE,
        ).force_render()
        plus_bare = self.housing.lap_split_x(
            side="plus", overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
            z_min=MOUNT_OFFSET, clearance=LAP_CLEARANCE,
        )
        plus = difference(plus_bare.force_render(), eng).with_bbox_from(plus_bare)
        return minus, plus

    def _splayed_halves(self):
        """The two housing halves, lap-jointed at X=0 and laid flat for
        the bed (`lap_splay`). Returned as a (minus, plus) pair."""
        minus, plus = self._lap_split_halves()
        return (
            minus.lap_splay(side="minus", lap_overlap=LAP_OVERLAP),
            plus.lap_splay(side="plus", lap_overlap=LAP_OVERLAP),
        )


    @variant(fn=128, default=True)
    def print_vertical(self):
        # Both halves printed vertically (optical axis = print Z), lens-
        # side-down: the OD step at the flange is an inward step (no
        # overhang), the lap-joint features get first-layer accuracy at
        # the bed, and the wider lens-side face gives a generous bed-
        # contact area. Suited for the Bambu X2D's dual-head PETG-on-PLA
        # support workflow — element-gripper undersides print over PETG
        # and break off cleanly. Trades ~25% extra wall-clock vs the
        # horizontal `print` variant for smoother bore circumferential
        # finish and stronger resistance to bayonet-engagement torque.
        minus, plus = self._lap_split_halves()

        # Lens-side-down: rotate 180° about X (flips Y and Z, keeps X
        # so minus stays at world X<=0 and plus at world X>=0). The
        # lens-side face ends up below z=0; pack_on_bed below uses
        # tight_bbox to lift it back to the bed (LensHousing's
        # tight_bbox override gives the truncated fillet rim's true
        # z-extent, so the rim lands flush with z=0).
        minus_v = minus.rotate([180, 0, 0])
        plus_v = plus.rotate([180, 0, 0])

        gap = 12   # ~1.2cm clearance between objects

        # Place each half so its cut face sits at world X = ±gap/2. Lap
        # tongues extend at most LAP_OVERLAP - LAP_CLEARANCE past the cut
        # face, so the actual material gap between the two halves is
        # gap - 2*(LAP_OVERLAP - LAP_CLEARANCE) — comfortably non-zero
        # for any reasonable gap. pack_on_bed can't preserve this overlap
        # if the halves are passed in individually (it would space them
        # apart by `gap`), so the pair is bonded into one unit first and
        # then laid out alongside the stop disc.
        pair = union(minus_v.left(gap / 2), plus_v.right(gap / 2))

        # flat_stop = self.stop_discs[0].down(STOP_DEPTH - STOP_THK / 2)
        # return pack_on_bed(pair, flat_stop, gap=gap, plate=BAMBU_X2D_PLATE)
        return pack_on_bed(pair, gap=gap, plate=BAMBU_X2D_PLATE)

    @variant(fn=60)
    def print_vertical_preview(self):
        # Same geometry as `print_vertical`, rendered at lower fn for a
        # fast preview. SCAD-render only; not for slicing.
        return self.print_vertical()

    @variant(fn=48)
    def print_hood(self):
        # Hood by itself, flare-down on the bed (the wide flare gives
        # the largest bed-contact footprint and the coupler / fillet
        # detail prints upward without overhangs). The coupler's label
        # is baked into `LensHood.build()` (via `add_text` on the inner
        # Tube before assembly), so it travels with the hood through
        # the flip and lands oriented correctly on the print surface.
        return pack_on_bed(self.hood.rotate([180, 0, 0]), plate=BAMBU_X2D_PLATE)

    @variant(fn=48)
    def print_stops(self):
        # Two waterhouse stop discs, laid flat on the bed. Picks the
        # f/5.6 and f/11 hole sizes from the JSON's `hole_diameters`
        # list (indices 1 and 3 by construction — index 0 is widest).
        # Adjust the slice if the JSON list ordering changes.
        flat_stops = [
            self.stop_discs[i].down(STOP_DEPTH - STOP_THK / 2)
            for i in (0,2,3)  # f4, f8, f11
            #for i in (1, 3)
        ]
        return pack_on_bed(*flat_stops, gap=10, plate=BAMBU_X2D_PLATE)

    @variant(fn=60)
    def lower_housing_testfit(self):
        """One-piece truncated housing for trial-fitting against the
        camera throat. Strips the assembled housing down to the
        structural lower wall (outer + mid + inner segments + mating
        disc) plus the bottom 2 mm of the flange-flange rim, with the
        helicoid focus slot still cut. No element holders, no stop
        slot/holder/disc, no front fillet, no lap split — slip the
        printed result into the camera body to check stepped-OD
        clearance and helicoid-pin clearance without committing to a
        full housing print. Element data is irrelevant; defaults or
        any --from-json design produce the same geometry.

        Lens-side-down orientation (matches print_vertical): rotated
        180° about X so the truncated flange-flange rim (the widest
        cross-section) sits on the bed for solid adhesion. The throat
        extends upward; every OD step is inward in this orientation,
        so no support material is needed."""
        h = self.testfit_housing
        barrel = union(*h._sections())
        if h.helicoid_focus_slot is not None:
            barrel = difference(
                barrel,
                h._swept_slot_cutter(h.helicoid_focus_slot, h.lower_mid_od),
            )
        if h.aperture_feeler_slot is not None:
            barrel = difference(
                barrel,
                h._swept_slot_cutter(h.aperture_feeler_slot, h.lower_inner_od),
            )
        barrel = difference(barrel, h._alignment_groove_cutter())
        # Lock mechanism (tabs + bead) — present by default so the
        # testfit piece exercises the same disc geometry the production
        # housing presents to the locking lens-mount ring. Pass
        # `--no_locking_mech=1` to suppress both together (e.g. to test
        # pre-lock-mech fit, or isolate which feature is binding).
        if not NO_LOCKING_MECH:
            if h.mating_disc_tabs is not None and h.mating_disc is not None:
                barrel = union(barrel, h._mating_disc_tabs_geometry())
            if h.mating_disc_bead is not None and h.mating_disc is not None:
                barrel = union(barrel, h._mating_disc_bead_geometry())
        # Trim everything above the bottom 2 mm of the upper housing.
        # The slab spans z = [z_bot, z_top] generously past the housing's
        # vertical extent on the bottom side (overshoot is harmless;
        # intersection clips to the barrel).
        z_top = h.mount_offset + 2.0
        z_bot = -h.housing_insertion_depth - 1
        big = 200.0
        trimmer = cube([big, big, z_top - z_bot], center="xy").up(z_bot)
        trimmed = intersection(barrel, trimmer)
        # Lens-side-down: rotate so the rim faces the bed, then lift so
        # the (formerly top) trim plane lands at z=0.
        return trimmed.rotate([180, 0, 0]).up(z_top)

    @variant(fn=48)
    def design_spread_out(self):
        # Inspection layout: hood + the two distinct splayed halves
        # (showing the lap joint) + one stop disc per entry in
        # `STOP_HOLE_D`, all in a single +X row. Too large for the print
        # bed; use the `print` variant for actual printing — `assert_fit`
        # is disabled so this layout is allowed to overflow.
        minus, plus = self._splayed_halves()
        flipped_hood = self.hood.flip("z")   # wide flare on the print bed
        flat_stops = [
            disc.down(STOP_DEPTH - STOP_THK / 2) for disc in self.stop_discs
        ]
        gap = self.housing.upper_housing_od   # ~one barrel-diameter of breathing room

        return pack_on_bed(
            flipped_hood, minus, plus, *flat_stops,
            gap=gap, assert_fit=False,
        )

    @variant(fn=48)
    def display(self):
        # Lift the hood one coupler_overlap above the true housing top (which
        # sits above upper_housing_len because of the front fillet ring) so
        # the housing's upper rim is visible between the two parts. The
        # widest-aperture stop disc shows fully inserted at its real depth.
        housing_top_z = self.housing.bbox.max[2]
        gap = self.hood.coupler_overlap
        return union(
            difference(self.housing, self.housing.engravings()),
            self.hood.up(housing_top_z + gap),
            self.stop_discs[0],
        )

    @variant(fn=48)
    def element_grippers(self):
        # Per-element diagnostic half-grippers for test-fitting individual
        # elements without printing a full housing. Each gripper is the
        # same three-tube stack as ElementHolder (rim / middle / rim) with
        # rim and middle inner diameters and axial extents matched to the
        # housing exactly — a successful fit here predicts a fit in the
        # real part. Outer wall is a uniform 2 mm-walled cylinder per
        # gripper (sized off the middle tube; rim tubes come out thicker).
        # Halved at X=0 keeping +X so each gripper prints as a half-shell
        # with the element code engraved on its outer apex (the anchor
        # sits at +X, so engravings stay on the kept half). Standing up
        # along Z; pack_on_bed lays them along +X in elements-tuple order.
        halves = []
        for e in self.housing.elements:
            g = ElementTestGripper(
                element=e,
                grip_depth=GRIP_DEPTH,
                grip_width=GRIP_WIDTH,
                wall_thk=2.0,
            )
            cutter = g.text_geometry(
                label=e.code, on="outer_wall", angle=0,
                font_size=2.5, relief=-0.4,
            )
            # with_bbox_from(g): difference()'s bbox can't be tightened
            # without CSG evaluation, but the engraving only removes
            # material from the gripper's outer face, so the true bbox
            # is the gripper's. Without this, halve()'s Intersection
            # bbox can't be clipped and pack_on_bed below errors out.
            engraved = difference(g, cutter).with_bbox_from(g)
            halves.append(engraved.halve([1, 0, 0]))
        return pack_on_bed(*halves, gap=10, plate=BAMBU_X2D_PLATE)

    @variant(fn=48)
    def testing(self):
        # One splayed half (the -X half, with lap-joint features visible)
        # for inspecting a single shell in isolation.
        minus, _ = self._splayed_halves()
        minus_bb = minus.bbox
        gap = self.housing.upper_housing_od
        return minus.left(minus_bb.max[0] + gap / 2)


if __name__ == "__main__":
    run()
