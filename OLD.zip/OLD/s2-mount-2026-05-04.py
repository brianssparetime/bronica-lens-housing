"""Bronica S2 lens-mount components.

Two mating bayonet parts:
- `CameraMount` — open tube with three outward-projecting lugs at the
  top rim, matching the actual Bronica S/S2/S2A/EC/EC-TL camera-side
  bayonet pattern (one large lug ~50° wide + two smaller ~40° lugs at
  roughly 120° spacing).
- `LensMount` — the lens-side mating part, built by subtracting the
  swept volume of the camera mount (pressed in then twisted left) from
  a thick tube.

Run:
    python s2-evolving/s2-mount.py
"""

import math

from scadwright import Component, bbox
from scadwright.boolops import difference, union
from scadwright.design import Design, run, variant
from scadwright.primitives import circle, cube, polygon, polyhedron, square
from scadwright.shapes import Arc, Tube


# Bambu X2D buildable area (mm). Layouts must fit within these.
BAMBU_X2D_PLATE_X = 256
BAMBU_X2D_PLATE_Y = 256


class CameraMount(Component):
    """Open tube with a per-lug list of outward-projecting bayonet lugs
    at the top rim.

    `barrel_id` / `wall_thk` / `length` define the open cylindrical body
    (`barrel_od = barrel_id + 2 * wall_thk` is computed). `lug_axial` is
    the axial thickness of each lug; `lugs` is a tuple of
    `(center_deg, width_deg, radial_proj_mm)` triples, one per lug, so
    the bayonet pattern can be asymmetric.
    """

    equations = """
        barrel_id, length, wall_thk, lug_axial > 0
        barrel_od = barrel_id + 2 * wall_thk
        body_or = barrel_od / 2
        lug_axial <= length
        len(lugs:tuple) >= 1
    """

    def build(self):                                       # framework hook: required; returns the shape
        yield Tube(h=self.length, od=self.barrel_od, id=self.barrel_id)
        z_lug_bottom = self.length - self.lug_axial
        # Each lug: an annular sector (Arc) extruded vertically, rotated
        # to its center angle, lifted to the top of the barrel.
        for center_deg, width_deg, proj_mm in self.lugs:
            half = width_deg / 2
            yield (
                Arc(
                    r=self.body_or + proj_mm / 2,
                    width=proj_mm,
                    angles=(center_deg - half, center_deg + half),
                )
                .linear_extrude(height=self.lug_axial)
                .up(z_lug_bottom)
            )


class BronicaS2CameraMount(CameraMount):
    """Concrete mount sized to the Bronica S/S2/EC camera mount.

    Body OD/ID/wall come from the rear-cap STL (60.5 / 56.5 / 2 mm); the
    barrel ID also matches the M57 thread behind the bayonet. The three
    lugs are taken from a flatbed scan of the actual camera mount: one
    larger lug plus two smaller, with center spacing ~120° but a slight
    asymmetry between the small ones. Centers in camera coords: 0° = +X,
    90° = +Y = up toward the BRONICA logo. Widths shrunk 1° from
    measured (undersized lugs still mate, oversized jam).
    """
    barrel_id = 56.5
    wall_thk = 2.0
    length = 20.0
    lug_axial = 1.2   # measured ~1.1 on the camera lug; +0.1 after a test print showed the channel too tight
    lugs = (
        (90.0, 49.0, 1.8),    # large (measured 50°, scan 49.5°)
        (214.75, 39.0, 1.2),  # small (measured 40°, scan 174.25°)
        (324.25, 40.5, 1.2),  # small (measured 41.5°, scan 283.75°)
    )


class LensMount(Component):
    """Lens-side mating part for a `CameraMount`.

    Coordinate convention: z=0 is the bottom face of the tube, z=h is
    the top face — the ENTRY RIM, the side the camera mount is pressed
    into. When fully inserted and rotated, the camera mount's lug-front
    plane sits at z = h - `insertion_depth` (the "rest plane").

    The cutter is the union of three pieces:

    1. BORE cutter (full tube height): a clearance-offset cylinder of
       `cam_barrel_od`. Lets the camera mount's body pass through the
       entire lens mount.
    2. ENTRY LUG CHANNELS (only `insertion_depth` tall, top of tube):
       lug-width arcs at the original lug angles, from the rest plane
       up to the entry rim. Each lug slides down its channel during
       press-in.
    3. ROTATION CHANNEL (only `lug_axial` tall, at the rest plane):
       lug arcs widened by `lock_angle_deg` on the CCW ("left") edge.
       The lug rotates through this channel after entry.

    Material between the rotation channel and the entry rim, at the
    swept angles outside the entry channels, is the bayonet lip —
    it catches each lug after the twist and prevents the mount from
    pulling back out. `clearance` is applied via 2D `offset` around
    each profile.

    Tube blank:
    - OD = `cam_barrel_od + 2*max_lug_proj + 2*wall_thk`
      (i.e. `wall_thk` of wall outside the circle around the lugs)
    - ID = `cam_barrel_id - 2`
    - h  = `h`
    """

    equations = """
        cam_barrel_od, cam_barrel_id, clearance, lock_angle_deg, lug_axial, wall_thk, insertion_depth, protrusion_len, entry_arc_clearance, axial_clearance > 0
        cam_barrel_od > cam_barrel_id
        lug_axial < insertion_depth
        h = protrusion_len + insertion_depth
        max_lug_proj = max(p for c, w, p in lugs:tuple)
        outer_od = cam_barrel_od + 2 * max_lug_proj + 2 * wall_thk
        inner_id = cam_barrel_id - 2 * wall_thk
        body_or = cam_barrel_od / 2
        outer_or = outer_od / 2
        rest_z = h - insertion_depth
        # Alignment groove: thin axial recess on the outer wall, centered
        # on the widest lug's center angle.
        groove_depth, groove_width > 0
        widest_w = max(lw for lc, lw, lp in lugs)
        widest_center = [lc for lc, lw, lp in lugs if lw == widest_w][0]
        # Groove ends up at the widest lug's world angle (the BRONICA
        # logo direction) after the lens rotates +lock_angle_deg in
        # camera coords into its locked position; in lens-coords the
        # groove therefore starts at widest_center - lock_angle_deg.
        groove_angle_deg = widest_center - lock_angle_deg
        # Optional inner-tube feature (always computed; only emitted
        # when self.inner_tube is True). `?inner_tube` defaults to False
        # via the override pattern when the caller doesn't supply it.
        ?inner_tube:bool = False if ?inner_tube is None else ?inner_tube
        inner_tube_od = cam_barrel_id - clearance
        inner_tube_id = inner_tube_od - 2 * inner_tube_wall_thk
        inner_tube_h = rest_z + inner_tube_above_flange
        connector_od = cam_barrel_od + 2 * clearance
        inner_tube_id > 0
    """

    def build(self):
        blank = Tube(h=self.h, od=self.outer_od, id=self.inner_id)

        # 1. BORE: clearance-offset cylinder through the entire tube.
        bore_2d = circle(d=self.cam_barrel_od).offset(r=self.clearance)
        bore_cutter = bore_2d.linear_extrude(height=self.h + 1.0).down(0.5)

        # 2. ENTRY LUG CHANNELS: lug-width arcs at original lug angles,
        # from the rest plane to just past the entry rim. Each entry
        # channel is widened tangentially by `entry_arc_clearance` mm
        # of arc length on EACH side (converted per-lug to degrees by
        # the lug's mid-radius); this only affects the entry channels,
        # not the rotation channels, so the locked fit stays tight while
        # the initial drop-in is forgiving.
        entry_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(
                    c - w / 2 - math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                    c + w / 2 + math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                ),
            )
            for c, w, p in self.lugs
        ]
        entry_lug_2d = union(*entry_arcs).offset(r=self.clearance)
        entry_lug_cutter = (
            entry_lug_2d
            .linear_extrude(height=self.insertion_depth + 0.5)
            .up(self.rest_z)
        )

        # 3. ROTATION CHANNEL: lug arcs widened by lock_angle_deg on
        # the CW edge, lug_axial tall (+ clearance above for fit).
        # The lug front face rests on the bottom of this channel. The
        # CW-edge widening means the LENS rotates CCW in camera coords
        # (CW from the viewer's perspective looking at the camera front)
        # to bring the indicator from its insertion angle (~10:30) into
        # the locked position at 12 o'clock.
        rot_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(c - w / 2 - self.lock_angle_deg, c + w / 2),
            )
            for c, w, p in self.lugs
        ]
        rot_2d = union(*rot_arcs).offset(r=self.clearance)
        rot_cutter = (
            rot_2d
            .linear_extrude(height=self.lug_axial + self.axial_clearance)
            .up(self.rest_z)
        )

        # 4. ALIGNMENT GROOVE: long skinny triangular prism on the outer
        # wall, apex pointing inward, base on the outer surface,
        # extruded the full tube height. Placed so that AFTER the lens
        # rotates into its locked position, the groove ends up aligned
        # with the widest lug's world angle (toward the BRONICA logo).
        groove_2d = polygon(points=[
            (self.outer_or - self.groove_depth, 0.0),       # apex (inward)
            (self.outer_or + 0.1, self.groove_width / 2),    # base +Y (slight overshoot)
            (self.outer_or + 0.1, -self.groove_width / 2),   # base -Y
        ])
        groove_cutter = (
            groove_2d
            .linear_extrude(height=self.h + 1.0)
            .down(0.5)
            .rotate([0, 0, self.groove_angle_deg])
        )

        yield difference(
            blank,
            union(bore_cutter, entry_lug_cutter, rot_cutter, groove_cutter),
        )

        if self.inner_tube:
            # Inner tube: fits inside the camera-mount throat; extends
            # from z=0 (bottom of the outer tube) up past the flange by
            # `inner_tube_above_flange`.
            yield Tube(
                h=self.inner_tube_h,
                od=self.inner_tube_od,
                id=self.inner_tube_id,
            )
            # Connector annulus: bridges the radial gap between the
            # inner tube and the outer tube, from z=0 to the flange.
            yield Tube(
                h=self.rest_z,
                od=self.connector_od,
                id=self.inner_tube_od,
            )


class BronicaS2LensMount(LensMount):
    """Concrete lens mount: lens-specific dimensions. The bayonet
    spec (cam_barrel_od, cam_barrel_id, lugs) is supplied at
    instantiation by reading them off the paired CameraMount instance.
    """

    clearance = 0.20
    # Extra arc-length added to each side of the ENTRY channels (only)
    # so the lugs drop in without fiddling. Rotation channels stay tight.
    entry_arc_clearance = 1.0
    # Axial slop in the rotation channel (channel z-height = lug_axial +
    # axial_clearance). Tightens lens-to-camera wobble independently of
    # the radial `clearance`.
    axial_clearance = 0.1
    wall_thk = 2.0
    # Measured by two test fits:
    #   1. With lock_angle_deg=45, the printed indicator at MATING (before
    #      rotation) sat ~7.5 mm CW (viewer frame) of where it should be
    #      relative to the BRONICA logo. Wanted to push the mating-position
    #      mark CCW.
    #   2. First correction lowered lock_angle_deg to 32.4 (the wrong way),
    #      which moved the mating mark CW instead of CCW; on the next test
    #      print it ended up about twice as far in that wrong direction.
    # Net: undo that wrong move AND apply the originally-intended one in
    # the right direction. 7.5 mm at outer_or = 34.05 mm is ~12.6°, so
    # lock_angle_deg = 45 + 12.6 = 57.6. This elongates the rotation
    # channel by 12.6° vs. the original (and 25.2° vs. the wrong-way fix),
    # and (via groove_angle_deg = widest_center - lock_angle_deg) shifts
    # the printed groove CCW in viewer frame so it lands at 12 o'clock
    # when locked.
    lock_angle_deg = 57.6
    # When fully inserted and rotated, the camera-mount lug-front plane
    # sits insertion_depth mm below the entry rim.  This needs to be sufficiently
    # short so that the tube's rim doesn't impinge on teh camera's face
    # when focused to infinity.   4 was very close, but not quite short enough.
    insertion_depth = 3.5
    protrusion_len = 5
    # Inner-tube feature: off by default via the base's override pattern;
    # set `inner_tube=True` at the call site to enable. Sizing values
    # below are used only when emitted.
    inner_tube_wall_thk = 2.0
    inner_tube_above_flange = 16.0
    # Alignment groove on the outer wall, at the widest lug's center.
    groove_depth = 0.3
    groove_width = 0.5
    # No part of the mount may extend more than this distance radially past
    # the OD wall — beyond it the feature collides with the focus collar on
    # the Bronica helicoid (effectively part of the camera body). Measured
    # from the lens-mount tube's outer wall to the inner wall of the focus
    # collar's bore. Any latch / tab / catch must respect this bound.
    max_radial_extension = 9.0


class LensMountLocking(LensMount):
    """`LensMount` plus an integral tangentially-rocking flex-tab latch.

    Vocabulary (used throughout this class):
      - TOOTH      : the wedge that descends through a pocket in the OD wall
                     into the rotation channel and impinges the lug.
      - LEVER ARM (C): the curved rigid body running tangentially along the OD,
                     connecting the flex pivot at one end to the tab at the
                     other; carries the tooth somewhere along its length.
      - PIVOT (flex zone): the thin annular sector at the LEVER ARM's CW end
                     anchoring it to the OD wall; bends to let the lever rock.
      - TAB (B)    : the user-actuated lug at the LEVER ARM's CCW end. Sticks
                     OUT radially from the lever arm so the user can grab it
                     and pull radially outward to retract the tooth.
      - FINGER CATCH (A): a small overhang at the TAB's outer-radial end,
                     extending tangentially (away from the tooth), giving the
                     fingertip something to hook on for pulling.

    Mechanism: the PIVOT sits on the entry-notch side of the TOOTH (HIGHER
    theta in lens-frame), the LEVER ARM extends CCW (in the lock-rotation
    direction) past the TOOTH, and the TAB is at the LEVER ARM's far CCW end.
    The lug's unmount push on the TOOTH's CCW face creates a moment about the
    PIVOT that drives the TOOTH radially INWARD (jams). The user's outward
    pull on the TAB creates the opposite moment → TOOTH retracts.

    The TOOTH is a chisel: ONE ramp on its CCW face (the side facing the
    entrance channel, where the lug approaches from during lock rotation). The
    ramp is sloped in the radial direction so the OUTER (lever-arm side) of the
    face is at full CCW extent and the INNER (deep-in-channel side) is pulled
    toward CW. Lug pushing this slope tangentially during lock rotation gets
    redirected with a radial-OUTWARD component on the tooth, plus the residual
    tangential force creates a CCW moment about the PIVOT — body rotates, tooth
    retracts, lug clears. The CW face (lock-side) stays vertical so the lug's
    unmount push hits a flat wall and creates a CW moment about the pivot,
    driving the tooth radially INWARD (jams).

    Note: the TOOTH does not interact with the lug during axial insertion. The
    tooth's angular position (just CW of the locked lug) is OUTSIDE the lug's
    initial angular range (the entry-notch arc), so the lug descends past the
    tooth without touching it. Tooth-lug contact only happens during the
    rotational phase.
    """

    # PIVOT (flex zone) dimensions and LEVER ARM CLEARANCE
    # The LEVER ARM is offset radially OUTWARD from the OD wall by lever_clearance,
    # so the slicer doesn't fuse them and so the lever arm can rock freely. The
    # FLEX zone fills this radial gap at the pivot azimuth — that single bridge
    # is the ONLY connection between the LEVER ARM and the OD.
    lever_clearance = 0.6     # radial gap between OD and LEVER ARM (mm) — must be
                              # ≥ ~0.5 mm so the slicer doesn't bridge the gap with
                              # a single perimeter and fuse them
    flex_arc_deg = 6.0        # angular extent of the flex zone (deg). This is
                              # the bending dimension of the pivot hinge —
                              # wider here means a stiffer pivot, less likely
                              # to over-flex and yield under repeated tab
                              # presses.
    # LEVER ARM (C) dimensions
    body_thk = 1.2            # radial thickness of the lever arm (mm)
    body_arc_deg = 18.0       # angular extent of lever arm from pivot to tab (deg)
    body_axial = 4.5          # axial height of the lever arm and tooth slab (mm)
    # TOOTH dimensions
    tooth_angular_width_deg = 5.0
    tooth_clearance_from_lug_deg = 0.5
    tooth_radial_depth = 4.1  # tooth projects this far INWARD from the lever arm's
                              # inner face (lever_inner_r). Sized to block ~75-80%
                              # of the rotation channel's radial depth — at the S2
                              # default this puts the tooth's inner face ~0.1 mm
                              # outboard of the camera-barrel clearance bore, so
                              # the tooth doesn't foul the camera barrel.
    tooth_ramp_deg = 35.0     # angle of the CCW-face ramp from vertical: how
                              # much the inner edge of the CCW face is pulled
                              # toward CW (small angle = nearly vertical face,
                              # large angle = strongly inclined face)
    tooth_axial_clearance = 0.3  # axial gap between the tooth and the channel
                              # walls on EACH side (top and bottom). At 0.3 mm
                              # the slicer can fit at least one PETG support
                              # layer above and below the tooth, preventing
                              # fusion with the tube during print and giving
                              # the tooth room to print supported.
    # TAB (B) dimensions — TAB is a flat radial paddle extending RADIALLY OUTWARD
    # from the lever arm's CCW endcap. It abuts the lever arm's CCW endcap face
    # (which is a tangential face) over the full axial × radial extent of the lever
    # arm; axial dimension matches body_axial. Long dimension is RADIAL; thin in
    # the tangential direction. Sized to stay within `max_radial_extension` past
    # the OD when combined with the FINGER CATCH (checked at construction).
    tab_radial_extent = 4.0    # how far the tab sticks out beyond the OD wall (mm)
    tab_tangential_width = 1.5 # thin tangential dimension (mm)
    # FINGER CATCH (A) dimensions — small overhang at the TAB's outer-radial end,
    # extending TANGENTIALLY (along the OD's tangent, away from the tooth) so the
    # user's fingertip has something to hook against. Same axial height as the
    # TAB and lever arm. Sized to stay within `max_radial_extension` past the OD
    # at its outer-tangential corner (checked at construction).
    finger_catch_extent = 2.5  # how far the catch extends tangentially past the TAB (mm)
    finger_catch_thk = 1.5    # radial thickness of the catch (mm)

    def _tooth_and_pivot_angles(self):
        """Compute (tooth_center_deg, pivot_center_deg) in lens-frame.

        The tooth sits inside the largest lug's ENTRANCE CHANNEL (not the
        rotation channel). Anchor: the lug's MATING-position CW edge — i.e.
        the tangential boundary between the rotation channel (CW of it) and
        the entry channel (CCW of it). The tooth's CW face is offset CCW from
        that edge by `tooth_clearance_from_lug_deg`, so the tooth lives just
        inside the entry channel. After full lock rotation the lug has swept
        out of the entry channel and the tooth, released, drops into the
        empty notch. To unmount, the operator pushes the tab to retract the
        tooth before rotating CCW.
        """
        widest_w = max(w for c, w, p in self.lugs)
        widest_center = next(c for c, w, p in self.lugs if w == widest_w)
        lug_mating_cw_edge_lens_deg = widest_center - widest_w / 2
        tooth_center_deg = (
            lug_mating_cw_edge_lens_deg
            + self.tooth_clearance_from_lug_deg
            + self.tooth_angular_width_deg / 2
        )
        pivot_offset_deg = self.body_arc_deg - self.tooth_angular_width_deg / 2
        pivot_center_deg = tooth_center_deg + pivot_offset_deg
        return tooth_center_deg, pivot_center_deg

    def build(self):
        # Constraint: latch's furthest-from-axis point (the FINGER CATCH outer-
        # tangential corner) must stay within `max_radial_extension` past the OD,
        # else it hits the focus collar on the Bronica helicoid. Checked at
        # construction so we get a clear error before any geometry is built.
        # `max_radial_extension` is inherited from the concrete subclass (e.g.
        # BronicaS2LensMount); skip the check if it isn't set.
        max_radial_ext = getattr(self, "max_radial_extension", None)
        if max_radial_ext is not None:
            corner_x = self.outer_or + self.lever_clearance + self.tab_radial_extent
            corner_y = self.tab_tangential_width + self.finger_catch_extent
            corner_radius = math.sqrt(corner_x ** 2 + corner_y ** 2)
            max_allowed_radius = self.outer_or + max_radial_ext
            if corner_radius > max_allowed_radius:
                raise ValueError(
                    f"latch corner reaches radius {corner_radius:.2f} mm, "
                    f"exceeds max allowed {max_allowed_radius:.2f} mm "
                    f"(OD {self.outer_or:.2f} + max_radial_extension "
                    f"{max_radial_ext:.2f}); reduce tab_radial_extent "
                    f"({self.tab_radial_extent}) and/or finger_catch_extent "
                    f"({self.finger_catch_extent})"
                )

        # Tooth placement: at the LEVER ARM's CCW endcap (under the TAB), with
        # the tooth's CCW edge aligned with the lever arm's CCW endcap so the
        # tooth is fully covered by the lever arm. This puts the tooth at the
        # FAR end of the lever arm from the pivot — maximizing the lever ratio
        # so a small pivot bend gives the largest tooth retraction (minimizes
        # required pivot travel, which is the weakest part of the design).
        # Pivot is on the entry-notch side of the tooth (HIGHER theta). Lever
        # arm extends CCW (toward LOWER theta, the lock direction). TAB is at
        # the CCW end of the lever arm.
        tooth_center_deg, pivot_center_deg = self._tooth_and_pivot_angles()
        grip_center_deg = pivot_center_deg - self.body_arc_deg

        # Pocket through the OD wall at tooth's angular position. Pocket has
        # angular clearance on both sides of the tooth so the tooth can swing
        # through it during release without hitting uncut OD material.
        pocket_angular_width = self.tooth_angular_width_deg + 4.0
        max_lug_proj_local = max(p for c, w, p in self.lugs)
        pocket_radial_depth = self.outer_or - (self.body_or + max_lug_proj_local / 2 + self.clearance)
        pocket_arc = Arc(
            r=self.outer_or - pocket_radial_depth / 2,
            width=pocket_radial_depth + 0.2,
            angles=(
                tooth_center_deg - pocket_angular_width / 2,
                tooth_center_deg + pocket_angular_width / 2,
            ),
        )
        pocket_cutter = (
            pocket_arc
            .linear_extrude(height=self.lug_axial + self.axial_clearance + 0.4)
            .up(self.rest_z - 0.2)
        )

        # Same cutters as base LensMount.
        blank = Tube(h=self.h, od=self.outer_od, id=self.inner_id)
        bore_2d = circle(d=self.cam_barrel_od).offset(r=self.clearance)
        bore_cutter = bore_2d.linear_extrude(height=self.h + 1.0).down(0.5)

        entry_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(
                    c - w / 2 - math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                    c + w / 2 + math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                ),
            )
            for c, w, p in self.lugs
        ]
        entry_lug_cutter = (
            union(*entry_arcs).offset(r=self.clearance)
            .linear_extrude(height=self.insertion_depth + 0.5)
            .up(self.rest_z)
        )

        rot_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(c - w / 2 - self.lock_angle_deg, c + w / 2),
            )
            for c, w, p in self.lugs
        ]
        rot_cutter = (
            union(*rot_arcs).offset(r=self.clearance)
            .linear_extrude(height=self.lug_axial + self.axial_clearance)
            .up(self.rest_z)
        )

        groove_2d = polygon(points=[
            (self.outer_or - self.groove_depth, 0.0),
            (self.outer_or + 0.1, self.groove_width / 2),
            (self.outer_or + 0.1, -self.groove_width / 2),
        ])
        groove_cutter = (
            groove_2d.linear_extrude(height=self.h + 1.0).down(0.5)
            .rotate([0, 0, self.groove_angle_deg])
        )

        yield difference(
            blank,
            union(bore_cutter, entry_lug_cutter, rot_cutter, groove_cutter, pocket_cutter),
        )

        # Latch: build with the pivot at azimuth=0 (along +X), body extending
        # in the −Y direction (which becomes CCW in lens-frame after rotation
        # to pivot_center_deg). Then rotate the assembly to pivot_center_deg.
        yield self._build_latch(tooth_center_deg, pivot_center_deg).rotate(
            [0, 0, pivot_center_deg]
        )

        # Inner-tube feature, identical to base.
        if self.inner_tube:
            yield Tube(h=self.inner_tube_h, od=self.inner_tube_od, id=self.inner_tube_id)
            yield Tube(h=self.rest_z, od=self.connector_od, id=self.inner_tube_od)

    def _build_latch(self, tooth_center_deg, pivot_center_deg):
        # Latch-local frame: PIVOT at azimuth=0 (along +X), at the very CW end of
        # the LEVER ARM. LEVER ARM extends from the pivot in the −azimuth direction
        # (CCW = lock direction in user/operator view) to the TAB at azimuth=
        # −body_arc_deg. Nothing extends past the pivot in the CW direction (so
        # the lever arm can't block its own motion).
        #
        # The LEVER ARM is OFFSET radially outward from the OD by lever_clearance,
        # leaving a clearance GAP that prevents the slicer from fusing them and lets
        # the lever rock freely. The FLEX zone is the ONLY connection between the
        # LEVER ARM and the OD: it sits in the gap at the pivot azimuth, anchored
        # to the OD on its inner face and to the LEVER ARM on its outer face.
        z_bot = self.rest_z - (self.body_axial - self.lug_axial) / 2
        tooth_local_az = tooth_center_deg - pivot_center_deg
        tooth_arc_mm_at_outer = (
            self.tooth_angular_width_deg * math.pi / 180.0 * self.outer_or
        )

        # Lever-arm radial range — offset outward from OD by lever_clearance.
        lever_inner_r = self.outer_or + self.lever_clearance
        lever_outer_r = lever_inner_r + self.body_thk

        # PIVOT (FLEX zone) — bridges the radial gap. Inner face overlaps
        # INTO the OD wall by `fuse_eps` (so the union with the lens-mount
        # blank merges into one connected manifold, not face-touching pieces).
        # Outer face overlaps slightly into the LEVER ARM. Tangentially extends
        # from a small overlap (-flex_overlap_deg) into the LEVER ARM's CW end,
        # out to +flex_arc_deg in the CW direction past the pivot.
        fuse_eps = 0.1  # volume-overlap epsilon for clean STL unions
        flex_overlap_deg = 0.5
        flex_radial_overlap = 0.2
        flex_inner_r = self.outer_or - fuse_eps                    # extends INTO OD wall
        flex_outer_r = self.outer_or + self.lever_clearance + flex_radial_overlap
        flex = (
            Arc(
                r=(flex_inner_r + flex_outer_r) / 2,
                width=flex_outer_r - flex_inner_r,
                angles=(-flex_overlap_deg, self.flex_arc_deg),
            )
            .linear_extrude(height=self.body_axial)
            .up(z_bot)
        )

        # LEVER ARM (C) — curved rigid annular sector OFFSET from the OD by
        # lever_clearance. Tangentially from -body_arc_deg (TAB end) to 0 (PIVOT
        # end). Pivot is at the very CW end of the lever arm.
        body = (
            Arc(
                r=lever_inner_r + self.body_thk / 2,
                width=self.body_thk,
                angles=(-self.body_arc_deg, 0),
            )
            .linear_extrude(height=self.body_axial)
            .up(z_bot)
        )

        # TOOTH — chisel polyhedron, built at +X axis (azimuth=0) then rotated
        # by tooth_local_az into position.
        #
        # Build-frame ↔ lens-frame mapping (after rotation by tooth_local_az,
        # which is NEGATIVE since the tooth is at lower theta than the pivot):
        #   +Y in build frame  →  HIGHER azimuth in latch-local  →  CCW direction
        #                          at the tooth in lens-frame  →  ENTRANCE-CHANNEL side
        #   -Y in build frame  →  LOWER azimuth in latch-local  →  CW direction
        #                          at the tooth in lens-frame  →  LOCK-direction side
        #
        # Faces:
        #   CCW face (+Y, ENTRANCE side): RAMPED. Outer (high-x) edge stays at
        #     full +Y (= +tooth_arc/2). Inner (low-x) edge is pulled toward CW
        #     (smaller +Y) by tooth_radial_depth × tan(tooth_ramp_deg). Lug
        #     approaches this face from +Y during lock rotation; the slope
        #     redirects the lug's tangential push into a radial OUTWARD force on
        #     the tooth, which (combined with the residual tangential moment
        #     about the pivot) retracts the tooth.
        #   CW face (-Y, LOCK side): VERTICAL at -tooth_arc/2. Lug pushing this
        #     face during unmount creates a CW moment about the pivot → tooth
        #     drives radially INWARD = jams = blocks.
        #   Top (+Z) and bottom (-Z): flat, both at constant z.
        #   Inner (-X) and outer (+X): vertical, at x_inner and x_outer.
        #
        # Tooth attaches to the LEVER ARM at its outer radial face. x_outer
        # extends `fuse_eps` INTO the lever arm so the union creates a real
        # volume overlap (not a face-touch) — required for the STL to be a
        # single connected manifold.
        x_outer = lever_inner_r + fuse_eps
        x_inner = lever_inner_r - self.tooth_radial_depth
        y_cw = -tooth_arc_mm_at_outer / 2  # CW (lock-side) face: vertical
        y_ccw_outer = +tooth_arc_mm_at_outer / 2  # CCW face outer edge: full +Y
        ramp_drop = self.tooth_radial_depth * math.tan(
            math.radians(self.tooth_ramp_deg)
        )
        y_ccw_inner = max(y_ccw_outer - ramp_drop, y_cw + 0.1)  # clamp so tooth stays nondegenerate at inner radius
        # Tooth's axial range is INSET from the rotation channel by tooth_axial_clearance
        # on both sides. The rotation channel runs from rest_z to rest_z + lug_axial +
        # axial_clearance; the tooth sits centered between the lug's axial range
        # (rest_z .. rest_z + lug_axial) with clearance gaps above and below for
        # support material and to keep the tooth from fusing with the tube during
        # printing.
        # NOTE: use distinct variable names — z_bot is the lever-arm bottom defined
        # earlier; tooth_z_lo/hi are the tooth's own axial extent.
        tooth_z_lo = self.rest_z + self.tooth_axial_clearance
        tooth_z_hi = self.rest_z + self.lug_axial - self.tooth_axial_clearance
        verts = [
            (x_inner, y_cw,        tooth_z_lo),    # 0
            (x_outer, y_cw,        tooth_z_lo),    # 1
            (x_outer, y_ccw_outer, tooth_z_lo),    # 2
            (x_inner, y_ccw_inner, tooth_z_lo),    # 3
            (x_inner, y_cw,        tooth_z_hi),    # 4
            (x_outer, y_cw,        tooth_z_hi),    # 5
            (x_outer, y_ccw_outer, tooth_z_hi),    # 6
            (x_inner, y_ccw_inner, tooth_z_hi),    # 7
        ]
        faces = [
            [0, 3, 2, 1],     # bottom (-Z, trapezoidal due to ramp)
            [4, 5, 6, 7],     # top (+Z, trapezoidal, flat)
            [0, 1, 5, 4],     # CW face (-Y, vertical) — blocks unmount
            [2, 3, 7, 6],     # CCW face (+Y, RAMPED) — entrance side, lug retracts tooth via this slope
            [1, 2, 6, 5],     # outer face (+X)
            [0, 4, 7, 3],     # inner face (-X)
        ]
        tooth = polyhedron(points=verts, faces=faces, convexity=2).rotate(
            [0, 0, tooth_local_az]
        )

        # TAB (B) — flat radial PADDLE extending RADIALLY OUTWARD from the LEVER
        # ARM's CCW endcap. Built at +X axis (azimuth=0 in build-tab frame),
        # then rotated to azimuth=-body_arc_deg.
        #
        # TAB orientation: long dimension RADIAL (tab_radial_extent), middle
        # dimension AXIAL (matches body_axial — the lever arm's height along the
        # tube axis), thin dimension TANGENTIAL (tab_tangential_width).
        #
        # ABUTMENT: the TAB's +Y face (the tangential face on the LEVER-ARM side)
        # sits flush at Y=0, against the LEVER ARM's CCW endcap face (which lies
        # at azimuth=0 in build-tab frame, i.e. Y=0 plane). Over the full axial
        # × radial extent of the LEVER ARM endcap, the two faces coincide. TAB's
        # tangential range is therefore [-tab_tangential_width, 0]; its inner
        # radial face starts at lever_inner_r (the LEVER ARM's inner face), so
        # the abutment covers the lever arm's full radial wall.
        # +Y dimension extended by `fuse_eps` so the TAB overlaps the LEVER ARM
        # by a small VOLUME (not just a shared face). Without this, OpenSCAD
        # unions them but they remain as separate manifolds in the STL — and
        # tools like Bambu Studio's "Split to Objects" treat them as separate
        # objects.
        fuse_eps = 0.1
        tab_b = (
            cube([self.tab_radial_extent, self.tab_tangential_width + fuse_eps, self.body_axial])
            .right(lever_inner_r)
            .up(z_bot)
            .back(self.tab_tangential_width)  # shift -Y; +Y face now at Y=+fuse_eps (inside lever arm)
        )

        # FINGER CATCH (A) — extends TANGENTIALLY from the TAB's outer-radial
        # end, perpendicular to the TAB's radial direction. Same axial height as
        # the TAB and lever arm (z_bot..z_bot+body_axial). The catch lives in
        # the −Y direction in the build-tab frame (away from the lever arm /
        # tooth side), giving the fingertip a hook on the TAB's outer corner.
        # Outer radial face: flush with the TAB's outer radial face. +Y face of
        # the catch: flush with the TAB's −Y face (they share that face).
        # +Y dimension extended by `fuse_eps` so the CATCH overlaps the TAB
        # by a small VOLUME at their shared face (same reason as TAB above).
        catch = (
            cube([self.finger_catch_thk, self.finger_catch_extent + fuse_eps, self.body_axial])
            .right(lever_inner_r + self.tab_radial_extent - self.finger_catch_thk)
            .up(z_bot)
            .back(self.tab_tangential_width + self.finger_catch_extent)
        )

        tab_assembly = union(tab_b, catch).rotate([0, 0, -self.body_arc_deg])

        return union(flex, body, tooth, tab_assembly)


class BronicaS2LensMountLocking(LensMountLocking, BronicaS2LensMount):
    """Bronica S2 lens mount with the tangentially-rocking flex-tab latch."""


class LensMountLockingSupports(LensMountLocking):
    """Modeled supports for printing `LensMountLocking` with PETG support
    material against a PLA part.

    Outputs ONLY the support volumes (no lens-mount geometry). Designed for
    Bambu Studio's multi-object workflow:

      1. Load the main lens-mount STL (`s2_mount-lens_locking.stl`) AND this
         supports STL (`s2_mount-lens_locking_supports.stl`) as TWO separate
         objects in the same plate. Position them at the same world coords
         (don't auto-arrange — both are pre-aligned in the model).
      2. Assign Generic PLA to the lens-mount object, Generic PETG to the
         supports object.
      3. On the lens-mount object, set `support: off` for the regions covered
         by the modeled supports (rotation channels and lever-arm clearance
         gap). The simplest way: paint blockers in the support-blocker tool
         over those regions, OR turn off auto-support entirely if the modeled
         supports cover everything that needs it.
      4. On the supports object, set `support: off` (it IS the support).
      5. PRINT ORIENTATION: bottom face on bed, entry rim pointing UP. The
         entry channels naturally point UP into open air with no roof to
         support, so we don't need to support them. The rotation channels
         have their roof (the bayonet lip) on the +z side, which DOES need
         support from below.

    Support shape is similar to `CameraMount` (a tube with lugs at the rim),
    but inverted relative to the lens mount and with the lugs widened to fill
    the rotational channels:

      - CENTRAL TUBE: a hollow tube sitting in the bore region, from the bed
        (SCAD z=0) up to the rotation-channel level (SCAD z=rest_z). Provides
        a foundation for the rotation lugs to print on. Sized to fit inside
        the bore with `support_air_gap` clearance.

      - ROTATION-CHANNEL FILLERS: arcs at each lug's rotation-channel angular
        range (wider than the lug itself by `lock_angle_deg` on the CCW edge),
        sized to fit inside the channel with `support_air_gap` on all sides.
        These sit on top of the central tube + the lens mount's bottom flange
        and fill the swept channel volume so the bayonet lip above the channel
        has continuous support during printing. At the latch's lug, the tooth
        volume is subtracted (with air gap) so the support doesn't fuse to or
        trap the tooth.

      - LEVER-ARM GAP SUPPORT: a thin curved slab in the `lever_clearance` gap
        between the OD and the lever arm, from the bed up to just below the
        lever arm's bottom face in SCAD (with air gap). Provides a foundation
        for the lever arm's first print layer. Excludes the flex-zone
        tangential range (the flex bridges the gap there).

    Note: NO entry-channel supports are needed. In this print orientation the
    entry channels are notches in the lip that open UPWARD into air — there's
    no roof to support.

    All air gaps to the lens mount are built into this geometry — there is no
    slicer-applied Z distance for multi-object support, so the gap MUST be in
    the model. PETG-on-PLA non-adhesion lets the supports pop off cleanly.
    """

    support_air_gap = 0.1     # radial/axial air gap between support and lens mount (mm)
    support_air_gap_deg = 0.5 # tangential air gap (degrees of arc)
    support_tube_wall_thk = 1.5  # wall thickness of the central support tube (mm)
    support_inward_offset = 1.0  # mm. The inner arcs are shifted radially inward by this amount, so the arc's outer face sits 1 mm inside the channel-filler's natural inner face. The filler's inner edge is also extended inward by the same amount, so the arc and filler keep their 0.1 mm radial overlap and stay as one printed part. The net effect: a step on the OUTSIDE of the arc (between the arc and the lens-mount lip) so the support can wiggle radially before having to clear the lip — much easier to remove.

    def build(self):
        # Tooth angular position (only the largest lug has the tooth, but we
        # subtract from all fillers for simplicity — it's a no-op elsewhere).
        tooth_center_deg, pivot_center_deg = self._tooth_and_pivot_angles()
        tooth_local_az = tooth_center_deg - pivot_center_deg

        # Tooth bounding box (build frame) — expanded by support_air_gap on all
        # sides — for subtraction from the rotation-channel filler. Mirrors the
        # tooth geometry built in LensMountLocking._build_latch (where x_outer
        # extends 0.1 mm into the lever arm by `fuse_eps` for clean union).
        tooth_fuse_eps = 0.1  # must match LensMountLocking._build_latch's fuse_eps
        tooth_arc_mm_at_outer = self.tooth_angular_width_deg * math.pi / 180.0 * self.outer_or
        lever_inner_r = self.outer_or + self.lever_clearance
        x_outer = lever_inner_r + tooth_fuse_eps
        x_inner = lever_inner_r - self.tooth_radial_depth
        y_lo = -tooth_arc_mm_at_outer / 2
        y_hi = +tooth_arc_mm_at_outer / 2
        z_lo_t = self.rest_z + self.tooth_axial_clearance
        z_hi_t = self.rest_z + self.lug_axial - self.tooth_axial_clearance
        ag = self.support_air_gap
        tooth_neg = (
            cube([
                (x_outer - x_inner) + 2 * ag,
                (y_hi - y_lo) + 2 * ag,
                (z_hi_t - z_lo_t) + 2 * ag,
            ])
            .right(x_inner - ag)
            .up(z_lo_t - ag)
            .back(-(y_lo - ag))   # shift in −Y to get y_lo - ag as the −Y face
            .rotate([0, 0, tooth_local_az])
            .rotate([0, 0, pivot_center_deg])
        )

        # ── CENTRAL SUPPORT — three arc segments ──────────────────────────────
        # The support "tube" in the bore is BROKEN into three arc segments,
        # one per lug. A single closed tube can't be removed from the printed
        # lens mount because its rotation-channel fillers (above) are wider
        # than the bore at the lip — the only way to extract a closed tube
        # would be to cut it. Three independent arcs each bring out their own
        # lug's filler with them, one at a time.
        #
        # Each segment spans only the SWEPT portion of its lug's rotation
        # channel — the part of the channel that's NOT under an entry-channel
        # notch in the bayonet lip. That's the only region where the lip
        # actually has a roof that needs support. The entry-channel notches
        # cut all the way through the lip, so the rotation channel beneath
        # them has no roof — no point supporting there.
        #
        # Support angular range per lug: [c − w/2 − lock_angle, c − w/2]
        # (with `support_air_gap_deg` clearance on each end). Outside this
        # range, either the rotation channel doesn't exist or the lip is
        # already cut.
        #
        # Each segment is shifted radially INWARD by `support_inward_offset` mm
        # so the arc's outer face is 1 mm clear of the lens-mount lip's inner
        # face. With the filler's inner edge ALSO extended inward by the same
        # amount (below), the segment and filler still overlap radially by
        # 0.1 mm — they stay one printed part. The 1 mm inward step on the
        # outside of the arc means the segment+filler unit can wiggle inward
        # before having to clear the lip, much easier to extract by hand.
        bore_inner_diameter = self.cam_barrel_od + 2 * self.clearance
        support_tube_outer_r = (
            (bore_inner_diameter - 2 * self.support_air_gap) / 2
            - self.support_inward_offset
        )
        support_tube_inner_r = support_tube_outer_r - self.support_tube_wall_thk

        for c, w, p in self.lugs:
            # Support only the swept-and-not-entry-channel part of the rotation
            # channel: from the rotation channel's CCW edge (c − w/2 − lock_angle)
            # to the entry channel's CCW edge (c − w/2). The CW half of the
            # rotation channel sits under the entry-channel notch (no roof =
            # no support needed).
            seg_start = c - w / 2 - self.lock_angle_deg + self.support_air_gap_deg
            seg_end = c - w / 2 - self.support_air_gap_deg
            # Segment top reaches the filler top (axially toward the camera).
            # The slicer prints the filler's bottom layer as a bridge from the
            # segment's outer face across the radial gap to the channel's
            # outer wall, so the filler is supported during printing without
            # being fused to the segment.
            yield (
                Arc(
                    r=(support_tube_inner_r + support_tube_outer_r) / 2,
                    width=support_tube_outer_r - support_tube_inner_r,
                    angles=(seg_start, seg_end),
                )
                .linear_extrude(
                    height=self.rest_z + self.lug_axial + self.axial_clearance - self.support_air_gap
                )
            )

        # ── ROTATION-CHANNEL FILLERS ──────────────────────────────────────────
        # One per lug. Wider than the lugs (covers the full rotation-channel
        # arc including the swept volume the lug rotated through).
        #
        # Axially: filler bottom is at `rest_z + support_air_gap` (NOT at rest_z)
        # so there's a 0.1 mm air gap between the filler's bottom face and the
        # lens-mount bottom flange's top face — otherwise they'd share a 2D
        # face and CGAL would fuse the supports with the lens mount, defeating
        # the multi-material setup. The 0.1 mm gap is small enough that the
        # slicer bridges it on the layer above.
        #
        # Filler inner edge is extended inward by `support_inward_offset` mm
        # past body_or so it overlaps the (also-inward-shifted) support arc
        # by 0.1 mm radially — segment and filler stay one printed part.
        # The 1 mm "tongue" of filler that hangs inward of the lens-mount
        # lip's inner face is bridged at print time from the arc's top edge.
        for c, w, p in self.lugs:
            filler_inner_r = self.body_or - self.support_inward_offset
            filler_outer_r = self.body_or + p - self.support_air_gap  # 0.1 air gap to channel outer wall
            # Tangential range matches the segment beneath: only the swept-
            # and-not-entry-channel part of the rotation channel.
            rot_arc = Arc(
                r=(filler_inner_r + filler_outer_r) / 2,
                width=filler_outer_r - filler_inner_r,
                angles=(
                    c - w / 2 - self.lock_angle_deg + self.support_air_gap_deg,
                    c - w / 2 - self.support_air_gap_deg,
                ),
            )
            rot_filler = (
                rot_arc
                .linear_extrude(
                    # Filler height: channel height minus 2 × air_gap (one above, one below).
                    height=self.lug_axial + self.axial_clearance - 2 * self.support_air_gap
                )
                .up(self.rest_z + self.support_air_gap)  # 0.1 mm above bottom flange top
            )
            yield difference(rot_filler, tooth_neg)

        # ── LEVER ARM + TAB + FINGER CATCH FOOTPRINT SUPPORT ─────────────────
        # Provides a foundation for the lever arm + TAB + FINGER CATCH to print
        # on. The footprint of those three features (projected onto the bed)
        # is extruded from the bed up to just below the lever arm's bottom
        # face (with air gap).
        #
        # Important: the support stays OUTSIDE the lever_clearance gap (the
        # 0.6 mm radial space between the OD wall and the lever arm). Inner
        # radial face of the support starts AT the lever arm's inner face
        # (lever_inner_r). The gap is left empty — required for the latch to
        # operate, and any support there would be hard to extract anyway.
        #
        # The OD wall doesn't need this support — it goes all the way down to
        # the bed in print on its own. The flex zone bridges the gap and is
        # connected structurally to the OD wall, so it can print suspended
        # over the (now-unsupported) gap.
        z_lever_bot = self.rest_z - (self.body_axial - self.lug_axial) / 2
        support_z_top = z_lever_bot - self.support_air_gap
        if support_z_top > 0:
            grip_center_deg = pivot_center_deg - self.body_arc_deg

            # 2D footprint of the lever arm (annular sector at the lever arm's
            # radial range, from grip_center_deg to pivot_center_deg).
            lever_outer_r = lever_inner_r + self.body_thk
            lever_arc_2d = Arc(
                r=(lever_inner_r + lever_outer_r) / 2,
                width=lever_outer_r - lever_inner_r,
                angles=(grip_center_deg, pivot_center_deg),
            )

            # 2D footprint of the TAB and FINGER CATCH at the lever arm's CCW
            # endcap. Built at +X axis with the same translations as in
            # _build_latch (radial range, tangential −Y placement), then rotated
            # to grip_center_deg (the lever arm's CCW endcap angle in lens frame).
            # Both shapes get a +Y extension (`footprint_fuse_eps`) so their
            # unions overlap by VOLUME (not just shared edges). The TAB's
            # extension also has to span the lever-arc's CCW endcap arc, which
            # is at lever_outer_r — for a noticeable angular overlap there, the
            # extension needs to be at least ~1 mm at this radius.
            footprint_fuse_eps = 1.0
            tab_2d = (
                square([self.tab_radial_extent, self.tab_tangential_width + footprint_fuse_eps])
                .right(lever_inner_r)
                .back(self.tab_tangential_width)
            )
            catch_2d = (
                square([self.finger_catch_thk, self.finger_catch_extent + footprint_fuse_eps])
                .right(lever_inner_r + self.tab_radial_extent - self.finger_catch_thk)
                .back(self.tab_tangential_width + self.finger_catch_extent)
            )
            tab_catch_2d = union(tab_2d, catch_2d).rotate([0, 0, grip_center_deg])

            # Combine and extrude from bed up to support top (with axial air
            # gap to the lever arm above).
            yield (
                union(lever_arc_2d, tab_catch_2d)
                .linear_extrude(height=support_z_top)
            )


class BronicaS2LensMountLockingSupports(LensMountLockingSupports, BronicaS2LensMount):
    """Bronica S2 modeled supports for the locking lens mount."""


class s2_mount(Design):
    camera_mount = BronicaS2CameraMount()
    lens_mount = BronicaS2LensMount(
        cam_barrel_od=camera_mount.barrel_od,
        cam_barrel_id=camera_mount.barrel_id,
        lugs=camera_mount.lugs,
        lug_axial=camera_mount.lug_axial,
    )
    lens_mount_locking = BronicaS2LensMountLocking(
        cam_barrel_od=camera_mount.barrel_od,
        cam_barrel_id=camera_mount.barrel_id,
        lugs=camera_mount.lugs,
        lug_axial=camera_mount.lug_axial,
    )
    lens_mount_locking_supports = BronicaS2LensMountLockingSupports(
        cam_barrel_od=camera_mount.barrel_od,
        cam_barrel_id=camera_mount.barrel_id,
        lugs=camera_mount.lugs,
        lug_axial=camera_mount.lug_axial,
    )

    @variant(fn=96, default=True)
    def camera(self):
        return _check_plate(self.camera_mount)

    @variant(fn=96)
    def lens(self):
        return _check_plate(self.lens_mount)

    @variant(fn=96)
    def lens_locking(self):
        return _check_plate(self.lens_mount_locking)

    @variant(fn=96)
    def lens_locking_supports(self):
        # Modeled PETG supports for the lens_locking part. Print as a SECOND
        # object alongside lens_locking in Bambu Studio (PETG filament,
        # support: off on this object). Pre-aligned to the lens-mount's world
        # coords — load both STLs without auto-arrange.
        # Print orientation: bottom face on bed, entry rim pointing UP (same
        # orientation as the lens_locking part).
        return self.lens_mount_locking_supports.red()

    @variant(fn=96)
    def lens_locking_print(self):
        # Combined STL with the lens mount AND the modeled supports as TWO
        # disconnected manifold solids in the same file. Workflow:
        #   1. Load this single STL into Bambu Studio (drag-and-drop is fine).
        #   2. Right-click the imported object → "Split → To Objects" (or
        #      "Split into objects"). This makes the lens mount and the
        #      supports independent objects WITHOUT moving them — they stay
        #      at their original aligned positions.
        #   3. Assign Generic PLA to the lens-mount object, Generic PETG to
        #      the supports object.
        #   4. Set "support: off" on the supports object (it IS the support).
        #      Set "support: off" on the lens-mount object too if the modeled
        #      supports cover everything (they cover the rotation channels
        #      and the lever-arm gap; nothing else needs slicer support).
        # The two solids do NOT touch in the model (built-in air gaps), so
        # the union just joins them into one STL file without fusing.
        return _check_plate(
            union(self.lens_mount_locking, self.lens_mount_locking_supports.red())
        )


def _check_plate(node):
    bb = bbox(node)
    if bb.size[0] > BAMBU_X2D_PLATE_X or bb.size[1] > BAMBU_X2D_PLATE_Y:
        raise ValueError(
            f"print layout {bb.size[0]:.1f} x {bb.size[1]:.1f} mm "
            f"exceeds Bambu X2D build plate "
            f"{BAMBU_X2D_PLATE_X} x {BAMBU_X2D_PLATE_Y} mm"
        )
    return node


if __name__ == "__main__":
    run()
