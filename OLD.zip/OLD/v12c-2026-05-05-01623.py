"""Lens housing with stacked optical elements and a matching clip-on hood.

Shows the recommended multi-part layout (see
docs/organizing_a_project.md). Generic Components live in the REUSABLE
zone with no project-specific defaults; the specific design for an
M57-throat camera lives in the CONCRETE zone as thin subclasses that
fill in measurements as class attributes.

Run:
    python examples/lens-housing.py                                  # print variant (default)
    scadwright build examples/lens-housing.py --variant=display        # assembled view
    scadwright build examples/lens-housing.py --variant=print          # split + spread for inspection
"""

from collections import namedtuple
from math import radians, tan

from scadwright import Component, Param, bbox, from_json
from scadwright.boolops import difference, intersection, union
from scadwright.composition_helpers import mirror_copy
from scadwright.design import Design, run, variant
from scadwright.primitives import circle, cube, cylinder
from scadwright.shapes import FilletRing, Funnel, Sector, Tube


# =============================================================================
# REUSABLE: generic Components, helpers, value types
# =============================================================================


# spacing is from flange (z=0) to element center; +z = toward object.
# `face_z_top`, `face_z_bot`, `constricted`, `throat_dia_required` are
# precomputed by `element(...)` so the housing's `equations` list can
# reference them as attributes directly. `code` (catalog code, e.g.
# "L7325") and `type` (e.g. "NMN", "ACH", "BCX") identify the lens.
Element = namedtuple(
    "Element",
    "code type dia edge_thk spacing face_z_top face_z_bot constricted throat_dia_required",
)


class ElementHolder(Component):
    """Two-sided clamp around one Element, symmetric about the element center."""

    AXIAL_CLR = 0.2
    RADIAL_CLR = 0.2

    element = Param(Element)
    equations = """
        od, grip_depth, grip_width > 0
    """

    def build(self):                                       # framework hook: required; returns the shape
        e = self.element
        surround_h = 0.5 * e.edge_thk + self.AXIAL_CLR
        surround = Tube(h=surround_h, od=self.od, id=e.dia + self.RADIAL_CLR)
        gripper = Tube(
            h=0.5 * self.grip_width,
            od=self.od,
            id=e.dia - self.grip_depth,
        ).attach(surround, fuse=True)
        half = union(surround, gripper).flip("z")
        return mirror_copy(half, normal=[0, 0, 1]).up(e.spacing)


def element(*, code, type, dia, edge_thk, spacing, grip_width, mount_offset=0):
    """Build an `Element` with its computed geometric fields filled in.

    The caller supplies `grip_width` (the holder's per-side gripper
    height) so the housing's equations can reason about each element's
    z-extent through attribute access. `mount_offset` is the axial
    extent of the lens-mount ring above the camera flange (z=0); the
    M57-restricted lower section of the housing extends up to this z,
    so an element is `constricted` when its lower face is below the
    top of the mount-ring zone (face_z_bot < mount_offset).
    """
    half = (edge_thk + 2 * grip_width) / 2
    return Element(
        code=code, type=type,
        dia=dia, edge_thk=edge_thk, spacing=spacing,
        face_z_top=spacing + half,
        face_z_bot=spacing - half,
        constricted=(spacing - half) < mount_offset,
        throat_dia_required=dia + ElementHolder.RADIAL_CLR,
    )


# A waterhouse stop is a thin disc slid laterally into the lens barrel
# through a side slot to set the aperture. `spacing` is the stop center's
# z-position, `thk` the disc thickness, `clr` the slot's z-clearance.
Stop = namedtuple("Stop", "spacing thk clr")


def stop(*, spacing, thk, clr):
    """Build a `Stop` value for a waterhouse stop."""
    return Stop(spacing=spacing, thk=thk, clr=clr)


class WaterhouseStop(Component):
    """A waterhouse stop disc.

    Viewed face-on, it's a 2D paddle: a smaller semicircle of radius
    `barrel_id`/2 in -Y joined to a larger semicircle of radius
    `barrel_od`/2 in +Y along their flat edges, with a central aperture
    hole of diameter `hole_d`. Extruded by `thk` along the lens axis
    and centered on `spacing`. When inserted, the lower (ID) semicircle
    sits in the bore as the aperture plate; the upper (OD) semicircle
    fills the wall slot, leaving a flush exterior. The hole sits on the
    barrel's axis."""

    equations = """
        barrel_id, barrel_od, thk, hole_d > 0
        barrel_id < barrel_od
        hole_d < barrel_id
        # `spacing` is the disc's z-center; `slot_bottom` is the
        # extruder's lower edge. The derivation establishes `spacing` as
        # a Param(float) without an artificial inequality (it can be
        # negative — the stop sits below the flange in the default).
        slot_bottom = spacing - thk / 2
    """

    def build(self):                                       # framework hook: required; returns the shape
        upper = Sector(r=self.barrel_od / 2, angles=(0, 180))
        lower = Sector(r=self.barrel_id / 2, angles=(180, 360))
        paddle_2d = difference(union(upper, lower), circle(d=self.hole_d))
        paddle = paddle_2d.linear_extrude(height=self.thk)
        return paddle.up(self.slot_bottom).red()


class StopHolder(Component):
    """Two-sided clamp around a waterhouse stop. Upper and lower grippers
    flank the slot symmetrically along z; both pinch the stop's lower-ID
    semicircle from outside the slot. Each gripper has its own outer
    diameter so the holder can sit in a section where the local wall OD
    differs above vs. below the stop (e.g. when the stop lands inside the
    expansion funnel). When `od_top == od_bot` the result matches a
    uniform-OD section. ID is shared across both grippers since the disc
    they pinch is one diameter regardless of where it sits."""

    stop = Param(Stop)
    equations = """
        od_top, od_bot, grip_depth, grip_width, barrel_id > 0
        barrel_id > grip_depth
    """

    def build(self):                                       # framework hook: required; returns the shape
        s = self.stop
        slot_h = s.thk + s.clr
        half_gw = 0.5 * self.grip_width
        upper = Tube(
            h=half_gw, od=self.od_top, id=self.barrel_id - self.grip_depth,
        ).up(slot_h / 2)
        lower = Tube(
            h=half_gw, od=self.od_bot, id=self.barrel_id - self.grip_depth,
        ).down(slot_h / 2 + half_gw)
        return union(upper, lower).up(s.spacing).green()


def trunc_fillet_ring(*, id, od, base_angle, slant="outwards", rim_width):
    """A `FilletRing` with its sharp apex chopped to a flat rim of
    `rim_width` radial width."""
    if rim_width <= 0:
        raise ValueError("rim_width must be > 0")
    if rim_width >= (od - id) / 2:
        raise ValueError("rim_width must be less than the ring's radial extent")
    # Radial eps: the chopper's outer cylindrical surface sits at d=od, same
    # as the FilletRing's outer wall. through() handles planar-bbox coplanar
    # faces but not cylinder-on-cylinder coincidence, so nudge the chopper
    # outward by a hair.
    eps = 0.01
    base = FilletRing(id=id, od=od, base_angle=base_angle, slant=slant)
    h_full = tan(radians(base_angle)) * (od - id) / 2
    z_t = tan(radians(base_angle)) * ((od - id) / 2 - rim_width)
    chopper = cylinder(h=h_full - z_t, d=od + 2 * eps).up(z_t).through(base, axis="z")
    return difference(base, chopper)


class LensHousing(Component):
    """Generic lens barrel: lower recess + flange + upper housing (narrow
    or funnel-widened) + element holders + front fillet. A matching hood
    Component can read the outer dimensions and hood cone angle off this
    housing to mate without shared scope."""

    FRONT_FILLET_OFFSET = 5.0   # aperture rim inset from the front element's grip ID

    stop = Param(Stop, default=None)
    equations = """
        # Wall-thickness split: the lower (M57-fit) section needs to fit
        # inside the camera's M57 throat, so its OD is constrained from
        # above by camera-body geometry — typically a thin (~1 mm radial)
        # wall. The flange-flange/funnel/upper section sits outside the
        # camera body and is wide enough to host a stepped lap joint
        # internally — typically a thick (~5 mm radial) wall. The two
        # are independent because they're constrained by different
        # physical realities.
        lower_housing_od = lower_housing_id + lower_barrel_thk
        hood_base_angle = 90 - fov_angle / 2
        lower_housing_od, lower_housing_id, housing_insertion_depth, lower_barrel_thk, upper_barrel_thk > 0
        flange_flange_od, flange_flange_len, fov_angle, hood_base_angle > 0
        grip_depth, grip_width > 0
        mount_offset >= 0
        # `housing_insertion_depth` is how far the lower housing reaches
        # into the camera body below the camera flange plane (z=0). It's
        # set by the camera's M57 throat depth — a fixed physical
        # constraint of the camera body, not a design choice.
        # `lower_housing_len` is the TOTAL length of the lower (M57-fit)
        # tube, spanning from the deepest point inside the throat
        # (z = -housing_insertion_depth) up through the camera flange and
        # the mount-ring zone to the top of the mount ring (z = mount_offset).
        # The flange plane (z=0) sits inside this section, not at one of
        # its boundaries.
        lower_housing_len = housing_insertion_depth + mount_offset
        unconstricted = tuple(e for e in elements:tuple if not e.constricted)
        max_upper_ele_dia = max((e.dia for e in unconstricted), default=0.0)
        is_wide = max_upper_ele_dia > lower_housing_id
        expansion_funnel_len = min((e.face_z_bot for e in unconstricted), default=inf)
        upper_housing_len = max(e.face_z_top for e in elements)
        upper_housing_od = (max_upper_ele_dia + upper_barrel_thk) if is_wide else flange_flange_od
        all(not e.constricted or e.throat_dia_required <= lower_housing_id for e in elements)
        # Wide-mode invariant: in funnel variants the funnel runs from
        # mount_offset (the top of the mount-ring zone, where the lower
        # tube ends) to expansion_funnel_len (the bottom of the lowest
        # unconstricted element). The funnel needs positive height, so the
        # lowest unconstricted element must sit strictly above the mount-
        # ring zone. (`element()` now defines constricted as face_z_bot <
        # mount_offset, so unconstricted elements have face_z_bot >=
        # mount_offset; this rule guards the equality edge case.)
        not is_wide or expansion_funnel_len > mount_offset
        # Stop slot must lie entirely in a section we can handle:
        #   (a) below the flange-flange (z <= mount_offset) — uniform
        #       lower-housing OD;
        #   (b) above the flange/funnel transition — uniform upper-
        #       housing OD;
        #   (c) (wide variant only) entirely within the funnel range
        #       [mount_offset, expansion_funnel_len] — handled by the
        #       per-gripper-OD logic in `wall_od_at_z` and the StopHolder
        #       od_top/od_bot pair.
        # The flange-overlap and mount-ring/flange transition zones stay
        # forbidden because they have a wall-OD discontinuity no cylindrical
        # gripper can span. The `?stop` sigil makes this line auto-skip
        # when no stop is supplied.
        ?stop.spacing + (stop.thk + stop.clr) / 2 <= mount_offset or stop.spacing - (stop.thk + stop.clr) / 2 >= (expansion_funnel_len if is_wide else mount_offset + flange_flange_len) or (is_wide and stop.spacing - (stop.thk + stop.clr) / 2 >= mount_offset and stop.spacing + (stop.thk + stop.clr) / 2 <= expansion_funnel_len)
    """

    def wall_od_at_z(self, z):
        """Outer-wall diameter at axial position z. Used to size each
        stop-holder gripper to its local wall thickness so a gripper that
        lands inside the expansion funnel doesn't poke out past the
        (narrower-at-its-bottom) wall.

        Region boundaries shift by `mount_offset`: the lower (M57-fit,
        thin-walled) section runs up to z=mount_offset; above it the
        flange-flange sits at [mount_offset, mount_offset+flange_flange_
        len], and (in wide variants) the funnel runs from mount_offset
        to expansion_funnel_len, overlapping the flange in the flange's
        z-range. The OD STEPS at z=mount_offset because the lower
        section's wall is thin (lower_barrel_thk) while the section
        above uses upper_barrel_thk — there's no continuous transition
        across that boundary.
        """
        mo = self.mount_offset
        if z <= mo:
            return self.lower_housing_od
        if not self.is_wide:
            if z <= mo + self.flange_flange_len:
                return self.flange_flange_od
            return self.upper_housing_od
        # Wide: funnel spans [mo, expansion_funnel_len], overlapping the
        # flange in [mo, mo + flange_flange_len] where the flange's wider
        # OD wins. Funnel uses upper_barrel_thk for its wall, so its bot
        # OD = lower_id + upper_barrel_thk (NOT lower_housing_od, which
        # is the thin lower section's OD just below the step).
        funnel_bot_od = self.lower_housing_id + self.upper_barrel_thk
        funnel_total_h = self.expansion_funnel_len - mo
        funnel_od = funnel_bot_od + (
            self.upper_housing_od - funnel_bot_od
        ) * (z - mo) / funnel_total_h
        if z <= mo + self.flange_flange_len:
            return max(self.flange_flange_od, funnel_od)
        if z <= self.expansion_funnel_len:
            return funnel_od
        return self.upper_housing_od

    def build(self):
        lower_id = self.lower_housing_id
        upper_id = self.max_upper_ele_dia if self.is_wide else lower_id
        mo = self.mount_offset

        # Lower (M57-restricted) tube spans from the deepest point inside
        # the camera throat (z = -housing_insertion_depth) up through the
        # camera flange and the mount-ring zone to the top of the mount
        # ring (z = mount_offset). The flange plane (z=0) is just a
        # reference point inside this section — the section itself is one
        # continuous piece, all M57-fit OD/ID and all wall thickness.
        lower = Tube(
            h=self.lower_housing_len, od=self.lower_housing_od, id=lower_id,
        ).down(self.housing_insertion_depth)

        # Flange-flange shifts up to sit on top of the mount ring rather
        # than directly on the camera flange. Element absolute z's are
        # unchanged; the upper section shrinks at the bottom to keep the
        # housing's total length the same.
        flange = Tube(
            h=self.flange_flange_len, od=self.flange_flange_od, id=lower_id,
        ).up(mo)

        if self.is_wide:
            # Funnel bottom pushed back to z=mount_offset (was z=0). Same
            # OD endpoints; the funnel takes a sharper angle to span the
            # reduced axial range without lengthening the lens. The funnel
            # uses upper_barrel_thk (the THICK wall) — its OD bot will
            # therefore step UP from the thin lower section's OD at z=
            # mount_offset (the shoulder that rests on the mount ring).
            funnel_h = self.expansion_funnel_len - mo
            funnel = Funnel(
                h=funnel_h, thk=self.upper_barrel_thk / 2,
                bot_id=lower_id, top_id=self.max_upper_ele_dia,
            ).up(mo)
            upper = Tube(
                h=self.upper_housing_len - self.expansion_funnel_len,
                od=self.max_upper_ele_dia + self.upper_barrel_thk,
                id=self.max_upper_ele_dia,
            ).up(self.expansion_funnel_len)
            barrel = union(lower, flange, funnel, upper)
        else:
            # Upper now starts where the flange-flange ends (no overlap
            # with the flange; same OD so the union is visually identical
            # to the original overlapping arrangement).
            flange_top = mo + self.flange_flange_len
            upper = Tube(
                h=self.upper_housing_len - flange_top,
                od=self.upper_housing_od, id=lower_id,
            ).up(flange_top)
            barrel = union(lower, flange, upper)

        # Slot OD: the maximum housing OD at the slot's z range. In the
        # uniform-OD allowed bands this is just the local OD; in the
        # funnel band the slot's TOP has the largest local OD (funnel
        # widens upward), so we use that. +1 mm radial overshoot avoids
        # cylinder-on-cylinder coplanar faces in the difference.
        if self.stop is not None:
            s = self.stop
            slot_h = s.thk + s.clr
            half_gw = 0.5 * self.grip_width
            slot_od = self.wall_od_at_z(s.spacing + slot_h / 2)
            slot = Tube(
                h=slot_h, od=slot_od + 1, id=lower_id - 0.1,
            ).halve([0, 1, 0]).up(s.spacing - slot_h / 2)
            barrel = difference(barrel, slot)

        yield barrel

        for e in self.elements:
            holder_od = lower_id if e.constricted else upper_id
            # Known limitation (wide variants only): when an unconstricted
            # element's dia equals max_upper_ele_dia, holder_od == its
            # own dia and the holder's surround tube has thk = -RADIAL_CLR/2
            # (negative). The fix is to size the widest element's holder
            # off upper_housing_od (wall outer) rather than upper_id
            # (wall inner == element dia). Leaving as a follow-up.
            yield ElementHolder(
                element=e, od=holder_od,
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        if self.stop is not None:
            # Per-gripper OD: each gripper's outer cylinder is sized to
            # the local wall OD at the gripper's BOTTOM (the narrowest
            # point in its z extent for an upward-widening funnel), so
            # the gripper is fully embedded in wall material with no
            # radial overshoot anywhere along its height.
            upper_z_bot = s.spacing + slot_h / 2
            lower_z_bot = s.spacing - slot_h / 2 - half_gw
            yield StopHolder(
                stop=self.stop,
                od_top=self.wall_od_at_z(upper_z_bot),
                od_bot=self.wall_od_at_z(lower_z_bot),
                barrel_id=lower_id,
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        front_ele_dia = max(self.elements, key=lambda e: e.spacing).dia
        yield trunc_fillet_ring(
            id=front_ele_dia - self.grip_depth + self.FRONT_FILLET_OFFSET,
            od=self.upper_housing_od,
            base_angle=self.hood_base_angle,
            slant="inwards",
            rim_width=2,
        ).attach(upper, fuse=True)


class LensHood(Component):
    """Generic clip-on hood sized by a paired housing. `housing_upper_od`
    and `hood_base_angle` come from the housing; the rest are hood-specific.
    Built in its mounted orientation: coupler at z=0, funnel flaring upward.
    The print variant flips it."""

    equations = """
        housing_upper_od, hood_base_angle, wall_thk, hood_length, coupler_overlap > 0
        hood_clr >= 0
        id_coupler = housing_upper_od + hood_clr
        od_coupler = id_coupler + 2 * wall_thk
        flare_od = housing_upper_od + 2 * hood_length * tan(90 - hood_base_angle)
    """

    def build(self):                                       # framework hook: required; returns the shape
        coupler = Tube(
            h=self.coupler_overlap, id=self.id_coupler, thk=self.wall_thk,
        )
        yield coupler
        yield Funnel(
            h=self.hood_length, thk=self.wall_thk,
            bot_od=self.housing_upper_od, top_od=self.flare_od,
        ).attach(coupler, fuse=True)
        yield FilletRing(
            id=self.id_coupler, od=self.od_coupler,
            base_angle=63, slant="inwards",
        ).attach(coupler, fuse=True)


def lap_split_x(housing, *, side, overlap, mid_radius, z_min=None):
    """Halve `housing` at X=0 with a stepped lap joint of depth `overlap`
    at radial position `mid_radius`. `side` is 'minus' (keep X<=0) or
    'plus' (keep X>=0). The kept half's outer layer (r >= mid_radius)
    extends past X=0 by `overlap`; its inner layer (r < mid_radius) is
    recessed from X=0 by `overlap`. The 'minus' and 'plus' results mate
    to reconstruct the original housing: light path through the joint
    zigzags through the step (light-tight); the step constrains relative
    XY position (self-aligning); engages by pure X-translation, no axial
    sliding.

    `mid_radius` must lie inside the wall everywhere along Z (between
    the bore and the outer wall in every section), or the layers will
    have zero thickness somewhere.

    `z_min` (optional) confines the lap features to z >= z_min. The
    lower (M57-fit, thin-walled) section of a housing should not have
    lap features (the wall is too thin to host the step), so the M57
    design passes z_min=mount_offset. Below z_min, the housing is just
    cleanly halved at X=0 with no lap geometry. If None (default), the
    lap features extend along the full housing.
    """
    if side not in ("minus", "plus"):
        raise ValueError(f"side must be 'minus' or 'plus', got {side!r}")
    sign = -1 if side == "minus" else 1
    half = housing.halve([sign, 0, 0])

    # Slabs are far larger than any housing; intersection clips them to
    # the wall geometry, so the step automatically conforms to varying
    # OD/ID along Z (e.g. the funnel transition in wide variants). When
    # z_min is set, the slab is anchored at z=z_min (not Z-centered) so
    # only z >= z_min material is included.
    big = 1000.0
    z_centered = z_min is None
    z_axes = "yz" if z_centered else "y"
    def _slab():
        c = cube([overlap, big, big], center=z_axes)
        return c if z_centered else c.up(z_min)
    if side == "minus":
        tongue_slab = _slab()                  # X in [0, overlap]
        groove_slab = _slab().left(overlap)    # X in [-overlap, 0]
    else:
        tongue_slab = _slab().left(overlap)    # X in [-overlap, 0]
        groove_slab = _slab()                  # X in [0, overlap]

    # `inner_volume` is the cylinder of radius `mid_radius` around Z;
    # outer-layer = housing - inner_volume; inner-layer = housing & inner_volume.
    inner_volume = cylinder(r=mid_radius, h=big, center="z")

    tongue = difference(intersection(housing, tongue_slab), inner_volume)
    groove = intersection(intersection(housing, groove_slab), inner_volume)
    return difference(union(half, tongue), groove)


def half_housing_splay(half, *, side, lap_overlap=0.0):
    """Lay one housing half flat on the print bed: rotate so the cut
    face lies parallel to the bed (cut-face-down) and lift the result
    by `lap_overlap` so the lap-joint tongue (which extends past the
    cut plane and would otherwise dip below Z=0 after the rotation)
    rests on the bed.

    `side` selects the rotation direction so the kept material lands
    above the bed regardless of which half was cut. `lap_overlap` is
    the same value passed to `lap_split_x`; it's explicit here because
    the framework's `bbox()` returns a conservative AABB across `halve`,
    so the actual minimum Z can't be derived from the splayed shape.
    Pass 0.0 if the half has no lap joint.
    """
    angle = 90 if side == "minus" else -90
    return half.rotate([0, angle, 0]).up(lap_overlap)


# =============================================================================
# CONCRETE: the specific M57 design
# =============================================================================


GRIP_DEPTH = 1.5
GRIP_WIDTH = 1.0

# Must match BronicaS2LensMount.protrusion_len in s2-mount.py — the lens-
# mount ring sits in the axial zone z=[0, MOUNT_OFFSET] above the camera
# flange, so the housing leaves that zone clear: the M57-restricted lower
# tube extends up to z=MOUNT_OFFSET, the flange-flange rests on top of
# the ring, and (for funnel/wide variants) the funnel starts at z=
# MOUNT_OFFSET with a sharper angle so the housing stays the same total
# length and no elements move in absolute z.
MOUNT_OFFSET = 5.0

# Waterhouse stop: 1.5mm disc, 0.5mm slot clearance for sliding fit.
# Depth and hole-diameter list come from the design (defaults below or
# loaded from --config).
STOP_THK = 1.5
STOP_CLR = .5

# v12c-bowl-swirl defaults (used unless --config overrides). Front to rear.
# `mounted_od` is optional and only applies to the element that carries it
# (its mount/cell is wider than the bare lens); the housing uses
# max(diameter, mounted_od) for clearance on those elements.
DEFAULT_ELEMENTS_DATA = (
    {"code": "L7325",  "type": "NMN", "diameter": 52.0, "edge_thickness": 6.2, "spacing":  34.6},
    {"code": "L14523", "type": "ACH", "diameter": 35.0, "mounted_od": 44.4, "edge_thickness": 13, "spacing":  12.6},
    {"code": "L13088", "type": "BCX", "diameter": 42.5, "edge_thickness":  2.2, "spacing":  -9.4},
)
DEFAULT_STOP_DEPTH = -2.7
DEFAULT_STOP_HOLE_D = (20.0, 14.3, 10.0, 7.3)


# Optional design override: invoke with `--from-json <path>`. The JSON is
# expected to carry `elements` (list of element dicts) and `stop` (dict with
# `depth` and `hole_diameters`). Missing keys surface as KeyError when the
# data is consumed below; the framework absorbs file-not-found / invalid-JSON
# at parse time.
_cfg = from_json()
if _cfg is not None:
    _elements_data = _cfg["elements"]
    STOP_DEPTH = float(_cfg["stop"]["depth"])
    STOP_HOLE_D = tuple(float(d) for d in _cfg["stop"]["hole_diameters"])
else:
    _elements_data = DEFAULT_ELEMENTS_DATA
    STOP_DEPTH = DEFAULT_STOP_DEPTH
    STOP_HOLE_D = DEFAULT_STOP_HOLE_D

def _effective_dia(e):
    """Use the mount OD when wider than the bare lens; bare diameter otherwise."""
    d = float(e["diameter"])
    if "mounted_od" in e:
        return max(d, float(e["mounted_od"]))
    return d


ELEMENTS = tuple(
    element(
        code=e["code"], type=e["type"],
        dia=_effective_dia(e), edge_thk=float(e["edge_thickness"]),
        spacing=float(e["spacing"]),
        grip_width=GRIP_WIDTH,
        mount_offset=MOUNT_OFFSET,
    )
    for e in _elements_data
)
THE_STOP = stop(spacing=STOP_DEPTH, thk=STOP_THK, clr=STOP_CLR)


# Stepped lap joint between the two printed housing halves. The wall is
# thick enough (5 mm radial) to host the step internally with both layers
# >=2.5 mm thick everywhere; no external rib needed. `LAP_MID_RADIUS` sits
# between the bore (r=27) and the outer wall (r=32 lower, r=33.5 flange/
# upper); the step is centered on the lower wall and biased toward the
# bore in flange/upper, but both layers stay >=2.5 mm.
LAP_OVERLAP = 3.0
LAP_MID_RADIUS = 29.5


class M57LensHousing(LensHousing):
    # Lower (M57-fit) section: OD must clear the camera's M57 throat
    # (~57 mm), so it's set just under that with a thin (1 mm radial)
    # wall. This is a hard physical constraint, not negotiable for fit.
    lower_housing_od = 56.0
    lower_barrel_thk = 2.0   # diameter delta = 2 x radial wall = 1 mm radial (thin)
    # M57 throat penetration: how far the lower housing reaches into the
    # camera body below the flange plane. Set by the camera's M57 throat
    # depth — physical, not a design choice. The total lower-tube length
    # (`lower_housing_len`) is derived as housing_insertion_depth + mount_offset.
    housing_insertion_depth = 14.5
    # Upper section (flange-flange / funnel / upper) wall thickness: thick
    # enough to host the stepped lap joint internally (5 mm radial gives
    # 2.5/2.5 mm layers around mid_radius). The upper section sits outside
    # the camera body so its OD is unconstrained by the throat.
    upper_barrel_thk = 10.0  # diameter delta = 2 x radial wall = 5 mm radial (thick)
    flange_flange_od = 67.0
    flange_flange_len = 5.0
    fov_angle = 57.0
    grip_depth = GRIP_DEPTH
    grip_width = GRIP_WIDTH
    mount_offset = MOUNT_OFFSET
    elements = ELEMENTS
    stop = THE_STOP


class M57LensHood(LensHood):
    wall_thk = 2.0
    hood_clr = 0.4
    hood_length = 20.0
    coupler_overlap = 6.0


# =============================================================================
# DESIGN: shared parts + variant methods
# =============================================================================


def _make_stop_discs(housing, hole_diameters):
    """One `WaterhouseStop` per hole diameter, all sharing the same
    barrel dimensions, thickness, and depth."""
    return tuple(
        WaterhouseStop(
            barrel_id=housing.lower_housing_id,
            barrel_od=housing.lower_housing_od,
            thk=STOP_THK,
            hole_d=h,
            spacing=STOP_DEPTH,
        )
        for h in hole_diameters
    )


# Bambu X2D buildable area on the bed (mm). Layouts must fit within these.
BAMBU_X2D_PLATE_X = 256
BAMBU_X2D_PLATE_Y = 256


class v12c(Design):
    housing = M57LensHousing()
    hood = M57LensHood(
        housing_upper_od=housing.upper_housing_od,
        hood_base_angle=housing.hood_base_angle,
    )
    stop_discs = _make_stop_discs(housing, STOP_HOLE_D)

    def _splayed_halves(self):
        """The two housing halves, lap-jointed at X=0 and laid flat for
        the bed. Returned as a (minus, plus) pair. The lap is confined
        to z >= MOUNT_OFFSET (the thick-walled section above the mount
        ring); the thin-walled lower section below z=MOUNT_OFFSET gets
        a clean halve only."""
        return (
            half_housing_splay(
                lap_split_x(self.housing, side="minus",
                            overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
                            z_min=MOUNT_OFFSET),
                side="minus", lap_overlap=LAP_OVERLAP,
            ),
            half_housing_splay(
                lap_split_x(self.housing, side="plus",
                            overlap=LAP_OVERLAP, mid_radius=LAP_MID_RADIUS,
                            z_min=MOUNT_OFFSET),
                side="plus", lap_overlap=LAP_OVERLAP,
            ),
        )

    @variant(fn=48, default=True)
    def print(self):
        # Compact bed layout sized for the Bambu X2D plate. The housing
        # is split into two distinct halves along X=0 with a stepped lap
        # joint (light-tight, self-aligning); both halves print cut-face-
        # down. Each splayed half is rotated 90° around Z so its long
        # axis runs along Y; the two halves sit side-by-side along Y,
        # and one waterhouse stop disc sits on the +X side. Asserts the
        # bounding footprint fits the printer's buildable area.
        minus, plus = self._splayed_halves()
        half_minus = minus.rotate([0, 0, 90])
        half_plus = plus.rotate([0, 0, 90])
        flat_stop = self.stop_discs[0].down(STOP_DEPTH - STOP_THK / 2)
        minus_bb = bbox(half_minus)
        plus_bb = bbox(half_plus)
        flat_bb = bbox(flat_stop)
        gap = 12   # ~1.2cm clearance between objects

        # Stack minus at -Y, plus at +Y, with `gap` between them.
        minus_placed = half_minus.back(minus_bb.max[1] + gap / 2)
        plus_placed = half_plus.forward(-plus_bb.min[1] + gap / 2)
        pair = union(minus_placed, plus_placed)
        pair_bb = bbox(pair)

        stop_placed = flat_stop.translate([
            pair_bb.max[0] + gap + flat_bb.size[0] / 2 - flat_bb.center[0],
            pair_bb.center[1] - flat_bb.center[1],
            0,
        ])

        layout = union(pair, stop_placed)
        layout_bb = bbox(layout)
        if (layout_bb.size[0] > BAMBU_X2D_PLATE_X
                or layout_bb.size[1] > BAMBU_X2D_PLATE_Y):
            raise ValueError(
                f"print layout {layout_bb.size[0]:.1f} x {layout_bb.size[1]:.1f} mm "
                f"exceeds Bambu X2D build plate "
                f"{BAMBU_X2D_PLATE_X} x {BAMBU_X2D_PLATE_Y} mm"
            )
        return layout

    @variant(fn=48)
    def design_spread_out(self):
        # Inspection layout: hood + the two distinct splayed halves
        # (showing the lap joint) + one stop disc per entry in
        # `STOP_HOLE_D`, spaced with a uniform gap and Y-aligned on a
        # shared baseline. Too large for the print bed; use the `print`
        # variant for actual printing.
        minus, plus = self._splayed_halves()
        flipped_hood = self.hood.flip("z")   # wide flare on the print bed
        flat_stops = [
            disc.down(STOP_DEPTH - STOP_THK / 2) for disc in self.stop_discs
        ]
        minus_bb = bbox(minus)
        plus_bb = bbox(plus)
        hood_bb = bbox(flipped_hood)
        flat_bb = bbox(flat_stops[0])   # all discs share the same outer footprint
        gap = self.housing.upper_housing_od   # ~one barrel-diameter of breathing room

        # Place minus on the -X side, plus on the +X side, separated by `gap`.
        minus_placed = minus.left(minus_bb.max[0] + gap / 2)
        plus_placed = plus.right(-plus_bb.min[0] + gap / 2)
        pair = union(minus_placed, plus_placed)
        pair_bb = bbox(pair)

        y_baseline = pair_bb.center[1]

        def place_at_x(node, bb, target_center_x):
            return node.translate([
                target_center_x - bb.center[0],
                y_baseline - bb.center[1],
                0,
            ])

        x_hood = pair_bb.min[0] - gap - hood_bb.size[0] / 2
        disc_pitch = flat_bb.size[0] + gap
        discs_placed = [
            place_at_x(
                flat, flat_bb,
                pair_bb.max[0] + gap + flat_bb.size[0] / 2 + i * disc_pitch,
            )
            for i, flat in enumerate(flat_stops)
        ]

        return union(
            pair,
            place_at_x(flipped_hood, hood_bb, x_hood),
            *discs_placed,
        )

    @variant(fn=48)
    def display(self):
        # Lift the hood one coupler_overlap above the true housing top (which
        # sits above upper_housing_len because of the front fillet ring) so
        # the housing's upper rim is visible between the two parts. The
        # widest-aperture stop disc shows fully inserted at its real depth.
        housing_top_z = bbox(self.housing).max[2]
        gap = self.hood.coupler_overlap
        return union(
            self.housing,
            self.hood.up(housing_top_z + gap),
            self.stop_discs[0],
        )

    @variant(fn=48)
    def testing(self):
        # One splayed half (the -X half, with lap-joint features visible)
        # for inspecting a single shell in isolation.
        minus, _ = self._splayed_halves()
        minus_bb = bbox(minus)
        gap = self.housing.upper_housing_od
        return minus.left(minus_bb.max[0] + gap / 2)


if __name__ == "__main__":
    run()
