"""Bronica S2 lens-mount components.

Two mating bayonet parts:
- `CameraMount` — open tube with three outward-projecting lugs at the
  top rim, matching the actual Bronica S/S2/S2A/EC/EC-TL camera-side
  bayonet pattern (one large lug ~50° wide + two smaller ~40° lugs at
  roughly 120° spacing).
- `LensMount` — the lens-side mating part, built by subtracting the
  swept volume of the camera mount (pressed in then twisted left) from
  a thick tube.

Run:
    python s2-evolving/s2_mount.py

Locking-pin variants live in the sibling `s2_mount_locking.py` module.
"""

import math

from scadwright import Component, bbox
from scadwright.boolops import difference, union
from scadwright.design import Design, run, variant
from scadwright.primitives import circle, polygon
from scadwright.shapes import Arc, Tube


# Bambu X2D buildable area (mm). Layouts must fit within these.
BAMBU_X2D_PLATE_X = 256
BAMBU_X2D_PLATE_Y = 256


class CameraMount(Component):
    """Open tube with a per-lug list of outward-projecting bayonet lugs
    at the top rim.

    `barrel_id` / `wall_thk` / `length` define the open cylindrical body
    (`barrel_od = barrel_id + 2 * wall_thk` is computed). `lug_axial` is
    the axial thickness of each lug; `lugs` is a tuple of
    `(center_deg, width_deg, radial_proj_mm)` triples, one per lug, so
    the bayonet pattern can be asymmetric.
    """

    equations = """
        barrel_id, length, wall_thk, lug_axial > 0
        barrel_od = barrel_id + 2 * wall_thk
        body_or = barrel_od / 2
        lug_axial <= length
        len(lugs:tuple) >= 1
    """

    def build(self):                                       # framework hook: required; returns the shape
        yield Tube(h=self.length, od=self.barrel_od, id=self.barrel_id)
        z_lug_bottom = self.length - self.lug_axial
        # Each lug: an annular sector (Arc) extruded vertically, rotated
        # to its center angle, lifted to the top of the barrel.
        for center_deg, width_deg, proj_mm in self.lugs:
            half = width_deg / 2
            yield (
                Arc(
                    r=self.body_or + proj_mm / 2,
                    width=proj_mm,
                    angles=(center_deg - half, center_deg + half),
                )
                .linear_extrude(height=self.lug_axial)
                .up(z_lug_bottom)
            )


class BronicaS2CameraMount(CameraMount):
    """Concrete mount sized to the Bronica S/S2/EC camera mount.

    Body OD/ID/wall come from the rear-cap STL (60.5 / 56.5 / 2 mm); the
    barrel ID also matches the M57 thread behind the bayonet. The three
    lugs are taken from a flatbed scan of the actual camera mount: one
    larger lug plus two smaller, with center spacing ~120° but a slight
    asymmetry between the small ones. Centers in camera coords: 0° = +X,
    90° = +Y = up toward the BRONICA logo. Widths shrunk 1° from
    measured (undersized lugs still mate, oversized jam).
    """
    barrel_id = 56.5
    wall_thk = 2.0
    length = 20.0
    lug_axial = 1.2   # measured ~1.1 on the camera lug; +0.1 after a test print showed the channel too tight
    lugs = (
        (90.0, 49.0, 1.8),    # large (measured 50°, scan 49.5°)
        (214.75, 39.0, 1.2),  # small (measured 40°, scan 174.25°)
        (324.25, 40.5, 1.2),  # small (measured 41.5°, scan 283.75°)
    )


class LensMount(Component):
    """Lens-side mating part for a `CameraMount`.

    Coordinate convention: z=0 is the bottom face of the tube, z=h is
    the top face — the ENTRY RIM, the side the camera mount is pressed
    into. When fully inserted and rotated, the camera mount's lug-front
    plane sits at z = h - `insertion_depth` (the "rest plane").

    The cutter is the union of three pieces:

    1. BORE cutter (full tube height): a clearance-offset cylinder of
       `cam_barrel_od`. Lets the camera mount's body pass through the
       entire lens mount.
    2. ENTRY LUG CHANNELS (only `insertion_depth` tall, top of tube):
       lug-width arcs at the original lug angles, from the rest plane
       up to the entry rim. Each lug slides down its channel during
       press-in.
    3. ROTATION CHANNEL (only `lug_axial` tall, at the rest plane):
       lug arcs widened by `lock_angle_deg` on the CCW ("left") edge.
       The lug rotates through this channel after entry.

    Material between the rotation channel and the entry rim, at the
    swept angles outside the entry channels, is the bayonet lip —
    it catches each lug after the twist and prevents the mount from
    pulling back out. `clearance` is applied via 2D `offset` around
    each profile.

    Tube blank:
    - OD = `cam_barrel_od + 2*max_lug_proj + 2*wall_thk`
      (i.e. `wall_thk` of wall outside the circle around the lugs)
    - ID = `cam_barrel_id - 2`
    - h  = `h`
    """

    equations = """
        cam_barrel_od, cam_barrel_id, clearance, lock_angle_deg, lug_axial, wall_thk, insertion_depth, protrusion_len, entry_arc_clearance, axial_clearance > 0
        cam_barrel_od > cam_barrel_id
        lug_axial < insertion_depth
        h = protrusion_len + insertion_depth
        max_lug_proj = max(p for c, w, p in lugs:tuple)
        outer_od = cam_barrel_od + 2 * max_lug_proj + 2 * wall_thk
        # `inner_shrink` shrinks the blank's inner diameter (and the bore cut
        # below) by this amount, leaving the OD and channel walls untouched.
        # 0 = the bore matches `cam_barrel_od + 2*clearance`. Bumping it makes
        # the inner cylinder smaller and the cuts go that much deeper inward.
        inner_shrink = 1.0
        inner_id = cam_barrel_id - 2 * wall_thk - inner_shrink
        body_or = cam_barrel_od / 2
        outer_or = outer_od / 2
        rest_z = h - insertion_depth
        # Alignment groove: thin axial recess on the outer wall, centered
        # on the widest lug's center angle.
        groove_depth, groove_width > 0
        widest_w = max(lw for lc, lw, lp in lugs)
        widest_center = [lc for lc, lw, lp in lugs if lw == widest_w][0]
        # Groove ends up at the widest lug's world angle (the BRONICA
        # logo direction) after the lens rotates +lock_angle_deg in
        # camera coords into its locked position; in lens-coords the
        # groove therefore starts at widest_center - lock_angle_deg.
        groove_angle_deg = widest_center - lock_angle_deg
        # Optional inner-tube feature (always computed; only emitted
        # when self.inner_tube is True). `?inner_tube` defaults to False
        # via the override pattern when the caller doesn't supply it.
        ?inner_tube:bool = False if ?inner_tube is None else ?inner_tube
        inner_tube_od = cam_barrel_id - clearance
        inner_tube_id = inner_tube_od - 2 * inner_tube_wall_thk
        inner_tube_h = rest_z + inner_tube_above_flange
        connector_od = cam_barrel_od + 2 * clearance
        inner_tube_id > 0
    """

    def build(self):
        blank = Tube(h=self.h, od=self.outer_od, id=self.inner_id)

        # 1. BORE: clearance-offset cylinder through the entire tube,
        # shrunk inward by `inner_shrink` (in diameter) so the bore cut
        # reaches the new (extended-inward) blank inner edge.
        bore_2d = circle(d=self.cam_barrel_od - self.inner_shrink).offset(r=self.clearance)
        bore_cutter = bore_2d.linear_extrude(height=self.h + 1.0).down(0.5)

        # 2. ENTRY LUG CHANNELS: lug-width arcs at original lug angles,
        # from the rest plane to just past the entry rim. Each entry
        # channel is widened tangentially by `entry_arc_clearance` mm
        # of arc length on EACH side (converted per-lug to degrees by
        # the lug's mid-radius); this only affects the entry channels,
        # not the rotation channels, so the locked fit stays tight while
        # the initial drop-in is forgiving.
        entry_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(
                    c - w / 2 - math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                    c + w / 2 + math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                ),
            )
            for c, w, p in self.lugs
        ]
        entry_lug_2d = union(*entry_arcs).offset(r=self.clearance)
        entry_lug_cutter = (
            entry_lug_2d
            .linear_extrude(height=self.insertion_depth + 0.5)
            .up(self.rest_z)
        )

        # 3. ROTATION CHANNEL: lug arcs widened by lock_angle_deg on
        # the CW edge, lug_axial tall (+ clearance above for fit).
        # The lug front face rests on the bottom of this channel. The
        # CW-edge widening means the LENS rotates CCW in camera coords
        # (CW from the viewer's perspective looking at the camera front)
        # to bring the indicator from its insertion angle (~10:30) into
        # the locked position at 12 o'clock.
        rot_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(c - w / 2 - self.lock_angle_deg, c + w / 2),
            )
            for c, w, p in self.lugs
        ]
        rot_2d = union(*rot_arcs).offset(r=self.clearance)
        rot_cutter = (
            rot_2d
            .linear_extrude(height=self.lug_axial + self.axial_clearance)
            .up(self.rest_z)
        )

        # 4. ALIGNMENT GROOVE: long skinny triangular prism on the outer
        # wall, apex pointing inward, base on the outer surface,
        # extruded the full tube height. Placed so that AFTER the lens
        # rotates into its locked position, the groove ends up aligned
        # with the widest lug's world angle (toward the BRONICA logo).
        groove_2d = polygon(points=[
            (self.outer_or - self.groove_depth, 0.0),       # apex (inward)
            (self.outer_or + 0.1, self.groove_width / 2),    # base +Y (slight overshoot)
            (self.outer_or + 0.1, -self.groove_width / 2),   # base -Y
        ])
        groove_cutter = (
            groove_2d
            .linear_extrude(height=self.h + 1.0)
            .down(0.5)
            .rotate([0, 0, self.groove_angle_deg])
        )

        yield difference(
            blank,
            union(bore_cutter, entry_lug_cutter, rot_cutter, groove_cutter),
        )

        if self.inner_tube:
            # Inner tube: fits inside the camera-mount throat; extends
            # from z=0 (bottom of the outer tube) up past the flange by
            # `inner_tube_above_flange`.
            yield Tube(
                h=self.inner_tube_h,
                od=self.inner_tube_od,
                id=self.inner_tube_id,
            )
            # Connector annulus: bridges the radial gap between the
            # inner tube and the outer tube, from z=0 to the flange.
            yield Tube(
                h=self.rest_z,
                od=self.connector_od,
                id=self.inner_tube_od,
            )


class BronicaS2LensMount(LensMount):
    """Concrete lens mount: lens-specific dimensions. The bayonet
    spec (cam_barrel_od, cam_barrel_id, lugs) is supplied at
    instantiation by reading them off the paired CameraMount instance.
    """

    clearance = 0.20
    # Extra arc-length added to each side of the ENTRY channels (only)
    # so the lugs drop in without fiddling. Rotation channels stay tight.
    entry_arc_clearance = 1.0
    # Axial slop in the rotation channel (channel z-height = lug_axial +
    # axial_clearance). Tightens lens-to-camera wobble independently of
    # the radial `clearance`. Bumped from 0.1 → 0.3 mm after a test print
    # showed the channel too tight: the modeled-PETG support's air gaps
    # (0.1 mm above and below the filler) plus PETG roof sag and rough
    # PETG/PLA boundary surfaces eat into the available headroom, so the
    # nominal 0.1 mm of slop wasn't enough.
    axial_clearance = 0.3
    wall_thk = 2.0
    # Measured by two test fits:
    #   1. With lock_angle_deg=45, the printed indicator at MATING (before
    #      rotation) sat ~7.5 mm CW (viewer frame) of where it should be
    #      relative to the BRONICA logo. Wanted to push the mating-position
    #      mark CCW.
    #   2. First correction lowered lock_angle_deg to 32.4 (the wrong way),
    #      which moved the mating mark CW instead of CCW; on the next test
    #      print it ended up about twice as far in that wrong direction.
    # Net: undo that wrong move AND apply the originally-intended one in
    # the right direction. 7.5 mm at outer_or = 34.05 mm is ~12.6°, so
    # lock_angle_deg = 45 + 12.6 = 57.6. This elongates the rotation
    # channel by 12.6° vs. the original (and 25.2° vs. the wrong-way fix),
    # and (via groove_angle_deg = widest_center - lock_angle_deg) shifts
    # the printed groove CCW in viewer frame so it lands at 12 o'clock
    # when locked.
    lock_angle_deg = 57.6
    # When fully inserted and rotated, the camera-mount lug-front plane
    # sits insertion_depth mm below the entry rim.  This needs to be sufficiently
    # short so that the tube's rim doesn't impinge on teh camera's face
    # when focused to infinity.   4 was very close, but not quite short enough.
    insertion_depth = 3.5
    protrusion_len = 5
    # Inner-tube feature: off by default via the base's override pattern;
    # set `inner_tube=True` at the call site to enable. Sizing values
    # below are used only when emitted.
    inner_tube_wall_thk = 2.0
    inner_tube_above_flange = 16.0
    # Alignment groove on the outer wall, at the widest lug's center.
    groove_depth = 0.3
    groove_width = 0.5
    # No part of the mount may extend more than this distance radially past
    # the OD wall — beyond it the feature collides with the focus collar on
    # the Bronica helicoid (effectively part of the camera body). Measured
    # from the lens-mount tube's outer wall to the inner wall of the focus
    # collar's bore. Any latch / tab / catch must respect this bound.
    max_radial_extension = 9.0


class s2_mount(Design):
    """Camera and lens mount variants. Locking-pin variants live in the
    sibling `s2-mount-locking.py` design module."""

    camera_mount = BronicaS2CameraMount()
    lens_mount = BronicaS2LensMount(
        cam_barrel_od=camera_mount.barrel_od,
        cam_barrel_id=camera_mount.barrel_id,
        lugs=camera_mount.lugs,
        lug_axial=camera_mount.lug_axial,
    )

    @variant(fn=96, default=True)
    def camera(self):
        return _check_plate(self.camera_mount)

    @variant(fn=96)
    def lens(self):
        return _check_plate(self.lens_mount)


def _check_plate(node):
    bb = bbox(node)
    if bb.size[0] > BAMBU_X2D_PLATE_X or bb.size[1] > BAMBU_X2D_PLATE_Y:
        raise ValueError(
            f"print layout {bb.size[0]:.1f} x {bb.size[1]:.1f} mm "
            f"exceeds Bambu X2D build plate "
            f"{BAMBU_X2D_PLATE_X} x {BAMBU_X2D_PLATE_Y} mm"
        )
    return node


if __name__ == "__main__":
    run()
