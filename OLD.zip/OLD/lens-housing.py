"""Lens housing with stacked optical elements and a matching clip-on hood.

Shows the recommended multi-part layout (see
docs/organizing_a_project.md). Generic Components live in the REUSABLE
zone with no project-specific defaults; the specific design for an
M57-throat camera lives in the CONCRETE zone as thin subclasses that
fill in measurements as class attributes.

Run:
    python examples/lens-housing.py                                  # print variant (default)
    scadwright build examples/lens-housing.py --variant=display        # assembled view
    scadwright build examples/lens-housing.py --variant=print          # split + spread for inspection
"""

from collections import namedtuple
from math import radians, tan

from scadwright import Component, Param, bbox
from scadwright.boolops import difference, intersection, union
from scadwright.composition_helpers import mirror_copy
from scadwright.design import Design, run, variant
from scadwright.primitives import circle, cylinder, square
from scadwright.shapes import FilletRing, Funnel, Tube


# =============================================================================
# REUSABLE: generic Components, helpers, value types
# =============================================================================


# spacing is from flange (z=0) to element center; +z = toward object.
# `face_z_top`, `face_z_bot`, `constricted`, `throat_dia_required` are
# precomputed by `element(...)` so the housing's `equations` list can
# reference them as attributes directly.
Element = namedtuple(
    "Element",
    "dia edge_thk spacing face_z_top face_z_bot constricted throat_dia_required",
)


class ElementHolder(Component):
    """Two-sided clamp around one Element, symmetric about the element center."""

    Z_SLOP = 0.5
    DIA_CLEAR = 0.4

    element = Param(Element)
    equations = ["od, grip_depth, grip_width > 0"]

    def build(self):                                       # framework hook: required; returns the shape
        e = self.element
        surround_h = 0.5 * e.edge_thk + self.Z_SLOP
        surround = Tube(h=surround_h, od=self.od, id=e.dia + self.DIA_CLEAR)
        gripper = Tube(
            h=0.5 * self.grip_width,
            od=self.od,
            id=e.dia - self.grip_depth,
        ).attach(surround, fuse=True)
        half = union(surround, gripper).flip("z")
        return mirror_copy(half, normal=[0, 0, 1]).up(e.spacing)


def element(*, dia, edge_thk, spacing, grip_width):
    """Build an `Element` with its computed geometric fields filled in.

    The caller supplies `grip_width` (the holder's per-side gripper
    height) so the housing's equations can reason about each element's
    z-extent through attribute access.
    """
    half = (edge_thk + 2 * grip_width) / 2
    return Element(
        dia=dia, edge_thk=edge_thk, spacing=spacing,
        face_z_top=spacing + half,
        face_z_bot=spacing - half,
        constricted=(spacing - half) < 0,
        throat_dia_required=dia + ElementHolder.DIA_CLEAR,
    )


# A waterhouse stop is a thin disc slid laterally into the lens barrel
# through a side slot to set the aperture. `spacing` is the stop center's
# z-position, `thk` the disc thickness, `clr` the slot's z-clearance.
Stop = namedtuple("Stop", "spacing thk clr")


def stop(*, spacing, thk, clr):
    """Build a `Stop` value for a waterhouse stop."""
    return Stop(spacing=spacing, thk=thk, clr=clr)


class WaterhouseStop(Component):
    """A waterhouse stop disc.

    Viewed face-on, it's a 2D paddle: a smaller semicircle of radius
    `barrel_id`/2 in -Y joined to a larger semicircle of radius
    `barrel_od`/2 in +Y along their flat edges, with a central aperture
    hole of diameter `hole_d`. Extruded by `thk` along the lens axis
    and centered on `spacing`. When inserted, the lower (ID) semicircle
    sits in the bore as the aperture plate; the upper (OD) semicircle
    fills the wall slot, leaving a flush exterior. The hole sits on the
    barrel's axis."""

    equations = [
        "barrel_id, barrel_od, thk, hole_d > 0",
        "barrel_id < barrel_od",
        "hole_d < barrel_id",
    ]
    params = "spacing"

    def build(self):                                       # framework hook: required; returns the shape
        big = self.barrel_od + 2
        upper_mask = square([big, big], center="x")              # Y in [0, big]
        lower_mask = square([big, big], center="x").back(big)    # Y in [-big, 0]
        upper_od = intersection(circle(d=self.barrel_od), upper_mask)
        lower_id = intersection(circle(d=self.barrel_id), lower_mask)
        paddle_2d = difference(union(upper_od, lower_id), circle(d=self.hole_d))
        paddle = paddle_2d.linear_extrude(height=self.thk)
        return paddle.up(self.spacing - self.thk / 2)


class StopHolder(Component):
    """Two-sided clamp around a waterhouse stop, symmetric about the
    stop's z-position. Intruding grippers above and below pinch the
    stop's lower-ID semicircle from outside the slot. The slot in the
    barrel is the disc's pocket — no surround needed here."""

    stop = Param(Stop)
    equations = [
        "od, grip_depth, grip_width, barrel_id > 0",
        "barrel_id > grip_depth",
    ]

    def build(self):                                       # framework hook: required; returns the shape
        s = self.stop
        slot_h = s.thk + s.clr
        gripper = Tube(
            h=0.5 * self.grip_width,
            od=self.od,
            id=self.barrel_id - self.grip_depth,
        ).up(slot_h / 2)
        return mirror_copy(gripper.flip("z"), normal=[0, 0, 1]).up(s.spacing)


def trunc_fillet_ring(*, id, od, base_angle, slant="outwards", rim_width):
    """A `FilletRing` with its sharp apex chopped to a flat rim of
    `rim_width` radial width."""
    if rim_width <= 0:
        raise ValueError("rim_width must be > 0")
    if rim_width >= (od - id) / 2:
        raise ValueError("rim_width must be less than the ring's radial extent")
    # Radial eps: the chopper's outer cylindrical surface sits at d=od, same
    # as the FilletRing's outer wall. through() handles planar-bbox coplanar
    # faces but not cylinder-on-cylinder coincidence, so nudge the chopper
    # outward by a hair.
    eps = 0.01
    base = FilletRing(id=id, od=od, base_angle=base_angle, slant=slant)
    h_full = tan(radians(base_angle)) * (od - id) / 2
    z_t = tan(radians(base_angle)) * ((od - id) / 2 - rim_width)
    chopper = cylinder(h=h_full - z_t, d=od + 2 * eps).up(z_t).through(base, axis="z")
    return difference(base, chopper)


class LensHousing(Component):
    """Generic lens barrel: lower recess + flange + upper housing (narrow
    or funnel-widened) + element holders + front fillet. A matching hood
    Component can read the outer dimensions and hood cone angle off this
    housing to mate without shared scope."""

    FRONT_FILLET_OFFSET = 5.0   # aperture rim inset from the front element's grip ID

    elements = Param(tuple)
    stop = Param(Stop, default=None)
    equations = [
        "lower_housing_od = lower_housing_id + barrel_thk",
        "hood_base_angle = 90 - fov_angle / 2",
        "lower_housing_od, lower_housing_id, lower_housing_len, barrel_thk > 0",
        "flange_flange_od, flange_flange_len, fov_angle, hood_base_angle > 0",
        "grip_depth, grip_width > 0",
        "unconstricted = tuple(e for e in elements if not e.constricted)",
        "max_upper_ele_dia = max((e.dia for e in unconstricted), default=0.0)",
        "is_wide = max_upper_ele_dia > lower_housing_id",
        "expansion_funnel_len = min((e.face_z_bot for e in unconstricted), default=inf)",
        "upper_housing_len = max(e.face_z_top for e in elements)",
        "upper_housing_od = (max_upper_ele_dia + barrel_thk) if is_wide else flange_flange_od",
        "all(not e.constricted or e.throat_dia_required <= lower_housing_id for e in elements)",
        # Stop must lie entirely in a uniform-OD section: either below
        # the flange (z<=0) or above the flange/funnel transition.
        # Funnel transition is currently out of scope.
        (
            "stop is None or "
            "stop.spacing + (stop.thk + stop.clr) / 2 <= 0 or "
            "stop.spacing - (stop.thk + stop.clr) / 2 >= "
            "(expansion_funnel_len if is_wide else flange_flange_len)"
        ),
    ]

    def build(self):
        lower_id = self.lower_housing_id
        upper_id = self.max_upper_ele_dia if self.is_wide else lower_id

        lower = Tube(
            h=self.lower_housing_len, od=self.lower_housing_od, id=lower_id,
        ).down(self.lower_housing_len)

        flange = Tube(
            h=self.flange_flange_len, od=self.flange_flange_od, id=lower_id,
        )

        if self.is_wide:
            funnel_len = self.expansion_funnel_len
            funnel = Funnel(
                h=funnel_len, thk=self.barrel_thk / 2,
                bot_id=lower_id, top_id=self.max_upper_ele_dia,
            )
            upper = Tube(
                h=self.upper_housing_len - funnel_len,
                od=self.max_upper_ele_dia + self.barrel_thk,
                id=self.max_upper_ele_dia,
            ).up(funnel_len)
            barrel = union(lower, flange, funnel, upper)
        else:
            upper = Tube(
                h=self.upper_housing_len, od=self.upper_housing_od, id=lower_id,
            )
            barrel = union(lower, flange, upper)

        # Local barrel OD at the stop's z (shared by slot cut and gripper).
        stop_od = (
            self.lower_housing_od if self.stop is not None and self.stop.spacing < 0
            else self.upper_housing_od
        )

        if self.stop is not None:
            s = self.stop
            slot_h = s.thk + s.clr
            # Slight radial overshoot avoids cylinder-on-cylinder coplanar
            # faces in the difference (through() can't detect those).
            slot = Tube(
                h=slot_h, od=stop_od + 1, id=lower_id - 0.1,
            ).halve([0, 1, 0]).up(s.spacing - slot_h / 2)
            barrel = difference(barrel, slot)

        yield barrel

        for e in self.elements:
            holder_od = lower_id if e.constricted else upper_id
            yield ElementHolder(
                element=e, od=holder_od,
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        if self.stop is not None:
            yield StopHolder(
                stop=self.stop, od=stop_od, barrel_id=lower_id,
                grip_depth=self.grip_depth, grip_width=self.grip_width,
            )

        front_ele_dia = max(self.elements, key=lambda e: e.spacing).dia
        yield trunc_fillet_ring(
            id=front_ele_dia - self.grip_depth + self.FRONT_FILLET_OFFSET,
            od=self.upper_housing_od,
            base_angle=self.hood_base_angle,
            slant="inwards",
            rim_width=2,
        ).attach(upper, fuse=True)


class LensHood(Component):
    """Generic clip-on hood sized by a paired housing. `housing_upper_od`
    and `hood_base_angle` come from the housing; the rest are hood-specific.
    Built in its mounted orientation: coupler at z=0, funnel flaring upward.
    The print variant flips it."""

    equations = [
        "housing_upper_od, hood_base_angle, wall_thk, hood_length, coupler_overlap > 0",
        "hood_clr >= 0",
        "id_coupler = housing_upper_od + hood_clr",
        "od_coupler = id_coupler + 2 * wall_thk",
        "flare_od = housing_upper_od + 2 * hood_length * tan((90 - hood_base_angle) * pi / 180)",
    ]

    def build(self):                                       # framework hook: required; returns the shape
        coupler = Tube(
            h=self.coupler_overlap, id=self.id_coupler, thk=self.wall_thk,
        )
        yield coupler
        yield Funnel(
            h=self.hood_length, thk=self.wall_thk,
            bot_od=self.housing_upper_od, top_od=self.flare_od,
        ).attach(coupler, fuse=True)
        yield FilletRing(
            id=self.id_coupler, od=self.od_coupler,
            base_angle=63, slant="inwards",
        ).attach(coupler, fuse=True)


def half_housing_splay(housing):
    """Cut in half and lay on its side for a section view."""
    return housing.halve([0, -1, 0]).rotate([270, 0, 0])


# =============================================================================
# CONCRETE: the specific M57 design
# =============================================================================


GRIP_DEPTH = 1.5
GRIP_WIDTH = 1.0

# Waterhouse stop: 1mm disc at z=10 (relative to the flange), 0.2mm slot
# clearance for sliding fit, 20mm aperture hole.
STOP_DEPTH = 10.0
STOP_THK = 1.0
STOP_CLR = 0.2
STOP_HOLE_D = 20.0

ELEMENTS = (
    element(dia=40.0, edge_thk=5, spacing=18, grip_width=GRIP_WIDTH),
    element(dia=50.0, edge_thk=2, spacing=-2, grip_width=GRIP_WIDTH),
    element(dia=38.5, edge_thk=2, spacing=-12, grip_width=GRIP_WIDTH),
)
THE_STOP = stop(spacing=STOP_DEPTH, thk=STOP_THK, clr=STOP_CLR)


class M57LensHousing(LensHousing):
    lower_housing_od = 56.0
    lower_housing_len = 14.5
    barrel_thk = 2.0
    flange_flange_od = 59.0
    flange_flange_len = 5.0
    fov_angle = 57.0
    grip_depth = GRIP_DEPTH
    grip_width = GRIP_WIDTH
    elements = ELEMENTS
    stop = THE_STOP


class M57LensHood(LensHood):
    wall_thk = 2.0
    hood_clr = 0.4
    hood_length = 20.0
    coupler_overlap = 6.0


# =============================================================================
# DESIGN: shared parts + variant methods
# =============================================================================


class M57Lens(Design):
    housing = M57LensHousing()
    hood = M57LensHood(
        housing_upper_od=housing.upper_housing_od,
        hood_base_angle=housing.hood_base_angle,
    )
    stop_disc = WaterhouseStop(
        barrel_id=housing.lower_housing_id,
        barrel_od=housing.upper_housing_od,
        thk=STOP_THK,
        hole_d=STOP_HOLE_D,
        spacing=STOP_DEPTH,
    )

    @variant(fn=48, default=True)
    def print(self):
        # Bed-ready layout: two splayed housing halves + the inverted hood,
        # spaced with a uniform gap between adjacent parts and Y-aligned on
        # a shared baseline. The stop disc sits flat to the right.
        half = half_housing_splay(self.housing)
        flipped_hood = self.hood.flip("z")   # wide flare on the print bed
        flat_stop = self.stop_disc.down(STOP_DEPTH - STOP_THK / 2)
        half_bb = bbox(half)
        hood_bb = bbox(flipped_hood)
        stop_bb = bbox(flat_stop)
        gap = self.housing.upper_housing_od   # ~one barrel-diameter of breathing room
        half_w = half_bb.size[0]
        hood_w = hood_bb.size[0]
        y_hood = half_bb.center[1] - hood_bb.center[1]
        y_stop = half_bb.center[1] - stop_bb.center[1]
        return union(
            half,
            half.right(half_w + gap),
            flipped_hood.translate(
                [-(hood_w + half_w) / 2 - gap, y_hood, 0]
            ),
            flat_stop.translate(
                [2 * (half_w + gap), y_stop, 0]
            ),
        )

    @variant(fn=48)
    def display(self):
        # Lift the hood one coupler_overlap above the true housing top (which
        # sits above upper_housing_len because of the front fillet ring) so
        # the housing's upper rim is visible between the two parts. The stop
        # disc shows fully inserted at its real depth.
        housing_top_z = bbox(self.housing).max[2]
        gap = self.hood.coupler_overlap
        return union(
            self.housing,
            self.hood.up(housing_top_z + gap),
            self.stop_disc,
        )


if __name__ == "__main__":
    run()
