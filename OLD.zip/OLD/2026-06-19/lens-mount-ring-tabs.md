# Lens mount ring attachment

The lens mount ring is currently glued to the lens housing — bonded
around the mating disc and against the underside of the flange-flange.
The joint works but is single-use: once the adhesive cures, the ring
can only be separated by destroying the bond.

This note captures two candidate mechanisms for a reversible, tool-light
attachment that still resists the circumferential shear loaded into the
joint when the bayonet engages.

Both options require corresponding changes on the lens-mount-ring side
(`lens_mount_ring.py` for the base ring; `lens_mount_locking_ring.py`
for the locking variant), not just the housing — the ring's bore or OD
has to carry the mating features. Those changes are not detailed here.

---

## Option A — Mini bayonet (quarter-turn lock)

A scaled-down version of the camera's own bayonet, between the housing
and the lens mount ring.

### Geometry

- 2–3 lugs project radially outward from the **mating disc**'s OD, each
  occupying ~20–30° of arc and ~1.0–1.5 mm radial proj.
- 2–3 matching **L-shaped channels** are cut into the lens mount ring's
  bore: an axial insertion slot (matching the lug width) feeding a
  circumferential locking channel that runs ~30° around.
- A shallow detent at the end of each locking channel gives a tactile
  click and resists accidental rotation off.

### Assembly / disassembly

1. Align the lugs with the insertion slots.
2. Push the ring axially onto the disc until the lugs reach the
   circumferential channels.
3. Rotate the ring ~30° to engage.
4. To remove: rotate back, lift off.

No tools; fingers only.

### Properties

- **Shear (circumferential):** strong. Loaded into the lug shanks; lug
  cross-section sets the limit and is easy to dial up.
- **Axial retention:** strong. The locking channel's ceiling prevents
  axial pullout once rotated; only the insertion-slot alignment lets
  the ring off.
- **Orientation:** fixed to one (or N, for N lugs) rotational position.
  Useful for clocking the engraved label upright; mildly annoying if
  the ring should be assemblable at arbitrary angles.
- **Manufacturing:** same printing idiom the camera-side bayonet
  already uses. Highest geometric complexity of the candidates.

---

## Option B — Axial snap tabs with triangular catches

A pair of cantilever tabs hanging axially from the flange-flange's
underside, snapping into matching notches on the lens mount ring.

### Geometry

- **2 tabs**, 180° apart, each centered on its own housing half so the
  lap-split cut plane never crosses a tab.
- Each tab extends **axially from the underside of the flange-flange**
  (z = mount_offset = 5) **back toward the camera** (-z direction). The
  tab tip lands at the same z as the ring's bottom edge — the tab does
  not extend past the ring.
- **Radial position:** outside the mating disc's OD. The lens mount
  ring fills the radial channel between the mating disc (inner) and
  the tabs (outer); the ring's OD slides past the tabs' inner face on
  assembly.
- At each tab's tip is a **catch**: a triangular cross-section with
  ~45° on both faces.
  - The leading 45° face (facing -z) acts as the entry ramp — the
    ring's top edge pushes the tab outward as it slides on.
  - The trailing 45° face (facing +z) is the locking face — engages a
    matching V-groove notch on the ring's OD.
- **Notches** on the ring's OD: shallow V-grooves at the same z as the
  tab tips, sized to match the catch profile. Two notches, 180° apart,
  one per tab.

### Assembly / disassembly

1. Push the ring axially onto the mating disc; the tabs flex outward
   as the ring's top edge rides up the catches' leading ramps.
2. The ring's bottom seats; the catches snap inward into the notches.
3. To remove: pry each tab outward (fingernail or thin screwdriver)
   far enough to release the catch, then slide the ring off.

Tool-free for assembly; minor pry for removal.

### Properties

- **Shear (circumferential):** moderate, less than Option A on its own
  — loaded into the catch-in-notch engagement; the notches are short
  circumferentially, so the contact area is smaller than a bayonet
  lug shank. See the **anti-rotation teeth** addition below, which
  brings shear capacity up to bayonet-class without changing assembly
  UX.
- **Axial retention:** strong. The 45° trailing face on the catch
  bites into the notch's matching face under axial tension — the more
  you pull, the harder the tab locks until it's pried out.
- **Orientation:** the 180° tab pattern gives 2-fold rotational
  alignment (assembleable at 0° or 180°); finer clocking would need
  asymmetric tabs.
- **Manufacturing:** tabs print along z, so the catch's leading (-z)
  ramp is a self-supported 45° overhang. Tab thickness and length tune
  the engagement force and fatigue life across repeated cycles.

### Anti-rotation teeth (clean separation of axial vs rotational
retention)

A pair of short teeth on the **underside of the flange-flange**,
sitting in the radial gap between the mating disc and the snap tabs,
engaging matching axial recesses on the **upper face of the lens
mount ring** (the face that meets the flange-flange when assembled).

- **Count and angular position:** 2 teeth, **coincident with the tabs
  at +X and −X**. Each tooth sits wholly inside its own housing half;
  the X=0 lap-split cut plane never touches a tooth. The +Y / −Y
  placement is rejected because it would bisect each tooth, leaving
  two clipped halves carried by separate housing halves and forcing
  the lap joint to carry torque across its own cut.
- **Geometry:** small rectangular pegs projecting upward from the
  flange-flange's underside, e.g. ~3 × 3 × 2 mm tall. The recesses on
  the ring are a matching slip-fit. Engagement is purely axial —
  teeth seat into recesses as part of the same push-on motion that
  engages the snap tabs.
- **Loading:** the teeth take circumferential shear across their full
  cross-section. Two 3 × 3 mm teeth provide ~9 mm² each (~18 mm²
  total) in shear, comfortably above any reasonable bayonet-release
  torque. The snap tabs no longer have to carry rotational load —
  they only need to transmit axial retention.
- **Assembly / disassembly UX:** unchanged. The teeth enter and exit
  their recesses on the same axial push-and-pry cycle as the tabs.
  No additional rotation or alignment step.

This refinement is the recommended form of Option B.

---

## Why Option B over Option A

The mini bayonet (Option A) creates a **race condition** with the
camera's own bayonet. With bayonets at both interfaces (camera-to-
ring and ring-to-housing), twisting the lens to unlock from the
camera could unlock the ring-to-housing joint instead, depending on
which has less rotational friction. There is no positive lock on the
ring-to-housing side that can decide the contest cleanly, and there's
no way to make the rotational torques predictably different across
print variation and wear.

Option B with the anti-rotation teeth avoids this entirely. The tab-
plus-tooth interface has **no rotational release path** — twist torque
transmits through tooth shear, and the tabs only release under axial
pull. So any lens-removal twist propagates fully through the housing-
to-ring interface and resolves at the camera bayonet, which is the
intended unlock joint.

The remaining shear concern shifts: the question is no longer "is
tab shear strong enough to hold the lens against bayonet engagement
torque" but "is tooth shear strong enough to transmit camera-bayonet
release torque without yielding." The latter is a much easier bar
to clear, and the 18 mm² of tooth cross-section clears it
comfortably.

---

## Open questions

- **Mating-disc fate:** does the disc stay (the tab-plus-tooth approach
  keeps it as the radial-locating feature), or is it absorbed into the
  new mechanism?
- **Rotational clocking:** is fixing the ring's rotational position
  relative to the housing desirable (engraving up-aligned) or undesirable
  (any orientation should work)?
- **Cycle count:** how many assembly/disassembly cycles is the
  attachment expected to survive? Affects tab thickness.
- **Tab vs tooth radial positions:** the tabs sit outside the ring's OD
  and the teeth sit inside between the mating disc and the tabs. Both
  features are at +X/−X. Need to confirm there's enough radial real
  estate at the flange-flange's underside to host both without crowding.
- **Spec ownership:** are the attachment features attributes of the
  camera (live in `BronicaS2Bayonet`), or of the housing/ring design
  (live with the part files)?
