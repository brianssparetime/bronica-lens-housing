"""Bronica S2 lens-mount components.

Two mating bayonet parts:
- `CameraMount` — open tube with three outward-projecting lugs at the
  top rim, matching the actual Bronica S/S2/S2A/EC/EC-TL camera-side
  bayonet pattern (one large lug ~50° wide + two smaller ~40° lugs at
  roughly 120° spacing).
- `LensMount` — the lens-side mating part, built by subtracting the
  swept volume of the camera mount (pressed in then twisted left) from
  a thick tube.

Run:
    python s2-evolving/s2-mount.py
"""

import math

from scadwright import Component, bbox
from scadwright.boolops import difference, union
from scadwright.design import Design, run, variant
from scadwright.primitives import circle, cube, polygon, polyhedron
from scadwright.shapes import Arc, Tube


# Bambu X2D buildable area (mm). Layouts must fit within these.
BAMBU_X2D_PLATE_X = 256
BAMBU_X2D_PLATE_Y = 256


class CameraMount(Component):
    """Open tube with a per-lug list of outward-projecting bayonet lugs
    at the top rim.

    `barrel_id` / `wall_thk` / `length` define the open cylindrical body
    (`barrel_od = barrel_id + 2 * wall_thk` is computed). `lug_axial` is
    the axial thickness of each lug; `lugs` is a tuple of
    `(center_deg, width_deg, radial_proj_mm)` triples, one per lug, so
    the bayonet pattern can be asymmetric.
    """

    equations = """
        barrel_id, length, wall_thk, lug_axial > 0
        barrel_od = barrel_id + 2 * wall_thk
        body_or = barrel_od / 2
        lug_axial <= length
        len(lugs:tuple) >= 1
    """

    def build(self):                                       # framework hook: required; returns the shape
        yield Tube(h=self.length, od=self.barrel_od, id=self.barrel_id)
        z_lug_bottom = self.length - self.lug_axial
        # Each lug: an annular sector (Arc) extruded vertically, rotated
        # to its center angle, lifted to the top of the barrel.
        for center_deg, width_deg, proj_mm in self.lugs:
            half = width_deg / 2
            yield (
                Arc(
                    r=self.body_or + proj_mm / 2,
                    width=proj_mm,
                    angles=(center_deg - half, center_deg + half),
                )
                .linear_extrude(height=self.lug_axial)
                .up(z_lug_bottom)
            )


class BronicaS2CameraMount(CameraMount):
    """Concrete mount sized to the Bronica S/S2/EC camera mount.

    Body OD/ID/wall come from the rear-cap STL (60.5 / 56.5 / 2 mm); the
    barrel ID also matches the M57 thread behind the bayonet. The three
    lugs are taken from a flatbed scan of the actual camera mount: one
    larger lug plus two smaller, with center spacing ~120° but a slight
    asymmetry between the small ones. Centers in camera coords: 0° = +X,
    90° = +Y = up toward the BRONICA logo. Widths shrunk 1° from
    measured (undersized lugs still mate, oversized jam).
    """
    barrel_id = 56.5
    wall_thk = 2.0
    length = 20.0
    lug_axial = 1.2   # measured ~1.1 on the camera lug; +0.1 after a test print showed the channel too tight
    lugs = (
        (90.0, 49.0, 1.8),    # large (measured 50°, scan 49.5°)
        (214.75, 39.0, 1.2),  # small (measured 40°, scan 174.25°)
        (324.25, 40.5, 1.2),  # small (measured 41.5°, scan 283.75°)
    )


class LensMount(Component):
    """Lens-side mating part for a `CameraMount`.

    Coordinate convention: z=0 is the bottom face of the tube, z=h is
    the top face — the ENTRY RIM, the side the camera mount is pressed
    into. When fully inserted and rotated, the camera mount's lug-front
    plane sits at z = h - `insertion_depth` (the "rest plane").

    The cutter is the union of three pieces:

    1. BORE cutter (full tube height): a clearance-offset cylinder of
       `cam_barrel_od`. Lets the camera mount's body pass through the
       entire lens mount.
    2. ENTRY LUG CHANNELS (only `insertion_depth` tall, top of tube):
       lug-width arcs at the original lug angles, from the rest plane
       up to the entry rim. Each lug slides down its channel during
       press-in.
    3. ROTATION CHANNEL (only `lug_axial` tall, at the rest plane):
       lug arcs widened by `lock_angle_deg` on the CCW ("left") edge.
       The lug rotates through this channel after entry.

    Material between the rotation channel and the entry rim, at the
    swept angles outside the entry channels, is the bayonet lip —
    it catches each lug after the twist and prevents the mount from
    pulling back out. `clearance` is applied via 2D `offset` around
    each profile.

    Tube blank:
    - OD = `cam_barrel_od + 2*max_lug_proj + 2*wall_thk`
      (i.e. `wall_thk` of wall outside the circle around the lugs)
    - ID = `cam_barrel_id - 2`
    - h  = `h`
    """

    equations = """
        cam_barrel_od, cam_barrel_id, clearance, lock_angle_deg, lug_axial, wall_thk, insertion_depth, protrusion_len, entry_arc_clearance, axial_clearance > 0
        cam_barrel_od > cam_barrel_id
        lug_axial < insertion_depth
        h = protrusion_len + insertion_depth
        max_lug_proj = max(p for c, w, p in lugs:tuple)
        outer_od = cam_barrel_od + 2 * max_lug_proj + 2 * wall_thk
        inner_id = cam_barrel_id - 2 * wall_thk
        body_or = cam_barrel_od / 2
        outer_or = outer_od / 2
        rest_z = h - insertion_depth
        # Alignment groove: thin axial recess on the outer wall, centered
        # on the widest lug's center angle.
        groove_depth, groove_width > 0
        widest_w = max(lw for lc, lw, lp in lugs)
        widest_center = [lc for lc, lw, lp in lugs if lw == widest_w][0]
        # Groove ends up at the widest lug's world angle (the BRONICA
        # logo direction) after the lens rotates +lock_angle_deg in
        # camera coords into its locked position; in lens-coords the
        # groove therefore starts at widest_center - lock_angle_deg.
        groove_angle_deg = widest_center - lock_angle_deg
        # Optional inner-tube feature (always computed; only emitted
        # when self.inner_tube is True). `?inner_tube` defaults to False
        # via the override pattern when the caller doesn't supply it.
        ?inner_tube:bool = False if ?inner_tube is None else ?inner_tube
        inner_tube_od = cam_barrel_id - clearance
        inner_tube_id = inner_tube_od - 2 * inner_tube_wall_thk
        inner_tube_h = rest_z + inner_tube_above_flange
        connector_od = cam_barrel_od + 2 * clearance
        inner_tube_id > 0
    """

    def build(self):
        blank = Tube(h=self.h, od=self.outer_od, id=self.inner_id)

        # 1. BORE: clearance-offset cylinder through the entire tube.
        bore_2d = circle(d=self.cam_barrel_od).offset(r=self.clearance)
        bore_cutter = bore_2d.linear_extrude(height=self.h + 1.0).down(0.5)

        # 2. ENTRY LUG CHANNELS: lug-width arcs at original lug angles,
        # from the rest plane to just past the entry rim. Each entry
        # channel is widened tangentially by `entry_arc_clearance` mm
        # of arc length on EACH side (converted per-lug to degrees by
        # the lug's mid-radius); this only affects the entry channels,
        # not the rotation channels, so the locked fit stays tight while
        # the initial drop-in is forgiving.
        entry_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(
                    c - w / 2 - math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                    c + w / 2 + math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                ),
            )
            for c, w, p in self.lugs
        ]
        entry_lug_2d = union(*entry_arcs).offset(r=self.clearance)
        entry_lug_cutter = (
            entry_lug_2d
            .linear_extrude(height=self.insertion_depth + 0.5)
            .up(self.rest_z)
        )

        # 3. ROTATION CHANNEL: lug arcs widened by lock_angle_deg on
        # the CW edge, lug_axial tall (+ clearance above for fit).
        # The lug front face rests on the bottom of this channel. The
        # CW-edge widening means the LENS rotates CCW in camera coords
        # (CW from the viewer's perspective looking at the camera front)
        # to bring the indicator from its insertion angle (~10:30) into
        # the locked position at 12 o'clock.
        rot_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(c - w / 2 - self.lock_angle_deg, c + w / 2),
            )
            for c, w, p in self.lugs
        ]
        rot_2d = union(*rot_arcs).offset(r=self.clearance)
        rot_cutter = (
            rot_2d
            .linear_extrude(height=self.lug_axial + self.axial_clearance)
            .up(self.rest_z)
        )

        # 4. ALIGNMENT GROOVE: long skinny triangular prism on the outer
        # wall, apex pointing inward, base on the outer surface,
        # extruded the full tube height. Placed so that AFTER the lens
        # rotates into its locked position, the groove ends up aligned
        # with the widest lug's world angle (toward the BRONICA logo).
        groove_2d = polygon(points=[
            (self.outer_or - self.groove_depth, 0.0),       # apex (inward)
            (self.outer_or + 0.1, self.groove_width / 2),    # base +Y (slight overshoot)
            (self.outer_or + 0.1, -self.groove_width / 2),   # base -Y
        ])
        groove_cutter = (
            groove_2d
            .linear_extrude(height=self.h + 1.0)
            .down(0.5)
            .rotate([0, 0, self.groove_angle_deg])
        )

        yield difference(
            blank,
            union(bore_cutter, entry_lug_cutter, rot_cutter, groove_cutter),
        )

        if self.inner_tube:
            # Inner tube: fits inside the camera-mount throat; extends
            # from z=0 (bottom of the outer tube) up past the flange by
            # `inner_tube_above_flange`.
            yield Tube(
                h=self.inner_tube_h,
                od=self.inner_tube_od,
                id=self.inner_tube_id,
            )
            # Connector annulus: bridges the radial gap between the
            # inner tube and the outer tube, from z=0 to the flange.
            yield Tube(
                h=self.rest_z,
                od=self.connector_od,
                id=self.inner_tube_od,
            )


class LensMountLocking(LensMount):
    """`LensMount` plus an integral cantilever flex-tab latch.

    Anchored at the entry rim's outer-upper corner (no projection above
    z=h, so the camera body doesn't foul). A thin flex zone runs from the
    rim down to just above the rotation channel; below it, a thicker
    rigid section carries the tooth (in the channel) and a grip (near
    z=0). User pulls the grip outward; the flex zone bends like a
    see-saw pivot; the tooth retracts radially out of the channel.

    Tooth has two ramped faces (CW and TOP) for auto-latch on insertion
    and rotation, and one vertical CCW face that blocks unmount rotation.
    Latch position: just CW of the largest lug's CW edge after locking
    (user-LEFT of the BRONICA logo, viewed from the lens side).
    """

    # Latch dimensions as class attributes (override on a subclass or pass at construction).
    flex_thk = 0.3            # thin flexure zone radial thickness (mm)
    flex_length = 2.8         # axial extent of flex zone, anchored at the rim (mm)
    body_thk = 1.0            # rigid carrier section radial thickness (mm)
    tab_width = 5.0           # tangential width of the tab (mm)
    tab_below_channel = 4.0   # how far below rest_z the rigid section extends (mm)
    tooth_angular_width_deg = 5.0
    tooth_clearance_from_lug_deg = 0.5
    tooth_radial_depth = 3.0  # tooth projects this far inward from OD (mm)
    tooth_top_ramp_deg = 35.0
    tooth_cw_ramp_deg = 30.0
    grip_outward = 4.0        # grip projects this far past the body's outer face (mm)
    grip_axial_height = 2.5   # grip block axial height (mm)

    def build(self):
        # Locked-position CW edge of the largest lug (lens-frame coords),
        # and the tooth's angular center: just CW of that with a small clearance.
        widest_w = max(w for c, w, p in self.lugs)
        widest_center = next(c for c, w, p in self.lugs if w == widest_w)
        lug_cw_edge_lens_deg = widest_center - self.lock_angle_deg + widest_w / 2
        tooth_cw_center_deg = (
            lug_cw_edge_lens_deg
            + self.tooth_clearance_from_lug_deg
            + self.tooth_angular_width_deg / 2
        )

        # Pocket through the OD wall at the latch angle, sized to admit the tooth.
        pocket_width = self.tooth_angular_width_deg + 2.0  # angular clearance each side
        max_lug_proj_local = max(p for c, w, p in self.lugs)
        pocket_radial_depth = self.outer_or - (self.body_or + max_lug_proj_local / 2 + self.clearance)
        pocket_arc = Arc(
            r=self.outer_or - pocket_radial_depth / 2,
            width=pocket_radial_depth + 0.2,  # tiny radial overshoot so the cut breaks through cleanly
            angles=(
                tooth_cw_center_deg - pocket_width / 2,
                tooth_cw_center_deg + pocket_width / 2,
            ),
        )
        pocket_cutter = (
            pocket_arc
            .linear_extrude(height=self.lug_axial + self.axial_clearance + 0.4)
            .up(self.rest_z - 0.2)
        )

        # Same cutters as base LensMount (re-derived because we add the pocket to the cutter union).
        blank = Tube(h=self.h, od=self.outer_od, id=self.inner_id)
        bore_2d = circle(d=self.cam_barrel_od).offset(r=self.clearance)
        bore_cutter = bore_2d.linear_extrude(height=self.h + 1.0).down(0.5)

        entry_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(
                    c - w / 2 - math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                    c + w / 2 + math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                ),
            )
            for c, w, p in self.lugs
        ]
        entry_lug_2d = union(*entry_arcs).offset(r=self.clearance)
        entry_lug_cutter = (
            entry_lug_2d
            .linear_extrude(height=self.insertion_depth + 0.5)
            .up(self.rest_z)
        )

        rot_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(c - w / 2 - self.lock_angle_deg, c + w / 2),
            )
            for c, w, p in self.lugs
        ]
        rot_2d = union(*rot_arcs).offset(r=self.clearance)
        rot_cutter = (
            rot_2d
            .linear_extrude(height=self.lug_axial + self.axial_clearance)
            .up(self.rest_z)
        )

        groove_2d = polygon(points=[
            (self.outer_or - self.groove_depth, 0.0),
            (self.outer_or + 0.1, self.groove_width / 2),
            (self.outer_or + 0.1, -self.groove_width / 2),
        ])
        groove_cutter = (
            groove_2d
            .linear_extrude(height=self.h + 1.0)
            .down(0.5)
            .rotate([0, 0, self.groove_angle_deg])
        )

        yield difference(
            blank,
            union(bore_cutter, entry_lug_cutter, rot_cutter, groove_cutter, pocket_cutter),
        )

        # Latch tab: built at theta=0 (tab axis along +X), then rotated to tooth_cw_center_deg.
        yield self._build_latch().rotate([0, 0, tooth_cw_center_deg])

        # Inner-tube feature, identical to base.
        if self.inner_tube:
            yield Tube(h=self.inner_tube_h, od=self.inner_tube_od, id=self.inner_tube_id)
            yield Tube(h=self.rest_z, od=self.connector_od, id=self.inner_tube_od)

    def _build_latch(self):
        # Local frame (before the angular rotate): +X = radial out, +Z = axial up.
        # The tab is symmetric about the X-Z plane; tab_width is along Y.
        flex_top_z = self.h
        flex_bot_z = self.h - self.flex_length
        body_top_z = flex_bot_z
        body_bot_z = self.rest_z - self.tab_below_channel
        tooth_z_bot = self.rest_z
        tooth_z_top = self.rest_z + self.lug_axial

        # Flex zone: thin slab against the OD, just below the rim.
        flex = (
            cube([self.flex_thk, self.tab_width, self.flex_length], center="y")
            .right(self.outer_or)
            .up(flex_bot_z)
        )

        # Rigid carrier section: thicker slab from below the flex zone down to the grip.
        body_height = body_top_z - body_bot_z
        body = (
            cube([self.body_thk, self.tab_width, body_height], center="y")
            .right(self.outer_or)
            .up(body_bot_z)
        )

        # Tooth: wedge-shaped polyhedron with vertical CCW face and ramped CW + TOP faces.
        # Local tooth coords: x = radial, y = tangential, z = axial.
        # Tooth radial range: [outer_or - tooth_radial_depth, outer_or].
        # Tooth axial range: [tooth_z_bot, tooth_z_top].
        # Tangential extent: derived from tooth_angular_width_deg at the OD radius.
        ang_half = self.tooth_angular_width_deg / 2
        # Convert angular width at the OD into a tangential half-width in mm.
        y_half_at_od = self.outer_or * math.tan(math.radians(ang_half))
        # CCW face is the -Y face; CW face is the +Y face. Ramp the CW face so its
        # outer corner sits at higher +Y than its inner corner (auto-latch on mount).
        y_ramp_cw = self.tooth_radial_depth * math.tan(math.radians(self.tooth_cw_ramp_deg))
        # Top face ramp: outer corner sits at higher +Z than its inner corner
        # (lug pushes it outward when descending into the channel).
        z_ramp_top = self.tooth_radial_depth * math.tan(math.radians(self.tooth_top_ramp_deg))

        x_inner = self.outer_or - self.tooth_radial_depth
        x_outer = self.outer_or + 0.01  # slight overshoot into the body slab for a clean union
        y_ccw_outer = -y_half_at_od
        y_ccw_inner = -y_half_at_od  # CCW face is vertical: same Y at inner & outer
        y_cw_outer = +y_half_at_od
        y_cw_inner = +y_half_at_od - y_ramp_cw  # CW face ramped: inner corner pulled toward CCW
        z_top_outer = tooth_z_top
        z_top_inner = tooth_z_top - z_ramp_top  # TOP face ramped: inner corner pulled down
        z_bot = tooth_z_bot

        # 8 vertices, ordered: 0..3 = bottom face (CCW from +X,+Y view), 4..7 = top face.
        # Indexing:
        #   0: inner-CCW-bot, 1: outer-CCW-bot, 2: outer-CW-bot, 3: inner-CW-bot
        #   4: inner-CCW-top, 5: outer-CCW-top, 6: outer-CW-top, 7: inner-CW-top
        # Note y_cw_inner < y_cw_outer (CW ramp), z_top_inner < z_top_outer (TOP ramp).
        verts = [
            (x_inner, y_ccw_inner, z_bot),
            (x_outer, y_ccw_outer, z_bot),
            (x_outer, y_cw_outer,  z_bot),
            (x_inner, y_cw_inner,  z_bot),
            (x_inner, y_ccw_inner, z_top_inner),
            (x_outer, y_ccw_outer, z_top_outer),
            (x_outer, y_cw_outer,  z_top_outer),
            (x_inner, y_cw_inner,  z_top_inner),
        ]
        # Faces (CCW outward winding when viewed from outside):
        faces = [
            [0, 3, 2, 1],     # bottom (-Z normal)
            [4, 5, 6, 7],     # top (+Z normal, ramped)
            [0, 1, 5, 4],     # CCW face (-Y normal, vertical)
            [2, 3, 7, 6],     # CW face (+Y normal, ramped)
            [1, 2, 6, 5],     # outer face (+X normal)
            [0, 4, 7, 3],     # inner face (-X normal)
        ]
        tooth = polyhedron(points=verts, faces=faces, convexity=2)

        # Grip: outward kink at the free end of the body, slightly wider tangentially for thumb purchase.
        grip = (
            cube([self.grip_outward, self.tab_width + 1.5, self.grip_axial_height], center="y")
            .right(self.outer_or + self.body_thk)
            .up(body_bot_z)
        )

        return union(flex, body, tooth, grip)


class BronicaS2LensMount(LensMount):
    """Concrete lens mount: lens-specific dimensions. The bayonet
    spec (cam_barrel_od, cam_barrel_id, lugs) is supplied at
    instantiation by reading them off the paired CameraMount instance.
    """

    clearance = 0.20
    # Extra arc-length added to each side of the ENTRY channels (only)
    # so the lugs drop in without fiddling. Rotation channels stay tight.
    entry_arc_clearance = 1.0
    # Axial slop in the rotation channel (channel z-height = lug_axial +
    # axial_clearance). Tightens lens-to-camera wobble independently of
    # the radial `clearance`.
    axial_clearance = 0.1
    wall_thk = 2.0
    # Measured by two test fits:
    #   1. With lock_angle_deg=45, the printed indicator at MATING (before
    #      rotation) sat ~7.5 mm CW (viewer frame) of where it should be
    #      relative to the BRONICA logo. Wanted to push the mating-position
    #      mark CCW.
    #   2. First correction lowered lock_angle_deg to 32.4 (the wrong way),
    #      which moved the mating mark CW instead of CCW; on the next test
    #      print it ended up about twice as far in that wrong direction.
    # Net: undo that wrong move AND apply the originally-intended one in
    # the right direction. 7.5 mm at outer_or = 34.05 mm is ~12.6°, so
    # lock_angle_deg = 45 + 12.6 = 57.6. This elongates the rotation
    # channel by 12.6° vs. the original (and 25.2° vs. the wrong-way fix),
    # and (via groove_angle_deg = widest_center - lock_angle_deg) shifts
    # the printed groove CCW in viewer frame so it lands at 12 o'clock
    # when locked.
    lock_angle_deg = 57.6
    # When fully inserted and rotated, the camera-mount lug-front plane
    # sits 4.2 mm below the entry rim.
    insertion_depth = 4
    protrusion_len = 5
    # Inner-tube feature: off by default via the base's override pattern;
    # set `inner_tube=True` at the call site to enable. Sizing values
    # below are used only when emitted.
    inner_tube_wall_thk = 2.0
    inner_tube_above_flange = 16.0
    # Alignment groove on the outer wall, at the widest lug's center.
    groove_depth = 0.3
    groove_width = 0.5


class BronicaS2LensMountLocking(LensMountLocking, BronicaS2LensMount):
    """Bronica S2 lens mount with the integral cantilever latch.

    Inherits all mating-fit values from `BronicaS2LensMount`; overrides
    nothing by default. Latch dimensions come from `LensMountLocking`'s
    defaults (tuned for PLA/PETG at the S2's 68 mm OD); subclass or pass
    overrides at construction to retune.
    """


class s2_mount(Design):
    camera_mount = BronicaS2CameraMount()
    lens_mount = BronicaS2LensMount(
        cam_barrel_od=camera_mount.barrel_od,
        cam_barrel_id=camera_mount.barrel_id,
        lugs=camera_mount.lugs,
        lug_axial=camera_mount.lug_axial,
    )
    lens_mount_locking = BronicaS2LensMountLocking(
        cam_barrel_od=camera_mount.barrel_od,
        cam_barrel_id=camera_mount.barrel_id,
        lugs=camera_mount.lugs,
        lug_axial=camera_mount.lug_axial,
    )

    @variant(fn=96, default=True)
    def camera(self):
        return _check_plate(self.camera_mount)

    @variant(fn=96)
    def lens(self):
        return _check_plate(self.lens_mount)

    @variant(fn=96)
    def lens_locking(self):
        return _check_plate(self.lens_mount_locking)


def _check_plate(node):
    bb = bbox(node)
    if bb.size[0] > BAMBU_X2D_PLATE_X or bb.size[1] > BAMBU_X2D_PLATE_Y:
        raise ValueError(
            f"print layout {bb.size[0]:.1f} x {bb.size[1]:.1f} mm "
            f"exceeds Bambu X2D build plate "
            f"{BAMBU_X2D_PLATE_X} x {BAMBU_X2D_PLATE_Y} mm"
        )
    return node


if __name__ == "__main__":
    run()
