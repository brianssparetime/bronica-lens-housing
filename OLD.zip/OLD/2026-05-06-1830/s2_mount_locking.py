"""Bronica S2 lens-mount LOCKING designs.

Pairs with `s2_mount.py` (the base CameraMount + LensMount). This module
adds locking mechanisms to the lens mount — currently a passive drop-in
pin, with a flex-tab latch design preserved as commented-out reference.

Run:
    python s2-evolving/s2_mount_locking.py
"""

import math

from scadwright import bbox
from scadwright.boolops import difference, union
from scadwright.design import Design, run, variant
from scadwright.primitives import circle, cube, polygon, polyhedron, square
from scadwright.shapes import Arc, Tube

from s2_mount import (
    BronicaS2CameraMount,
    BronicaS2LensMount,
    CameraMount,
    LensMount,
)


# Bambu X2D buildable area (mm). Layouts must fit within these.
BAMBU_X2D_PLATE_X = 256
BAMBU_X2D_PLATE_Y = 256


# ============================================================================
# OLD DESIGN — flex-tab latch with tangentially rocking lever arm + tooth.
# Disabled: this design depended on an over-long tooth ramp and a weak axial
# pivot. Kept here for reference while we iterate on the pin-drop design below.
# ============================================================================
_OLD_FLEX_TAB_LATCH_DESIGN = r'''
class LensMountLocking(LensMount):
    """`LensMount` plus an integral tangentially-rocking flex-tab latch.

    Vocabulary (used throughout this class):
      - TOOTH      : the wedge that descends through a pocket in the OD wall
                     into the rotation channel and impinges the lug.
      - LEVER ARM (C): the curved rigid body running tangentially along the OD,
                     connecting the flex pivot at one end to the tab at the
                     other; carries the tooth somewhere along its length.
      - PIVOT (flex zone): the thin annular sector at the LEVER ARM's CW end
                     anchoring it to the OD wall; bends to let the lever rock.
      - TAB (B)    : the user-actuated lug at the LEVER ARM's CCW end. Sticks
                     OUT radially from the lever arm so the user can grab it
                     and pull radially outward to retract the tooth.
      - FINGER CATCH (A): a small overhang at the TAB's outer-radial end,
                     extending tangentially (away from the tooth), giving the
                     fingertip something to hook on for pulling.

    Mechanism: the PIVOT sits on the entry-notch side of the TOOTH (HIGHER
    theta in lens-frame), the LEVER ARM extends CCW (in the lock-rotation
    direction) past the TOOTH, and the TAB is at the LEVER ARM's far CCW end.
    The lug's unmount push on the TOOTH's CCW face creates a moment about the
    PIVOT that drives the TOOTH radially INWARD (jams). The user's outward
    pull on the TAB creates the opposite moment → TOOTH retracts.

    The TOOTH is a chisel: ONE ramp on its CCW face (the side facing the
    entrance channel, where the lug approaches from during lock rotation). The
    ramp is sloped in the radial direction so the OUTER (lever-arm side) of the
    face is at full CCW extent and the INNER (deep-in-channel side) is pulled
    toward CW. Lug pushing this slope tangentially during lock rotation gets
    redirected with a radial-OUTWARD component on the tooth, plus the residual
    tangential force creates a CCW moment about the PIVOT — body rotates, tooth
    retracts, lug clears. The CW face (lock-side) stays vertical so the lug's
    unmount push hits a flat wall and creates a CW moment about the pivot,
    driving the tooth radially INWARD (jams).

    Note: the TOOTH does not interact with the lug during axial insertion. The
    tooth's angular position (just CW of the locked lug) is OUTSIDE the lug's
    initial angular range (the entry-notch arc), so the lug descends past the
    tooth without touching it. Tooth-lug contact only happens during the
    rotational phase.
    """

    # PIVOT (flex zone) dimensions and LEVER ARM CLEARANCE
    # The LEVER ARM is offset radially OUTWARD from the OD wall by lever_clearance,
    # so the slicer doesn't fuse them and so the lever arm can rock freely. The
    # FLEX zone fills this radial gap at the pivot azimuth — that single bridge
    # is the ONLY connection between the LEVER ARM and the OD.
    lever_clearance = 0.6     # radial gap between OD and LEVER ARM (mm) — must be
                              # ≥ ~0.5 mm so the slicer doesn't bridge the gap with
                              # a single perimeter and fuse them
    flex_arc_deg = 6.0        # angular extent of the flex zone (deg). This is
                              # the bending dimension of the pivot hinge —
                              # wider here means a stiffer pivot, less likely
                              # to over-flex and yield under repeated tab
                              # presses.
    # LEVER ARM (C) dimensions
    body_thk = 1.2            # radial thickness of the lever arm (mm)
    body_arc_deg = 18.0       # angular extent of lever arm from pivot to tab (deg)
    body_axial = 4.5          # axial height of the lever arm and tooth slab (mm)
    # TOOTH dimensions
    tooth_angular_width_deg = 5.0
    tooth_clearance_from_lug_deg = 0.5
    tooth_radial_depth = 4.1  # tooth projects this far INWARD from the lever arm's
                              # inner face (lever_inner_r). Sized to block ~75-80%
                              # of the rotation channel's radial depth — at the S2
                              # default this puts the tooth's inner face ~0.1 mm
                              # outboard of the camera-barrel clearance bore, so
                              # the tooth doesn't foul the camera barrel.
    tooth_ramp_deg = 35.0     # angle of the CCW-face ramp from vertical: how
                              # much the inner edge of the CCW face is pulled
                              # toward CW (small angle = nearly vertical face,
                              # large angle = strongly inclined face)
    tooth_axial_clearance = 0.3  # axial gap between the tooth and the channel
                              # walls on EACH side (top and bottom). At 0.3 mm
                              # the slicer can fit at least one PETG support
                              # layer above and below the tooth, preventing
                              # fusion with the tube during print and giving
                              # the tooth room to print supported.
    # TAB (B) dimensions — TAB is a flat radial paddle extending RADIALLY OUTWARD
    # from the lever arm's CCW endcap. It abuts the lever arm's CCW endcap face
    # (which is a tangential face) over the full axial × radial extent of the lever
    # arm; axial dimension matches body_axial. Long dimension is RADIAL; thin in
    # the tangential direction. Sized to stay within `max_radial_extension` past
    # the OD when combined with the FINGER CATCH (checked at construction).
    tab_radial_extent = 4.0    # how far the tab sticks out beyond the OD wall (mm)
    tab_tangential_width = 1.5 # thin tangential dimension (mm)
    # FINGER CATCH (A) dimensions — small overhang at the TAB's outer-radial end,
    # extending TANGENTIALLY (along the OD's tangent, away from the tooth) so the
    # user's fingertip has something to hook against. Same axial height as the
    # TAB and lever arm. Sized to stay within `max_radial_extension` past the OD
    # at its outer-tangential corner (checked at construction).
    finger_catch_extent = 2.5  # how far the catch extends tangentially past the TAB (mm)
    finger_catch_thk = 1.5    # radial thickness of the catch (mm)

    def _tooth_and_pivot_angles(self):
        """Compute (tooth_center_deg, pivot_center_deg) in lens-frame.

        The tooth sits inside the largest lug's ENTRANCE CHANNEL (not the
        rotation channel). Anchor: the lug's MATING-position CW edge — i.e.
        the tangential boundary between the rotation channel (CW of it) and
        the entry channel (CCW of it). The tooth's CW face is offset CCW from
        that edge by `tooth_clearance_from_lug_deg`, so the tooth lives just
        inside the entry channel. After full lock rotation the lug has swept
        out of the entry channel and the tooth, released, drops into the
        empty notch. To unmount, the operator pushes the tab to retract the
        tooth before rotating CCW.
        """
        widest_w = max(w for c, w, p in self.lugs)
        widest_center = next(c for c, w, p in self.lugs if w == widest_w)
        lug_mating_cw_edge_lens_deg = widest_center - widest_w / 2
        tooth_center_deg = (
            lug_mating_cw_edge_lens_deg
            + self.tooth_clearance_from_lug_deg
            + self.tooth_angular_width_deg / 2
        )
        pivot_offset_deg = self.body_arc_deg - self.tooth_angular_width_deg / 2
        pivot_center_deg = tooth_center_deg + pivot_offset_deg
        return tooth_center_deg, pivot_center_deg

    def build(self):
        # Constraint: latch's furthest-from-axis point (the FINGER CATCH outer-
        # tangential corner) must stay within `max_radial_extension` past the OD,
        # else it hits the focus collar on the Bronica helicoid. Checked at
        # construction so we get a clear error before any geometry is built.
        # `max_radial_extension` is inherited from the concrete subclass (e.g.
        # BronicaS2LensMount); skip the check if it isn't set.
        max_radial_ext = getattr(self, "max_radial_extension", None)
        if max_radial_ext is not None:
            corner_x = self.outer_or + self.lever_clearance + self.tab_radial_extent
            corner_y = self.tab_tangential_width + self.finger_catch_extent
            corner_radius = math.sqrt(corner_x ** 2 + corner_y ** 2)
            max_allowed_radius = self.outer_or + max_radial_ext
            if corner_radius > max_allowed_radius:
                raise ValueError(
                    f"latch corner reaches radius {corner_radius:.2f} mm, "
                    f"exceeds max allowed {max_allowed_radius:.2f} mm "
                    f"(OD {self.outer_or:.2f} + max_radial_extension "
                    f"{max_radial_ext:.2f}); reduce tab_radial_extent "
                    f"({self.tab_radial_extent}) and/or finger_catch_extent "
                    f"({self.finger_catch_extent})"
                )

        # Tooth placement: at the LEVER ARM's CCW endcap (under the TAB), with
        # the tooth's CCW edge aligned with the lever arm's CCW endcap so the
        # tooth is fully covered by the lever arm. This puts the tooth at the
        # FAR end of the lever arm from the pivot — maximizing the lever ratio
        # so a small pivot bend gives the largest tooth retraction (minimizes
        # required pivot travel, which is the weakest part of the design).
        # Pivot is on the entry-notch side of the tooth (HIGHER theta). Lever
        # arm extends CCW (toward LOWER theta, the lock direction). TAB is at
        # the CCW end of the lever arm.
        tooth_center_deg, pivot_center_deg = self._tooth_and_pivot_angles()
        grip_center_deg = pivot_center_deg - self.body_arc_deg

        # Pocket through the OD wall at tooth's angular position. Pocket has
        # angular clearance on both sides of the tooth so the tooth can swing
        # through it during release without hitting uncut OD material.
        pocket_angular_width = self.tooth_angular_width_deg + 4.0
        max_lug_proj_local = max(p for c, w, p in self.lugs)
        pocket_radial_depth = self.outer_or - (self.body_or + max_lug_proj_local / 2 + self.clearance)
        pocket_arc = Arc(
            r=self.outer_or - pocket_radial_depth / 2,
            width=pocket_radial_depth + 0.2,
            angles=(
                tooth_center_deg - pocket_angular_width / 2,
                tooth_center_deg + pocket_angular_width / 2,
            ),
        )
        pocket_cutter = (
            pocket_arc
            .linear_extrude(height=self.lug_axial + self.axial_clearance + 0.4)
            .up(self.rest_z - 0.2)
        )

        # Same cutters as base LensMount.
        blank = Tube(h=self.h, od=self.outer_od, id=self.inner_id)
        bore_2d = circle(d=self.cam_barrel_od).offset(r=self.clearance)
        bore_cutter = bore_2d.linear_extrude(height=self.h + 1.0).down(0.5)

        entry_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(
                    c - w / 2 - math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                    c + w / 2 + math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                ),
            )
            for c, w, p in self.lugs
        ]
        entry_lug_cutter = (
            union(*entry_arcs).offset(r=self.clearance)
            .linear_extrude(height=self.insertion_depth + 0.5)
            .up(self.rest_z)
        )

        rot_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(c - w / 2 - self.lock_angle_deg, c + w / 2),
            )
            for c, w, p in self.lugs
        ]
        rot_cutter = (
            union(*rot_arcs).offset(r=self.clearance)
            .linear_extrude(height=self.lug_axial + self.axial_clearance)
            .up(self.rest_z)
        )

        groove_2d = polygon(points=[
            (self.outer_or - self.groove_depth, 0.0),
            (self.outer_or + 0.1, self.groove_width / 2),
            (self.outer_or + 0.1, -self.groove_width / 2),
        ])
        groove_cutter = (
            groove_2d.linear_extrude(height=self.h + 1.0).down(0.5)
            .rotate([0, 0, self.groove_angle_deg])
        )

        yield difference(
            blank,
            union(bore_cutter, entry_lug_cutter, rot_cutter, groove_cutter, pocket_cutter),
        )

        # Latch: build with the pivot at azimuth=0 (along +X), body extending
        # in the −Y direction (which becomes CCW in lens-frame after rotation
        # to pivot_center_deg). Then rotate the assembly to pivot_center_deg.
        yield self._build_latch(tooth_center_deg, pivot_center_deg).rotate(
            [0, 0, pivot_center_deg]
        )

        # Inner-tube feature, identical to base.
        if self.inner_tube:
            yield Tube(h=self.inner_tube_h, od=self.inner_tube_od, id=self.inner_tube_id)
            yield Tube(h=self.rest_z, od=self.connector_od, id=self.inner_tube_od)

    def _build_latch(self, tooth_center_deg, pivot_center_deg):
        # Latch-local frame: PIVOT at azimuth=0 (along +X), at the very CW end of
        # the LEVER ARM. LEVER ARM extends from the pivot in the −azimuth direction
        # (CCW = lock direction in user/operator view) to the TAB at azimuth=
        # −body_arc_deg. Nothing extends past the pivot in the CW direction (so
        # the lever arm can't block its own motion).
        #
        # The LEVER ARM is OFFSET radially outward from the OD by lever_clearance,
        # leaving a clearance GAP that prevents the slicer from fusing them and lets
        # the lever rock freely. The FLEX zone is the ONLY connection between the
        # LEVER ARM and the OD: it sits in the gap at the pivot azimuth, anchored
        # to the OD on its inner face and to the LEVER ARM on its outer face.
        z_bot = self.rest_z - (self.body_axial - self.lug_axial) / 2
        tooth_local_az = tooth_center_deg - pivot_center_deg
        tooth_arc_mm_at_outer = (
            self.tooth_angular_width_deg * math.pi / 180.0 * self.outer_or
        )

        # Lever-arm radial range — offset outward from OD by lever_clearance.
        lever_inner_r = self.outer_or + self.lever_clearance
        lever_outer_r = lever_inner_r + self.body_thk

        # PIVOT (FLEX zone) — bridges the radial gap. Inner face overlaps
        # INTO the OD wall by `fuse_eps` (so the union with the lens-mount
        # blank merges into one connected manifold, not face-touching pieces).
        # Outer face overlaps slightly into the LEVER ARM. Tangentially extends
        # from a small overlap (-flex_overlap_deg) into the LEVER ARM's CW end,
        # out to +flex_arc_deg in the CW direction past the pivot.
        fuse_eps = 0.1  # volume-overlap epsilon for clean STL unions
        flex_overlap_deg = 0.5
        flex_radial_overlap = 0.2
        flex_inner_r = self.outer_or - fuse_eps                    # extends INTO OD wall
        flex_outer_r = self.outer_or + self.lever_clearance + flex_radial_overlap
        flex = (
            Arc(
                r=(flex_inner_r + flex_outer_r) / 2,
                width=flex_outer_r - flex_inner_r,
                angles=(-flex_overlap_deg, self.flex_arc_deg),
            )
            .linear_extrude(height=self.body_axial)
            .up(z_bot)
        )

        # LEVER ARM (C) — curved rigid annular sector OFFSET from the OD by
        # lever_clearance. Tangentially from -body_arc_deg (TAB end) to 0 (PIVOT
        # end). Pivot is at the very CW end of the lever arm.
        body = (
            Arc(
                r=lever_inner_r + self.body_thk / 2,
                width=self.body_thk,
                angles=(-self.body_arc_deg, 0),
            )
            .linear_extrude(height=self.body_axial)
            .up(z_bot)
        )

        # TOOTH — chisel polyhedron, built at +X axis (azimuth=0) then rotated
        # by tooth_local_az into position.
        #
        # Build-frame ↔ lens-frame mapping (after rotation by tooth_local_az,
        # which is NEGATIVE since the tooth is at lower theta than the pivot):
        #   +Y in build frame  →  HIGHER azimuth in latch-local  →  CCW direction
        #                          at the tooth in lens-frame  →  ENTRANCE-CHANNEL side
        #   -Y in build frame  →  LOWER azimuth in latch-local  →  CW direction
        #                          at the tooth in lens-frame  →  LOCK-direction side
        #
        # Faces:
        #   CCW face (+Y, ENTRANCE side): RAMPED. Outer (high-x) edge stays at
        #     full +Y (= +tooth_arc/2). Inner (low-x) edge is pulled toward CW
        #     (smaller +Y) by tooth_radial_depth × tan(tooth_ramp_deg). Lug
        #     approaches this face from +Y during lock rotation; the slope
        #     redirects the lug's tangential push into a radial OUTWARD force on
        #     the tooth, which (combined with the residual tangential moment
        #     about the pivot) retracts the tooth.
        #   CW face (-Y, LOCK side): VERTICAL at -tooth_arc/2. Lug pushing this
        #     face during unmount creates a CW moment about the pivot → tooth
        #     drives radially INWARD = jams = blocks.
        #   Top (+Z) and bottom (-Z): flat, both at constant z.
        #   Inner (-X) and outer (+X): vertical, at x_inner and x_outer.
        #
        # Tooth attaches to the LEVER ARM at its outer radial face. x_outer
        # extends `fuse_eps` INTO the lever arm so the union creates a real
        # volume overlap (not a face-touch) — required for the STL to be a
        # single connected manifold.
        x_outer = lever_inner_r + fuse_eps
        x_inner = lever_inner_r - self.tooth_radial_depth
        y_cw = -tooth_arc_mm_at_outer / 2  # CW (lock-side) face: vertical
        y_ccw_outer = +tooth_arc_mm_at_outer / 2  # CCW face outer edge: full +Y
        ramp_drop = self.tooth_radial_depth * math.tan(
            math.radians(self.tooth_ramp_deg)
        )
        y_ccw_inner = max(y_ccw_outer - ramp_drop, y_cw + 0.1)  # clamp so tooth stays nondegenerate at inner radius
        # Tooth's axial range is INSET from the rotation channel by tooth_axial_clearance
        # on both sides. The rotation channel runs from rest_z to rest_z + lug_axial +
        # axial_clearance; the tooth sits centered between the lug's axial range
        # (rest_z .. rest_z + lug_axial) with clearance gaps above and below for
        # support material and to keep the tooth from fusing with the tube during
        # printing.
        # NOTE: use distinct variable names — z_bot is the lever-arm bottom defined
        # earlier; tooth_z_lo/hi are the tooth's own axial extent.
        tooth_z_lo = self.rest_z + self.tooth_axial_clearance
        tooth_z_hi = self.rest_z + self.lug_axial - self.tooth_axial_clearance
        verts = [
            (x_inner, y_cw,        tooth_z_lo),    # 0
            (x_outer, y_cw,        tooth_z_lo),    # 1
            (x_outer, y_ccw_outer, tooth_z_lo),    # 2
            (x_inner, y_ccw_inner, tooth_z_lo),    # 3
            (x_inner, y_cw,        tooth_z_hi),    # 4
            (x_outer, y_cw,        tooth_z_hi),    # 5
            (x_outer, y_ccw_outer, tooth_z_hi),    # 6
            (x_inner, y_ccw_inner, tooth_z_hi),    # 7
        ]
        faces = [
            [0, 3, 2, 1],     # bottom (-Z, trapezoidal due to ramp)
            [4, 5, 6, 7],     # top (+Z, trapezoidal, flat)
            [0, 1, 5, 4],     # CW face (-Y, vertical) — blocks unmount
            [2, 3, 7, 6],     # CCW face (+Y, RAMPED) — entrance side, lug retracts tooth via this slope
            [1, 2, 6, 5],     # outer face (+X)
            [0, 4, 7, 3],     # inner face (-X)
        ]
        tooth = polyhedron(points=verts, faces=faces, convexity=2).rotate(
            [0, 0, tooth_local_az]
        )

        # TAB (B) — flat radial PADDLE extending RADIALLY OUTWARD from the LEVER
        # ARM's CCW endcap. Built at +X axis (azimuth=0 in build-tab frame),
        # then rotated to azimuth=-body_arc_deg.
        #
        # TAB orientation: long dimension RADIAL (tab_radial_extent), middle
        # dimension AXIAL (matches body_axial — the lever arm's height along the
        # tube axis), thin dimension TANGENTIAL (tab_tangential_width).
        #
        # ABUTMENT: the TAB's +Y face (the tangential face on the LEVER-ARM side)
        # sits flush at Y=0, against the LEVER ARM's CCW endcap face (which lies
        # at azimuth=0 in build-tab frame, i.e. Y=0 plane). Over the full axial
        # × radial extent of the LEVER ARM endcap, the two faces coincide. TAB's
        # tangential range is therefore [-tab_tangential_width, 0]; its inner
        # radial face starts at lever_inner_r (the LEVER ARM's inner face), so
        # the abutment covers the lever arm's full radial wall.
        # +Y dimension extended by `fuse_eps` so the TAB overlaps the LEVER ARM
        # by a small VOLUME (not just a shared face). Without this, OpenSCAD
        # unions them but they remain as separate manifolds in the STL — and
        # tools like Bambu Studio's "Split to Objects" treat them as separate
        # objects.
        fuse_eps = 0.1
        tab_b = (
            cube([self.tab_radial_extent, self.tab_tangential_width + fuse_eps, self.body_axial])
            .right(lever_inner_r)
            .up(z_bot)
            .back(self.tab_tangential_width)  # shift -Y; +Y face now at Y=+fuse_eps (inside lever arm)
        )

        # FINGER CATCH (A) — extends TANGENTIALLY from the TAB's outer-radial
        # end, perpendicular to the TAB's radial direction. Same axial height as
        # the TAB and lever arm (z_bot..z_bot+body_axial). The catch lives in
        # the −Y direction in the build-tab frame (away from the lever arm /
        # tooth side), giving the fingertip a hook on the TAB's outer corner.
        # Outer radial face: flush with the TAB's outer radial face. +Y face of
        # the catch: flush with the TAB's −Y face (they share that face).
        # +Y dimension extended by `fuse_eps` so the CATCH overlaps the TAB
        # by a small VOLUME at their shared face (same reason as TAB above).
        catch = (
            cube([self.finger_catch_thk, self.finger_catch_extent + fuse_eps, self.body_axial])
            .right(lever_inner_r + self.tab_radial_extent - self.finger_catch_thk)
            .up(z_bot)
            .back(self.tab_tangential_width + self.finger_catch_extent)
        )

        tab_assembly = union(tab_b, catch).rotate([0, 0, -self.body_arc_deg])

        return union(flex, body, tooth, tab_assembly)


class BronicaS2LensMountLocking(LensMountLocking, BronicaS2LensMount):
    """Bronica S2 lens mount with the tangentially-rocking flex-tab latch."""


class LensMountLockingSupports(LensMountLocking):
    """Modeled supports for printing `LensMountLocking` with PETG support
    material against a PLA part.

    Outputs ONLY the support volumes (no lens-mount geometry). Designed for
    Bambu Studio's multi-object workflow:

      1. Load the main lens-mount STL (`s2_mount-lens_locking.stl`) AND this
         supports STL (`s2_mount-lens_locking_supports.stl`) as TWO separate
         objects in the same plate. Position them at the same world coords
         (don't auto-arrange — both are pre-aligned in the model).
      2. Assign Generic PLA to the lens-mount object, Generic PETG to the
         supports object.
      3. On the lens-mount object, set `support: off` for the regions covered
         by the modeled supports (rotation channels and lever-arm clearance
         gap). The simplest way: paint blockers in the support-blocker tool
         over those regions, OR turn off auto-support entirely if the modeled
         supports cover everything that needs it.
      4. On the supports object, set `support: off` (it IS the support).
      5. PRINT ORIENTATION: bottom face on bed, entry rim pointing UP. The
         entry channels naturally point UP into open air with no roof to
         support, so we don't need to support them. The rotation channels
         have their roof (the bayonet lip) on the +z side, which DOES need
         support from below.

    Support shape is similar to `CameraMount` (a tube with lugs at the rim),
    but inverted relative to the lens mount and with the lugs widened to fill
    the rotational channels:

      - CENTRAL TUBE: a hollow tube sitting in the bore region, from the bed
        (SCAD z=0) up to the rotation-channel level (SCAD z=rest_z). Provides
        a foundation for the rotation lugs to print on. Sized to fit inside
        the bore with `support_air_gap` clearance.

      - ROTATION-CHANNEL FILLERS: arcs at each lug's rotation-channel angular
        range (wider than the lug itself by `lock_angle_deg` on the CCW edge),
        sized to fit inside the channel with `support_air_gap` on all sides.
        These sit on top of the central tube + the lens mount's bottom flange
        and fill the swept channel volume so the bayonet lip above the channel
        has continuous support during printing. At the latch's lug, the tooth
        volume is subtracted (with air gap) so the support doesn't fuse to or
        trap the tooth.

      - LEVER-ARM GAP SUPPORT: a thin curved slab in the `lever_clearance` gap
        between the OD and the lever arm, from the bed up to just below the
        lever arm's bottom face in SCAD (with air gap). Provides a foundation
        for the lever arm's first print layer. Excludes the flex-zone
        tangential range (the flex bridges the gap there).

    Note: NO entry-channel supports are needed. In this print orientation the
    entry channels are notches in the lip that open UPWARD into air — there's
    no roof to support.

    All air gaps to the lens mount are built into this geometry — there is no
    slicer-applied Z distance for multi-object support, so the gap MUST be in
    the model. PETG-on-PLA non-adhesion lets the supports pop off cleanly.
    """

    support_air_gap = 0.1     # radial/axial air gap between support and lens mount (mm)
    support_air_gap_deg = 0.5 # tangential air gap (degrees of arc)
    support_tube_wall_thk = 1.5  # wall thickness of the central support tube (mm)
    support_inward_offset = 1.0  # mm. The inner arcs are shifted radially inward by this amount, so the arc's outer face sits 1 mm inside the channel-filler's natural inner face. The filler's inner edge is also extended inward by the same amount, so the arc and filler keep their 0.1 mm radial overlap and stay as one printed part. The net effect: a step on the OUTSIDE of the arc (between the arc and the lens-mount lip) so the support can wiggle radially before having to clear the lip — much easier to remove.

    def build(self):
        # Tooth angular position (only the largest lug has the tooth, but we
        # subtract from all fillers for simplicity — it's a no-op elsewhere).
        tooth_center_deg, pivot_center_deg = self._tooth_and_pivot_angles()
        tooth_local_az = tooth_center_deg - pivot_center_deg

        # Tooth bounding box (build frame) — expanded by support_air_gap on all
        # sides — for subtraction from the rotation-channel filler. Mirrors the
        # tooth geometry built in LensMountLocking._build_latch (where x_outer
        # extends 0.1 mm into the lever arm by `fuse_eps` for clean union).
        tooth_fuse_eps = 0.1  # must match LensMountLocking._build_latch's fuse_eps
        tooth_arc_mm_at_outer = self.tooth_angular_width_deg * math.pi / 180.0 * self.outer_or
        lever_inner_r = self.outer_or + self.lever_clearance
        x_outer = lever_inner_r + tooth_fuse_eps
        x_inner = lever_inner_r - self.tooth_radial_depth
        y_lo = -tooth_arc_mm_at_outer / 2
        y_hi = +tooth_arc_mm_at_outer / 2
        z_lo_t = self.rest_z + self.tooth_axial_clearance
        z_hi_t = self.rest_z + self.lug_axial - self.tooth_axial_clearance
        ag = self.support_air_gap
        tooth_neg = (
            cube([
                (x_outer - x_inner) + 2 * ag,
                (y_hi - y_lo) + 2 * ag,
                (z_hi_t - z_lo_t) + 2 * ag,
            ])
            .right(x_inner - ag)
            .up(z_lo_t - ag)
            .back(-(y_lo - ag))   # shift in −Y to get y_lo - ag as the −Y face
            .rotate([0, 0, tooth_local_az])
            .rotate([0, 0, pivot_center_deg])
        )

        # ── CENTRAL SUPPORT — three arc segments ──────────────────────────────
        # The support "tube" in the bore is BROKEN into three arc segments,
        # one per lug. A single closed tube can't be removed from the printed
        # lens mount because its rotation-channel fillers (above) are wider
        # than the bore at the lip — the only way to extract a closed tube
        # would be to cut it. Three independent arcs each bring out their own
        # lug's filler with them, one at a time.
        #
        # Each segment spans only the SWEPT portion of its lug's rotation
        # channel — the part of the channel that's NOT under an entry-channel
        # notch in the bayonet lip. That's the only region where the lip
        # actually has a roof that needs support. The entry-channel notches
        # cut all the way through the lip, so the rotation channel beneath
        # them has no roof — no point supporting there.
        #
        # Support angular range per lug: [c − w/2 − lock_angle, c − w/2]
        # (with `support_air_gap_deg` clearance on each end). Outside this
        # range, either the rotation channel doesn't exist or the lip is
        # already cut.
        #
        # Each segment is shifted radially INWARD by `support_inward_offset` mm
        # so the arc's outer face is 1 mm clear of the lens-mount lip's inner
        # face. With the filler's inner edge ALSO extended inward by the same
        # amount (below), the segment and filler still overlap radially by
        # 0.1 mm — they stay one printed part. The 1 mm inward step on the
        # outside of the arc means the segment+filler unit can wiggle inward
        # before having to clear the lip, much easier to extract by hand.
        bore_inner_diameter = self.cam_barrel_od + 2 * self.clearance
        support_tube_outer_r = (
            (bore_inner_diameter - 2 * self.support_air_gap) / 2
            - self.support_inward_offset
        )
        support_tube_inner_r = support_tube_outer_r - self.support_tube_wall_thk

        for c, w, p in self.lugs:
            # Support only the swept-and-not-entry-channel part of the rotation
            # channel: from the rotation channel's CCW edge (c − w/2 − lock_angle)
            # to the entry channel's CCW edge (c − w/2). The CW half of the
            # rotation channel sits under the entry-channel notch (no roof =
            # no support needed).
            seg_start = c - w / 2 - self.lock_angle_deg + self.support_air_gap_deg
            seg_end = c - w / 2 - self.support_air_gap_deg
            # Segment top reaches the filler top (axially toward the camera).
            # The slicer prints the filler's bottom layer as a bridge from the
            # segment's outer face across the radial gap to the channel's
            # outer wall, so the filler is supported during printing without
            # being fused to the segment.
            yield (
                Arc(
                    r=(support_tube_inner_r + support_tube_outer_r) / 2,
                    width=support_tube_outer_r - support_tube_inner_r,
                    angles=(seg_start, seg_end),
                )
                .linear_extrude(
                    height=self.rest_z + self.lug_axial + self.axial_clearance - self.support_air_gap
                )
            )

        # ── ROTATION-CHANNEL FILLERS ──────────────────────────────────────────
        # One per lug. Wider than the lugs (covers the full rotation-channel
        # arc including the swept volume the lug rotated through).
        #
        # Axially: filler bottom is at `rest_z + support_air_gap` (NOT at rest_z)
        # so there's a 0.1 mm air gap between the filler's bottom face and the
        # lens-mount bottom flange's top face — otherwise they'd share a 2D
        # face and CGAL would fuse the supports with the lens mount, defeating
        # the multi-material setup. The 0.1 mm gap is small enough that the
        # slicer bridges it on the layer above.
        #
        # Filler inner edge is extended inward by `support_inward_offset` mm
        # past body_or so it overlaps the (also-inward-shifted) support arc
        # by 0.1 mm radially — segment and filler stay one printed part.
        # The 1 mm "tongue" of filler that hangs inward of the lens-mount
        # lip's inner face is bridged at print time from the arc's top edge.
        for c, w, p in self.lugs:
            filler_inner_r = self.body_or - self.support_inward_offset
            filler_outer_r = self.body_or + p - self.support_air_gap  # 0.1 air gap to channel outer wall
            # Tangential range matches the segment beneath: only the swept-
            # and-not-entry-channel part of the rotation channel.
            rot_arc = Arc(
                r=(filler_inner_r + filler_outer_r) / 2,
                width=filler_outer_r - filler_inner_r,
                angles=(
                    c - w / 2 - self.lock_angle_deg + self.support_air_gap_deg,
                    c - w / 2 - self.support_air_gap_deg,
                ),
            )
            rot_filler = (
                rot_arc
                .linear_extrude(
                    # Filler height: channel height minus 2 × air_gap (one above, one below).
                    height=self.lug_axial + self.axial_clearance - 2 * self.support_air_gap
                )
                .up(self.rest_z + self.support_air_gap)  # 0.1 mm above bottom flange top
            )
            yield difference(rot_filler, tooth_neg)

        # ── LEVER ARM + TAB + FINGER CATCH FOOTPRINT SUPPORT ─────────────────
        # Provides a foundation for the lever arm + TAB + FINGER CATCH to print
        # on. The footprint of those three features (projected onto the bed)
        # is extruded from the bed up to just below the lever arm's bottom
        # face (with air gap).
        #
        # Important: the support stays OUTSIDE the lever_clearance gap (the
        # 0.6 mm radial space between the OD wall and the lever arm). Inner
        # radial face of the support starts AT the lever arm's inner face
        # (lever_inner_r). The gap is left empty — required for the latch to
        # operate, and any support there would be hard to extract anyway.
        #
        # The OD wall doesn't need this support — it goes all the way down to
        # the bed in print on its own. The flex zone bridges the gap and is
        # connected structurally to the OD wall, so it can print suspended
        # over the (now-unsupported) gap.
        z_lever_bot = self.rest_z - (self.body_axial - self.lug_axial) / 2
        support_z_top = z_lever_bot - self.support_air_gap
        if support_z_top > 0:
            grip_center_deg = pivot_center_deg - self.body_arc_deg

            # 2D footprint of the lever arm (annular sector at the lever arm's
            # radial range, from grip_center_deg to pivot_center_deg).
            lever_outer_r = lever_inner_r + self.body_thk
            lever_arc_2d = Arc(
                r=(lever_inner_r + lever_outer_r) / 2,
                width=lever_outer_r - lever_inner_r,
                angles=(grip_center_deg, pivot_center_deg),
            )

            # 2D footprint of the TAB and FINGER CATCH at the lever arm's CCW
            # endcap. Built at +X axis with the same translations as in
            # _build_latch (radial range, tangential −Y placement), then rotated
            # to grip_center_deg (the lever arm's CCW endcap angle in lens frame).
            # Both shapes get a +Y extension (`footprint_fuse_eps`) so their
            # unions overlap by VOLUME (not just shared edges). The TAB's
            # extension also has to span the lever-arc's CCW endcap arc, which
            # is at lever_outer_r — for a noticeable angular overlap there, the
            # extension needs to be at least ~1 mm at this radius.
            footprint_fuse_eps = 1.0
            tab_2d = (
                square([self.tab_radial_extent, self.tab_tangential_width + footprint_fuse_eps])
                .right(lever_inner_r)
                .back(self.tab_tangential_width)
            )
            catch_2d = (
                square([self.finger_catch_thk, self.finger_catch_extent + footprint_fuse_eps])
                .right(lever_inner_r + self.tab_radial_extent - self.finger_catch_thk)
                .back(self.tab_tangential_width + self.finger_catch_extent)
            )
            tab_catch_2d = union(tab_2d, catch_2d).rotate([0, 0, grip_center_deg])

            # Combine and extrude from bed up to support top (with axial air
            # gap to the lever arm above).
            yield (
                union(lever_arc_2d, tab_catch_2d)
                .linear_extrude(height=support_z_top)
            )


class BronicaS2LensMountLockingSupports(LensMountLockingSupports, BronicaS2LensMount):
    """Bronica S2 modeled supports for the locking lens mount."""
'''


# ============================================================================
# NEW DESIGN — locking PIN that drops into the rotation channel by gravity.
# A 3 mm-dia axial hole through the bayonet lip, sited just CW of the largest
# lug's entry-channel CW edge, holds a loose 2 mm-dia cylindrical pin. In the
# print-time supports object, the rotation-channel filler under the latch lug
# is taller than the other two — high enough for its top face to support the
# pin during printing. After supports are removed the pin falls under gravity
# into the rotation channel and blocks CCW lug rotation (= unmount).
#
# This stage: hole + drop-in pin only. No actuation mechanism, no spring.
# ============================================================================


class LensMountLocking(LensMount):
    """`LensMount` with a passive drop-in locking pin (cubic).

    Adds a rectangular axial hole through the bayonet lip at the largest
    lug's locking azimuth, just CW of the entry channel CW edge, plus a
    loose rectangular pin printed inside that hole. The pin is a separate
    manifold; in the print-time configuration its bottom face rests on the
    rotation-channel filler from the supports object. Removing the supports
    after print drops the pin into the rotation channel by gravity, where
    it blocks CCW lug rotation (= traps the lens locked).

    Local pin frame: +X = radial outward, +Y = CCW around the part. Pin
    cross-section is rectangular (`pin_radial` × `pin_tangential`); hole
    is the pin grown by `pin_fuse_clearance / 2` on every side.
    """

    pin_fuse_clearance = 0.4      # mm — total clearance: 0.2 mm per side, just
                                  # enough to keep PLA from bridging during print-in-
                                  # place
    pin_inner_wall_thk = 0.2      # mm of lip material between the hole's inboard
                                  # face and the bore wall — keeps the pin off the
                                  # central empty cylinder
    pin_lug_clearance = 0.5       # mm — tangential clearance between the pin's
                                  # CW face and the locked lug's CCW edge.
                                  # Smaller = pin catches the lug earlier on
                                  # unmount-rotation; larger = wider dead-zone
                                  # before the pin engages.

    # Lever arm — a curved annular sector outside the OD wall, tangentially
    # centered on the pin. Standalone manifold; not yet connected to the
    # housing or the pin. Will hook up to actuation in a later iteration.
    lever_arm_arc_length = 5.0       # mm — circumferential extent at mid-radius
    lever_arm_radial_thk = 1.2       # mm — radial thickness
    lever_arm_clearance = 0.3        # mm — radial gap between OD and lever-arm
                                     # inner face. Slightly under one nozzle
                                     # width (Bambu default 0.42 mm); the
                                     # housing's outer perimeter and switch's
                                     # inner perimeter still print as distinct
                                     # walls, but with less margin than 0.4 mm.
                                     # Old flex-tab design's documented minimum
                                     # was 0.5 mm; 0.3 mm is aggressive for an
                                     # open wall-to-wall gap. If the switch
                                     # comes out fused to the housing, bump
                                     # this back up to 0.4 mm.
    lever_arm_axial_below_rest = 1.65  # mm — lever-arm bottom face below rest_z
                                       # (= 5 mm); inherited from the old flex-tab
                                       # design, where it centered the arm on
                                       # the lug. Top face goes to part top.

    def _pin_geometry(self):
        """Return (theta_deg, r_axis, pin_radial, pin_tangential, hole_radial, hole_tangential).

        Anchored to the LATCH (= widest) lug. Radial layout, bore-out:
            bore_inner | wall | clearance | pin_radial | clearance | slot outer wall
        with `clearance = pin_fuse_clearance / 2` and `wall =
        pin_inner_wall_thk`. The hole spans `wall` to `slot_outer`
        (= `body_or + widest_p + self.clearance`), so the hole's outer
        face never cuts past the rotation channel's outer wall.

        - hole_radial = widest_p − pin_inner_wall_thk
          (= 1.6 mm with widest_p=1.8 and wall=0.2).
        - pin_radial = hole_radial − pin_fuse_clearance
          (= 1.2 mm — the pin sits inside the hole with `clearance` on
          each side).
        - pin_tangential = widest_p / 2 — half the prior cylinder-pin's
          diameter; keeps the pin's tangential bulk modest.

        Angular layout: the pin's CW face (the one opposite the entry
        channel) sits one lug-width plus `pin_lug_clearance` CCW of the
        rotation channel's CW end. Equivalently, it sits one
        `pin_lug_clearance` CCW of the locked lug's CCW edge — pushed
        as deep into the rotation channel as the locked lug allows.
        """
        widest_w = max(w for c, w, p in self.lugs)
        widest_center = next(c for c, w, p in self.lugs if w == widest_w)
        widest_p = next(p for c, w, p in self.lugs if w == widest_w)
        per_side_clearance = self.pin_fuse_clearance / 2
        hole_radial = widest_p - self.pin_inner_wall_thk
        pin_radial = hole_radial - self.pin_fuse_clearance
        pin_tangential = widest_p / 2
        bore_inner = self.body_or + self.clearance
        r_axis = (
            bore_inner
            + self.pin_inner_wall_thk
            + per_side_clearance
            + pin_radial / 2
        )
        hole_tangential = pin_tangential + 2 * per_side_clearance
        # Pin's CW face at lens-frame angle = (rot_channel_CW_end + lug_w
        # + clearance). pin_theta itself (the pin axis angle) is offset
        # CCW from that face by half the pin's tangential angular extent.
        rot_channel_cw_end_deg = widest_center - widest_w / 2 - self.lock_angle_deg
        pin_lug_clearance_deg = math.degrees(self.pin_lug_clearance / r_axis)
        pin_tan_half_deg = math.degrees((pin_tangential / 2) / r_axis)
        theta = (
            rot_channel_cw_end_deg
            + widest_w
            + pin_lug_clearance_deg
            + pin_tan_half_deg
        )
        return theta, r_axis, pin_radial, pin_tangential, hole_radial, hole_tangential

    def build(self):
        # Same cutters as LensMount.build, plus a rectangular pin hole.
        blank = Tube(h=self.h, od=self.outer_od, id=self.inner_id)
        bore_2d = circle(d=self.cam_barrel_od - self.inner_shrink).offset(r=self.clearance)
        bore_cutter = bore_2d.linear_extrude(height=self.h + 1.0).down(0.5)

        entry_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(
                    c - w / 2 - math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                    c + w / 2 + math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                ),
            )
            for c, w, p in self.lugs
        ]
        entry_lug_cutter = (
            union(*entry_arcs).offset(r=self.clearance)
            .linear_extrude(height=self.insertion_depth + 0.5)
            .up(self.rest_z)
        )

        rot_arcs = [
            Arc(
                r=self.body_or + p / 2,
                width=p,
                angles=(c - w / 2 - self.lock_angle_deg, c + w / 2),
            )
            for c, w, p in self.lugs
        ]
        rot_cutter = (
            union(*rot_arcs).offset(r=self.clearance)
            .linear_extrude(height=self.lug_axial + self.axial_clearance)
            .up(self.rest_z)
        )

        groove_2d = polygon(points=[
            (self.outer_or - self.groove_depth, 0.0),
            (self.outer_or + 0.1, self.groove_width / 2),
            (self.outer_or + 0.1, -self.groove_width / 2),
        ])
        groove_cutter = (
            groove_2d.linear_extrude(height=self.h + 1.0).down(0.5)
            .rotate([0, 0, self.groove_angle_deg])
        )

        # Pin hole: rectangular axial cutter from the rotation-channel roof
        # up past the part's top face. Centered on the pin axis in the local
        # pin frame, oriented so its X edge runs radially and Y edge runs
        # tangentially.
        pin_theta_deg, r_axis, pin_radial, pin_tangential, hole_radial, hole_tangential = (
            self._pin_geometry()
        )
        pin_x = r_axis * math.cos(math.radians(pin_theta_deg))
        pin_y = r_axis * math.sin(math.radians(pin_theta_deg))
        channel_roof_z = self.rest_z + self.lug_axial + self.axial_clearance
        hole_height = self.h - channel_roof_z + 0.5
        pin_hole_cutter = (
            cube([hole_radial, hole_tangential, hole_height])
            .left(hole_radial / 2)         # local X centered: [-rad/2, +rad/2]
            .back(hole_tangential / 2)     # local Y centered: [-tan/2, +tan/2]
            .up(channel_roof_z)
            .rotate([0, 0, pin_theta_deg]) # align local +X with lens-frame radial-out
            .right(pin_x).back(-pin_y)
        )

        # Stem geometry — links the pin (inboard) to the switch (outboard)
        # so they print as one object. Tangential matches the pin; radial
        # spans pin_outer to switch_inner with a 0.1 mm volumetric overlap
        # on each side for clean fusion. Height = pin's axial height minus
        # the rotation-channel height (so when the supports are removed the
        # whole pin+stem+switch assembly drops by exactly the channel height
        # and the stem ends up at the channel-roof level on its way down).
        # Top flush with the part's top face.
        per_side_clearance = self.pin_fuse_clearance / 2
        pin_outer_r = r_axis + pin_radial / 2
        switch_inner_r = self.outer_or + self.lever_arm_clearance
        stem_fuse_eps = 0.1
        stem_inner_r = pin_outer_r - stem_fuse_eps
        stem_outer_r = switch_inner_r + stem_fuse_eps
        stem_radial = stem_outer_r - stem_inner_r
        stem_tangential = pin_tangential
        rotation_channel_height = self.lug_axial + self.axial_clearance
        pin_axial_height = self.h - channel_roof_z
        # Stem axial extent matches the pin's, so the stem's underside is
        # supported by the pin during the print (no unsupported overhang on
        # the stem's −Z face). Stem ends up coextensive with the pin in z.
        stem_height = pin_axial_height
        stem_z_top = self.h
        stem_z_bot = stem_z_top - stem_height

        # Stem-slot cutter — rectangular hole through the lip outer wall so
        # the stem can slide axially without fusing to the housing during
        # print-in-place. Same per-side `pin_fuse_clearance / 2` as the pin
        # has from its hole walls. Z range covers both the stem's print
        # position AND its dropped position so the assembly can travel after
        # supports are removed.
        slot_inner_r = stem_inner_r - per_side_clearance
        slot_outer_r = stem_outer_r + per_side_clearance
        slot_radial = slot_outer_r - slot_inner_r
        slot_tangential = stem_tangential + self.pin_fuse_clearance
        # In print the slot has `rotation_channel_height + per_side_clearance`
        # of room below the stem (= 1.5 mm — drop travel plus the per-side
        # clearance the pin sees against its hole walls). After the user pushes
        # the assembly down by the full `rotation_channel_height`, the stem
        # ends up in its dropped position with that same 1.5 mm of room still
        # below it, so it isn't bottoming on the slot floor.
        stem_dropped_z_bot = stem_z_bot - rotation_channel_height
        print_bottom_room = rotation_channel_height + per_side_clearance
        slot_z_bot = stem_dropped_z_bot - print_bottom_room
        slot_z_top = self.h + 0.5
        slot_height = slot_z_top - slot_z_bot
        stem_slot_cutter = (
            cube([slot_radial, slot_tangential, slot_height])
            .right(slot_inner_r)
            .back(slot_tangential / 2)
            .up(slot_z_bot)
            .rotate([0, 0, pin_theta_deg])
        )

        yield difference(
            blank,
            union(
                bore_cutter, entry_lug_cutter, rot_cutter, groove_cutter,
                pin_hole_cutter, stem_slot_cutter,
            ),
        )

        # The pin itself, as a separate manifold. Bottom face flush with the
        # rotation-channel roof — i.e. one `_pin_print_support_gap` (the same
        # tiny clearance that separates the channel roof from the filler top)
        # above the filler. Top face flush with the part's top face.
        pin_bottom_z = self.rest_z + self.lug_axial + self.axial_clearance
        pin_top_z = self.h
        pin_height = pin_top_z - pin_bottom_z
        yield (
            cube([pin_radial, pin_tangential, pin_height])
            .left(pin_radial / 2)
            .back(pin_tangential / 2)
            .up(pin_bottom_z)
            .rotate([0, 0, pin_theta_deg])
            .right(pin_x).back(-pin_y)
        )

        # Lever arm — annular-sector beam outside the OD, tangentially centered
        # on the pin. Standalone manifold (no flex bridge yet); the
        # `lever_arm_clearance` gap to the OD keeps the slicer from fusing it
        # to the housing during print-in-place. Top flush with the part's top
        # face; bottom drops `lever_arm_axial_below_rest` below `rest_z`.
        lever_arm_inner_r = self.outer_or + self.lever_arm_clearance
        lever_arm_mid_r = lever_arm_inner_r + self.lever_arm_radial_thk / 2
        lever_arm_half_angle_deg = math.degrees(
            (self.lever_arm_arc_length / 2) / lever_arm_mid_r
        )
        lever_arm_z_bot = self.rest_z - self.lever_arm_axial_below_rest
        lever_arm_height = self.h - lever_arm_z_bot
        yield (
            Arc(
                r=lever_arm_mid_r,
                width=self.lever_arm_radial_thk,
                angles=(
                    pin_theta_deg - lever_arm_half_angle_deg,
                    pin_theta_deg + lever_arm_half_angle_deg,
                ),
            )
            .linear_extrude(height=lever_arm_height)
            .up(lever_arm_z_bot)
        )

        # Stem — bridges the pin and switch into one object. Volumetric
        # overlap with both (0.1 mm on each radial side) fuses them through
        # CGAL's union into a single manifold.
        yield (
            cube([stem_radial, stem_tangential, stem_height])
            .right(stem_inner_r)
            .back(stem_tangential / 2)
            .up(stem_z_bot)
            .rotate([0, 0, pin_theta_deg])
            .green()
        )

        if self.inner_tube:
            yield Tube(h=self.inner_tube_h, od=self.inner_tube_od, id=self.inner_tube_id)
            yield Tube(h=self.rest_z, od=self.connector_od, id=self.inner_tube_od)


class BronicaS2LensMountLocking(LensMountLocking, BronicaS2LensMount):
    """Bronica S2 lens mount with the drop-in locking pin."""


class LensMountLockingSupports(LensMountLocking):
    """Modeled PETG supports for printing `LensMountLocking` with a PLA part.

    Yields:
      - Three central support arcs (one per lug, in the bore region).
      - Three rotation-channel fillers (one per lug). The latch lug's filler
        is the one that supports the pin during printing — its top face is
        at `rest_z + lug_axial + axial_clearance - support_air_gap` (= the
        same z as the other fillers' tops), the pin sits on it.

    Print orientation: bottom face on bed, entry rim pointing UP. The print
    config gives the pin a flat PETG shelf to print on; removing the
    supports drops the pin into the channel.
    """

    support_air_gap = 0.1
    support_air_gap_deg = 0.5
    support_tube_wall_thk = 1.5
    support_inward_offset = 1.0

    def build(self):
        # Central support arcs — three pillars in the bore, one per lug.
        # Each spans the swept-but-not-entry-channel arc of its lug's
        # rotation channel, shifted radially inward by `support_inward_offset`
        # so it doesn't get pinned under the bayonet lip during removal.
        bore_inner_diameter = self.cam_barrel_od - self.inner_shrink + 2 * self.clearance
        support_tube_outer_r = (
            (bore_inner_diameter - 2 * self.support_air_gap) / 2
            - self.support_inward_offset
        )
        support_tube_inner_r = support_tube_outer_r - self.support_tube_wall_thk

        for c, w, p in self.lugs:
            seg_start = c - w / 2 - self.lock_angle_deg + self.support_air_gap_deg
            seg_end = c - w / 2 - self.support_air_gap_deg
            yield (
                Arc(
                    r=(support_tube_inner_r + support_tube_outer_r) / 2,
                    width=support_tube_outer_r - support_tube_inner_r,
                    angles=(seg_start, seg_end),
                )
                .linear_extrude(
                    height=self.rest_z + self.lug_axial + self.axial_clearance - self.support_air_gap
                )
            )

        # Rotation-channel fillers — one per lug. Inner edge anchored to
        # the central pillar's outer edge minus `fuse_overlap` so the two
        # pieces always merge into one printed part — independent of
        # `inner_shrink` (which moves the pillar but not body_or). Filler
        # bottom is air_gap above the bottom-flange top face; filler top
        # is air_gap below the rotation-channel roof. The latch lug's
        # filler doubles as the pin's print-time support shelf.
        fuse_overlap = 0.1
        for c, w, p in self.lugs:
            filler_inner_r = support_tube_outer_r - fuse_overlap
            filler_outer_r = self.body_or + p - self.support_air_gap
            rot_arc = Arc(
                r=(filler_inner_r + filler_outer_r) / 2,
                width=filler_outer_r - filler_inner_r,
                angles=(
                    c - w / 2 - self.lock_angle_deg + self.support_air_gap_deg,
                    c - w / 2 - self.support_air_gap_deg,
                ),
            )
            yield (
                rot_arc
                .linear_extrude(
                    height=self.lug_axial + self.axial_clearance - 2 * self.support_air_gap
                )
                .up(self.rest_z + self.support_air_gap)
            )

        # Stem-tongue — extension of the latch lug's filler outward into
        # the stem slot, supporting the stem's underside during print-in-
        # place. Tangentially narrower than the stem so the stem overhangs
        # it by `tongue_overhang` on each side: less PETG-PLA contact area
        # on the stem-bottom interface = much easier to release the support
        # cleanly. PLA bridges the small overhang trivially.
        pin_theta_deg, _r_axis, _pr, pin_tangential, _hr, _ht = self._pin_geometry()
        widest_p = max(p for c, w, p in self.lugs)
        filler_outer_r = self.body_or + widest_p - self.support_air_gap
        tongue_fuse_eps = 0.05
        tongue_inner_r = filler_outer_r - tongue_fuse_eps
        tongue_outer_r = self.outer_or
        tongue_radial = tongue_outer_r - tongue_inner_r
        tongue_overhang = 0.3
        tongue_tangential = pin_tangential - 2 * tongue_overhang
        tongue_z_bot = self.rest_z + self.support_air_gap
        tongue_height = self.lug_axial + self.axial_clearance - 2 * self.support_air_gap
        yield (
            cube([tongue_radial, tongue_tangential, tongue_height])
            .right(tongue_inner_r)
            .back(tongue_tangential / 2)
            .up(tongue_z_bot)
            .rotate([0, 0, pin_theta_deg])
        )

        # Switch (lever-arm) support foot — annular sector matching the
        # switch's radial+angular footprint, extruded from the bed up to
        # `support_air_gap` below the switch's bottom face. Inherited from
        # the old flex-tab design's lever-arm-support pattern.
        switch_inner_r = self.outer_or + self.lever_arm_clearance
        switch_outer_r = switch_inner_r + self.lever_arm_radial_thk
        switch_mid_r = (switch_inner_r + switch_outer_r) / 2
        switch_half_angle_deg = math.degrees(
            (self.lever_arm_arc_length / 2) / switch_mid_r
        )
        switch_z_bot = self.rest_z - self.lever_arm_axial_below_rest
        foot_top_z = switch_z_bot - self.support_air_gap
        if foot_top_z > 0:
            yield (
                Arc(
                    r=switch_mid_r,
                    width=switch_outer_r - switch_inner_r,
                    angles=(
                        pin_theta_deg - switch_half_angle_deg,
                        pin_theta_deg + switch_half_angle_deg,
                    ),
                )
                .linear_extrude(height=foot_top_z)
            )


class BronicaS2LensMountLockingSupports(LensMountLockingSupports, BronicaS2LensMount):
    """Bronica S2 modeled supports for the pin-locking lens mount."""



class s2_mount_locking(Design):
    """Locking variants. Camera mount and base lens mount live in the
    sibling `s2_mount` design (in `s2-mount.py`)."""

    camera_mount = BronicaS2CameraMount()
    lens_mount_locking = BronicaS2LensMountLocking(
        cam_barrel_od=camera_mount.barrel_od,
        cam_barrel_id=camera_mount.barrel_id,
        lugs=camera_mount.lugs,
        lug_axial=camera_mount.lug_axial,
    )
    lens_mount_locking_supports = BronicaS2LensMountLockingSupports(
        cam_barrel_od=camera_mount.barrel_od,
        cam_barrel_id=camera_mount.barrel_id,
        lugs=camera_mount.lugs,
        lug_axial=camera_mount.lug_axial,
    )

    @variant(fn=96, default=True)
    def lens_locking(self):
        return _check_plate(self.lens_mount_locking)

    @variant(fn=96)
    def lens_locking_supports(self):
        # Modeled PETG supports for the lens_locking part. Print as a SECOND
        # object alongside lens_locking in Bambu Studio (PETG filament,
        # support: off on this object). Pre-aligned to the lens-mount's world
        # coords — load both STLs without auto-arrange.
        # Print orientation: bottom face on bed, entry rim pointing UP (same
        # orientation as the lens_locking part).
        return self.lens_mount_locking_supports.red()

    @variant(fn=96)
    def lens_locking_print(self):
        # Combined STL with the lens mount AND the modeled supports as
        # disconnected manifold solids in the same file. Workflow:
        #   1. Load this single STL into Bambu Studio (drag-and-drop is fine).
        #   2. Right-click the imported object → "Split → To Objects" (or
        #      "Split into objects"). This makes the lens mount and the
        #      supports independent objects WITHOUT moving them — they stay
        #      at their original aligned positions.
        #   3. Assign Generic PLA to the lens-mount object, Generic PETG to
        #      the supports object.
        #   4. Set "support: off" on the supports object (it IS the support).
        # The two solids do NOT touch in the model (built-in air gaps), so
        # the union just joins them into one STL file without fusing.
        return _check_plate(
            union(self.lens_mount_locking, self.lens_mount_locking_supports.red())
        )


def _check_plate(node):
    bb = bbox(node)
    if bb.size[0] > BAMBU_X2D_PLATE_X or bb.size[1] > BAMBU_X2D_PLATE_Y:
        raise ValueError(
            f"print layout {bb.size[0]:.1f} x {bb.size[1]:.1f} mm "
            f"exceeds Bambu X2D build plate "
            f"{BAMBU_X2D_PLATE_X} x {BAMBU_X2D_PLATE_Y} mm"
        )
    return node


if __name__ == "__main__":
    run()
