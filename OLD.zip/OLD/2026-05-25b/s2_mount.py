"""Bronica S2 lens-mount components.

Two mating bayonet parts:
- `CameraMount` — open tube with three outward-projecting lugs at the
  top rim, matching the actual Bronica S/S2/S2A/EC/EC-TL camera-side
  bayonet pattern (one large lug ~50° wide + two smaller ~40° lugs at
  roughly 120° spacing).
- `LensMount` — the lens-side mating part, built by subtracting the
  swept volume of the camera mount (pressed in then twisted left) from
  a thick tube.

Run:
    python s2-evolving/s2_mount.py

Locking-pin variants live in the sibling `s2_mount_locking.py` module.
"""

import math

from scadwright import Component
from scadwright.boolops import difference, union
from scadwright.composition_helpers import pack_on_bed
from scadwright.design import Design, run, variant
from scadwright.primitives import circle, polygon
from scadwright.shapes import Arc, Dome, Tube

from s2_spec import BronicaS2Bayonet


# Bambu X2D buildable area (mm). Layouts must fit within these.
BAMBU_X2D_PLATE = (256.0, 256.0)


class CameraMount(Component):
    """Open tube with a per-lug list of outward-projecting bayonet lugs
    at the top rim.

    `barrel_id` / `wall_thk` / `length` define the open cylindrical body
    (`barrel_od = barrel_id + 2 * wall_thk` is computed). `lug_axial` is
    the axial thickness of each lug; `lugs` is a tuple of
    `(center_deg, width_deg, radial_proj_mm)` triples, one per lug, so
    the bayonet pattern can be asymmetric.
    """

    equations = """
        barrel_id, length, wall_thk, lug_axial > 0
        barrel_od = barrel_id + 2 * wall_thk
        body_or = barrel_od / 2
        lug_axial <= length
        len(lugs:tuple) >= 1
    """

    def build(self):                                       # framework hook: required; returns the shape
        yield Tube(h=self.length, od=self.barrel_od, id=self.barrel_id)
        z_lug_bottom = self.length - self.lug_axial
        # Each lug: an annular sector (Arc) extruded vertically, rotated
        # to its center angle, lifted to the top of the barrel.
        for center_deg, width_deg, proj_mm in self.lugs:
            half = width_deg / 2
            yield (
                Arc(
                    r=self.body_or + proj_mm / 2,
                    width=proj_mm,
                    angles=(center_deg - half, center_deg + half),
                )
                .linear_extrude(height=self.lug_axial)
                .up(z_lug_bottom)
            )


class BronicaS2CameraMount(CameraMount):
    """Concrete mount sized to the Bronica S/S2/EC camera mount.
    All measurements live in `BronicaS2Bayonet` — single source of
    truth for the bayonet contract shared across files."""
    barrel_id = BronicaS2Bayonet.cam_barrel_id
    wall_thk  = BronicaS2Bayonet.cam_wall_thk
    length    = BronicaS2Bayonet.cam_length
    lug_axial = BronicaS2Bayonet.cam_lug_axial
    lugs      = BronicaS2Bayonet.lugs


class LensMount(Component):
    """Lens-side mating part for a `CameraMount`.

    Coordinate convention: z=0 is the bottom face of the tube, z=h is
    the top face — the ENTRY RIM, the side the camera mount is pressed
    into. When fully inserted and rotated, the camera mount's lug-front
    plane sits at z = h - `insertion_depth` (the "rest plane").

    The cutter is the union of three pieces:

    1. BORE cutter (full tube height): a clearance-offset cylinder of
       `cam_barrel_od`. Lets the camera mount's body pass through the
       entire lens mount.
    2. ENTRY LUG CHANNELS (only `insertion_depth` tall, top of tube):
       lug-width arcs at the original lug angles, from the rest plane
       up to the entry rim. Each lug slides down its channel during
       press-in.
    3. ROTATION CHANNEL (only `lug_axial` tall, at the rest plane):
       lug arcs widened by `lock_angle_deg` on the CCW ("left") edge.
       The lug rotates through this channel after entry.

    Material between the rotation channel and the entry rim, at the
    swept angles outside the entry channels, is the bayonet lip —
    it catches each lug after the twist and prevents the mount from
    pulling back out. `clearance` is applied via 2D `offset` around
    each profile.

    Tube blank:
    - OD = `cam_barrel_od + 2*max_lug_proj + 2*wall_thk`
      (i.e. `wall_thk` of wall outside the circle around the lugs)
    - ID = `cam_barrel_id - 2`
    - h  = `h`
    """

    equations = """
        cam_barrel_od, cam_barrel_id, clearance, lock_angle_deg, lug_axial, wall_thk, insertion_depth, protrusion_len, entry_arc_clearance, axial_clearance > 0
        cam_barrel_od > cam_barrel_id
        lug_axial < insertion_depth
        h = protrusion_len + insertion_depth
        max_lug_proj = max(p for c, w, p in lugs:tuple)
        outer_od = cam_barrel_od + 2 * max_lug_proj + 2 * wall_thk
        # `inner_shrink` shrinks the blank's inner diameter (and the bore cut
        # below) by this amount, leaving the OD and channel walls untouched.
        # 0 = the bore matches `cam_barrel_od + 2*clearance`. Bumping it makes
        # the inner cylinder smaller and the cuts go that much deeper inward.
        # Concrete subclasses set the value (BronicaS2LensMount reads it
        # from the bayonet spec).
        inner_shrink >= 0
        inner_id = cam_barrel_id - 2 * wall_thk - inner_shrink
        body_or = cam_barrel_od / 2
        outer_or = outer_od / 2
        rest_z = h - insertion_depth
        # Bore and channel-cutter inner radii. The bore is a cylindrical
        # hole of radius `bore_inner_r`; channel cutters (entry + rotation)
        # must reach inward past it so the channels actually open into the
        # bore. Without `channel_breakthrough`, `inner_shrink` widens the
        # bore-side wall and seals the channels with a thin veil. The
        # value below is the desired POST-offset overlap into the bore;
        # `channel_inner_r` is set so that after `.offset(r=clearance)`
        # the cutter's inner edge sits `channel_breakthrough` mm inside
        # the bore inner wall.
        bore_inner_r = body_or + clearance - inner_shrink / 2
        channel_breakthrough = 0.5
        channel_inner_r = bore_inner_r + clearance - channel_breakthrough
        # Alignment groove: thin axial recess on the outer wall, centered
        # on the widest lug's center angle.
        groove_depth, groove_width > 0
        widest_w = max(lw for lc, lw, lp in lugs)
        widest_center = [lc for lc, lw, lp in lugs if lw == widest_w][0]
        # Groove ends up at the widest lug's world angle (the BRONICA
        # logo direction) after the lens rotates +lock_angle_deg in
        # camera coords into its locked position; in lens-coords the
        # groove therefore starts at widest_center - lock_angle_deg.
        groove_angle_deg = widest_center - lock_angle_deg
    """

    def tight_bbox(self):                                  # framework hook: declare true post-Difference extents
        # Default tight_bbox would walk into the bore/channel/groove
        # `difference()` and raise. The bore + channels are fully contained
        # within the blank, so the only thing past `outer_od/2` is the
        # alignment-dot cap (protrudes ~cap_height - cap_embed radially).
        # Round up to 1.5 mm so the layout helpers always have headroom.
        from scadwright import BBox
        cap_protrusion = 1.5
        r = self.outer_od / 2 + cap_protrusion
        return BBox(min=(-r, -r, 0.0), max=(r, r, self.h))

    def _blank(self):
        return Tube(h=self.h, od=self.outer_od, id=self.inner_id)

    def _solid(self):
        """Material the cutters subtract from. Subclasses override to
        add bosses (e.g. pillow blocks) before the difference, so any
        boss-piercing cutters can act on them in the same pass."""
        return self._blank()

    def _bore_cutter(self):
        # Clearance-offset cylinder through the entire tube, shrunk
        # inward by `inner_shrink` (in diameter) so the bore cut reaches
        # the (extended-inward) blank inner edge.
        bore_2d = circle(d=self.cam_barrel_od - self.inner_shrink).offset(r=self.clearance)
        return bore_2d.linear_extrude(height=self.h + 1.0).down(0.5)

    def _entry_lug_cutter(self):
        # Lug-width arcs at the original lug angles, from the rest
        # plane to just past the entry rim. Each entry channel is
        # widened tangentially by `entry_arc_clearance` mm of arc
        # length on each side (converted per-lug to degrees by the
        # lug's mid-radius); only the entry channels are widened, not
        # the rotation channels, so the locked fit stays tight while
        # the initial drop-in is forgiving.
        entry_arcs = [
            Arc(
                r=(self.channel_inner_r + self.body_or + p) / 2,
                width=(self.body_or + p) - self.channel_inner_r,
                angles=(
                    c - w / 2 - math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                    c + w / 2 + math.degrees(self.entry_arc_clearance / (self.body_or + p / 2)),
                ),
            )
            for c, w, p in self.lugs
        ]
        return (
            union(*entry_arcs).offset(r=self.clearance)
            .linear_extrude(height=self.insertion_depth + 0.5)
            .up(self.rest_z)
        )

    def _rot_cutter(self):
        # Lug arcs widened by `lock_angle_deg` on the CW edge,
        # `lug_axial` tall (+ axial_clearance above for fit). The lug
        # front face rests on the bottom of this channel. The CW-edge
        # widening means the lens rotates CCW in camera coords
        # (CW from the viewer's perspective looking at the camera front)
        # to bring the indicator from its insertion angle (~10:30) into
        # the locked position at 12 o'clock.
        rot_arcs = [
            Arc(
                r=(self.channel_inner_r + self.body_or + p) / 2,
                width=(self.body_or + p) - self.channel_inner_r,
                angles=(c - w / 2 - self.lock_angle_deg, c + w / 2),
            )
            for c, w, p in self.lugs
        ]
        return (
            union(*rot_arcs).offset(r=self.clearance)
            .linear_extrude(height=self.lug_axial + self.axial_clearance)
            .up(self.rest_z)
        )

    def _groove_cutter(self):
        # Long skinny triangular prism on the outer wall, apex pointing
        # inward, base on the outer surface, extruded the full tube
        # height. Placed so that AFTER the lens rotates into its locked
        # position, the groove ends up aligned with the widest lug's
        # world angle (toward the BRONICA logo).
        groove_2d = polygon(points=[
            (self.outer_or - self.groove_depth, 0.0),       # apex (inward)
            (self.outer_or + 0.1, self.groove_width / 2),    # base +Y (slight overshoot)
            (self.outer_or + 0.1, -self.groove_width / 2),   # base -Y
        ])
        return (
            groove_2d
            .linear_extrude(height=self.h + 1.0)
            .down(0.5)
            .rotate([0, 0, self.groove_angle_deg])
        )

    def _cutters(self):
        """Generator of cutter Nodes for the main difference. Subclasses
        override to yield super()'s plus their own cuts, keeping all
        cuts in one Difference (avoids leaving thin veils of wall when
        a subclass cut would otherwise be in a separate pass)."""
        yield self._bore_cutter()
        yield self._entry_lug_cutter()
        yield self._rot_cutter()
        yield self._groove_cutter()

    def _alignment_dot_cap(self):
        # Small dome bump on the outer wall, centered on the same angle
        # as the alignment groove. The cap's flat base sits tangent to
        # the cylinder; embedded slightly inward (cap_embed) so the
        # union with the body stays a clean CSG (avoids tangent-line
        # contact between flat face and cylinder).
        cap_dia = 4.0
        cap_height = 1.5
        cap_inset = 0.2          # axial inset of cap's top edge from z=h
        cap_embed = 0.1          # radial embed into the wall
        return (
            Dome(cap_dia=cap_dia, cap_height=cap_height)
            .rotate([0, 90, 0])                        # dome from +z to +x
            .right(self.outer_or - cap_embed)
            .up(self.h - cap_inset - cap_dia / 2)
            .rotate([0, 0, self.groove_angle_deg])
        )

    def build(self):
        yield difference(self._solid(), *self._cutters())
        yield self._alignment_dot_cap()



class LensMountSupports(LensMount):
    """Modeled PETG supports for printing `LensMount` with a PLA part.

    Yields, per lug:
      - one central support arc — pillar in the bore region, spanning the
        swept-but-not-entry-channel arc of the lug's rotation channel and
        shifted radially inward by `support_inward_offset` so it isn't
        trapped under the bayonet lip during removal;
      - one rotation-channel filler — fits inside the rotation channel
        with `support_air_gap` of clearance above (under the channel roof)
        and below (above the bottom-flange top face), holding up the
        bayonet-lip ceiling during print. Inner edge extended inward by
        `support_inward_offset` so it overlaps the central pillar by
        ~0.1 mm radially — pillar + filler print as one connected part.

    Print orientation: bottom face on bed, entry rim pointing UP. Pair with
    the matching `LensMount` instance: print both as separate objects
    (PETG for supports, PLA for the mount, supports OFF on both objects).
    """

    support_air_gap = 0.1
    support_air_gap_deg = 0.5
    support_tube_wall_thk = 1.5
    support_inward_offset = 1.0

    def tight_bbox(self):                                  # framework hook: walk the supports build tree
        # LensMount overrides tight_bbox to declare the lens-mount's
        # post-Difference extents, but our build yields only the
        # support pieces (no Difference). Fall back to the default
        # tree walk so the bbox reflects the supports themselves.
        return Component.tight_bbox(self)

    def build(self):                                       # framework hook: required; returns the shape
        bore_inner_diameter = self.cam_barrel_od - self.inner_shrink + 2 * self.clearance
        support_tube_outer_r = (
            (bore_inner_diameter - 2 * self.support_air_gap) / 2
            - self.support_inward_offset
        )
        support_tube_inner_r = support_tube_outer_r - self.support_tube_wall_thk

        for c, w, p in self.lugs:
            seg_start = c - w / 2 - self.lock_angle_deg + self.support_air_gap_deg
            seg_end = c - w / 2 - self.support_air_gap_deg
            # Central pillar: bore region, full height up to under the
            # rotation-channel roof.
            yield (
                Arc(
                    r=(support_tube_inner_r + support_tube_outer_r) / 2,
                    width=support_tube_outer_r - support_tube_inner_r,
                    angles=(seg_start, seg_end),
                )
                .linear_extrude(
                    height=self.rest_z + self.lug_axial + self.axial_clearance - self.support_air_gap
                )
            )
            # Rotation-channel filler: sits inside the rotation channel,
            # holding up its roof (the bayonet lip). Inner edge anchored to
            # the central pillar's outer edge minus `fuse_overlap` so the
            # two pieces always merge into one printed part — independent
            # of `inner_shrink` (which moves the pillar but not body_or).
            fuse_overlap = 0.1
            filler_inner_r = support_tube_outer_r - fuse_overlap
            filler_outer_r = self.body_or + p - self.support_air_gap
            yield (
                Arc(
                    r=(filler_inner_r + filler_outer_r) / 2,
                    width=filler_outer_r - filler_inner_r,
                    angles=(seg_start, seg_end),
                )
                .linear_extrude(
                    height=self.lug_axial + self.axial_clearance - 2 * self.support_air_gap
                )
                .up(self.rest_z + self.support_air_gap)
            )


class BronicaS2LensMount(LensMount):
    """Concrete lens mount: lens-specific dimensions. The bayonet
    spec (cam_barrel_od, cam_barrel_id, lugs) is supplied at
    instantiation by reading them off the paired CameraMount instance.
    """

    # Bayonet-contract values come from the shared spec (single source
    # of truth shared with the lens housing in v12c.py).
    clearance      = BronicaS2Bayonet.mount_clearance
    wall_thk       = BronicaS2Bayonet.mount_wall_thk
    inner_shrink   = BronicaS2Bayonet.mount_inner_shrink
    protrusion_len = BronicaS2Bayonet.mount_protrusion
    # Extra arc-length added to each side of the ENTRY channels (only)
    # so the lugs drop in without fiddling. Rotation channels stay tight.
    entry_arc_clearance = 1.0
    # Axial slop in the rotation channel (channel z-height = lug_axial +
    # axial_clearance). Tightens lens-to-camera wobble independently of
    # the radial `clearance`.
    # Was 0.1 mm with Bambu's auto-generated supports. Bumped to 0.3 mm
    # for the modeled-PETG-support workflow: the air gap above the filler
    # lets the channel roof sag slightly, and the PETG/PLA boundary prints
    # rougher than a slicer-support face — both eat into the nominal slop.
    # Next, after test print (was .3), but that was just a tiny bit too loose, -> .25
    axial_clearance = 0.25
    lock_angle_deg = BronicaS2Bayonet.lock_angle_deg
    # When fully inserted and rotated, the camera-mount lug-front plane
    # sits insertion_depth mm below the entry rim.  This needs to be sufficiently
    # short so that the tube's rim doesn't impinge on teh camera's face
    # when focused to infinity.   4 was very close, but not quite short enough.
    insertion_depth = 3.5
    # Alignment groove on the outer wall, at the widest lug's center.
    groove_depth = BronicaS2Bayonet.alignment_groove_depth
    groove_width = BronicaS2Bayonet.alignment_groove_width
    # No part of the mount may extend more than these distances radially
    # past the OD wall — beyond them the feature collides with the focus
    # collar on the Bronica helicoid. The collar is stepped: features in
    # z=[h − focus_collar_narrow_axial, h] (camera-side end) must respect
    # `max_radial_extension_narrow`; features below that range may use
    # the wider `max_radial_extension_wide`.
    max_radial_extension_wide = (
        BronicaS2Bayonet.focus_collar_inner_dia_wide / 2
        - BronicaS2Bayonet.lens_mount_od / 2
    )
    max_radial_extension_narrow = (
        BronicaS2Bayonet.focus_collar_inner_dia_narrow / 2
        - BronicaS2Bayonet.lens_mount_od / 2
    )


class BronicaS2LensMountSupports(LensMountSupports, BronicaS2LensMount):
    """Bronica S2 modeled supports for the basic lens mount."""


class s2_mount(Design):
    """Camera and lens mount variants. Locking-pin variants live in the
    sibling `s2-mount-locking.py` design module."""

    camera_mount = BronicaS2CameraMount()
    lens_mount = BronicaS2LensMount(
        cam_barrel_od=camera_mount.barrel_od,
        cam_barrel_id=camera_mount.barrel_id,
        lugs=camera_mount.lugs,
        lug_axial=camera_mount.lug_axial,
    )
    lens_mount_supports = BronicaS2LensMountSupports(
        cam_barrel_od=camera_mount.barrel_od,
        cam_barrel_id=camera_mount.barrel_id,
        lugs=camera_mount.lugs,
        lug_axial=camera_mount.lug_axial,
    )

    @variant(fn=96, default=True)
    def camera(self):
        return pack_on_bed(self.camera_mount, plate=BAMBU_X2D_PLATE)

    @variant(fn=96)
    def lens(self):
        return pack_on_bed(self.lens_mount, plate=BAMBU_X2D_PLATE)

    @variant(fn=96)
    def lens_supports(self):
        # Modeled PETG supports for the lens part. Print as a SECOND object
        # alongside `lens` in Bambu Studio (PETG filament, support: off on
        # this object). Pre-aligned to the lens mount's world coords — load
        # both STLs without auto-arrange.
        return self.lens_mount_supports.red()

    @variant(fn=96)
    def lens_print(self):
        # Combined STL with the lens mount AND the modeled supports as
        # disconnected manifold solids in the same file. Workflow:
        # in Bambu Studio, Right-click → Split → To Objects, assign PLA to
        # the mount, PETG to the supports, support: off on both objects.
        return pack_on_bed(
            union(self.lens_mount, self.lens_mount_supports.red()),
            plate=BAMBU_X2D_PLATE,
        )


if __name__ == "__main__":
    run()
